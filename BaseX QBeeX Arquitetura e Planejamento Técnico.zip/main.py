"""
BazeX Auth Service
Autor: Maya Patel - Backend Developer
Descrição: Serviço de autenticação e autorização para a plataforma BazeX/QBeeX
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager
import uvicorn
import structlog
from prometheus_client import Counter, Histogram, generate_latest
from fastapi.responses import Response

from .config import settings
from .database import init_db, get_db
from .models import User, TokenData
from .schemas import UserCreate, UserLogin, Token, UserResponse
from .auth import (
    create_access_token, 
    create_refresh_token, 
    verify_token, 
    get_current_user,
    hash_password,
    verify_password
)
from .cache import get_redis, cache_token, invalidate_token

# Configuração de logging
logger = structlog.get_logger()

# Métricas Prometheus
REQUEST_COUNT = Counter('auth_requests_total', 'Total auth requests', ['method', 'endpoint'])
REQUEST_DURATION = Histogram('auth_request_duration_seconds', 'Request duration')

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerenciamento do ciclo de vida da aplicação"""
    # Startup
    logger.info("🚀 Iniciando Auth Service...")
    await init_db()
    logger.info("✅ Database inicializado")
    
    yield
    
    # Shutdown
    logger.info("🛑 Finalizando Auth Service...")

# Inicialização da aplicação FastAPI
app = FastAPI(
    title="BazeX Auth Service",
    description="Serviço de autenticação e autorização da plataforma BazeX/QBeeX",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Middleware de segurança
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings.ALLOWED_HOSTS
)

# Security scheme
security = HTTPBearer()

@app.middleware("http")
async def add_process_time_header(request, call_next):
    """Middleware para métricas de performance"""
    import time
    start_time = time.time()
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    REQUEST_DURATION.observe(process_time)
    REQUEST_COUNT.labels(method=request.method, endpoint=request.url.path).inc()
    
    response.headers["X-Process-Time"] = str(process_time)
    return response

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "auth-service",
        "version": "1.0.0"
    }

@app.get("/metrics")
async def metrics():
    """Endpoint para métricas Prometheus"""
    return Response(generate_latest(), media_type="text/plain")

@app.post("/auth/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user(
    user_data: UserCreate,
    db = Depends(get_db)
):
    """
    Registro de novo usuário
    
    - **email**: Email único do usuário
    - **password**: Senha (mínimo 8 caracteres)
    - **full_name**: Nome completo do usuário
    """
    logger.info("Tentativa de registro", email=user_data.email)
    
    # Verificar se usuário já existe
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        logger.warning("Tentativa de registro com email existente", email=user_data.email)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email já está em uso"
        )
    
    # Criar novo usuário
    hashed_password = hash_password(user_data.password)
    new_user = User(
        email=user_data.email,
        full_name=user_data.full_name,
        hashed_password=hashed_password,
        is_active=True
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    logger.info("Usuário registrado com sucesso", user_id=new_user.id, email=new_user.email)
    
    return UserResponse(
        id=new_user.id,
        email=new_user.email,
        full_name=new_user.full_name,
        is_active=new_user.is_active,
        created_at=new_user.created_at
    )

@app.post("/auth/login", response_model=Token)
async def login_user(
    user_credentials: UserLogin,
    db = Depends(get_db),
    redis = Depends(get_redis)
):
    """
    Autenticação de usuário
    
    - **email**: Email do usuário
    - **password**: Senha do usuário
    
    Retorna access_token e refresh_token
    """
    logger.info("Tentativa de login", email=user_credentials.email)
    
    # Verificar credenciais
    user = db.query(User).filter(User.email == user_credentials.email).first()
    if not user or not verify_password(user_credentials.password, user.hashed_password):
        logger.warning("Credenciais inválidas", email=user_credentials.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        logger.warning("Tentativa de login com usuário inativo", email=user_credentials.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário inativo"
        )
    
    # Gerar tokens
    access_token = create_access_token(data={"sub": str(user.id), "email": user.email})
    refresh_token = create_refresh_token(data={"sub": str(user.id)})
    
    # Cache do token
    await cache_token(redis, access_token, user.id)
    
    # Atualizar último login
    from datetime import datetime
    user.last_login = datetime.utcnow()
    db.commit()
    
    logger.info("Login realizado com sucesso", user_id=user.id, email=user.email)
    
    return Token(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )

@app.post("/auth/refresh", response_model=Token)
async def refresh_token(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db = Depends(get_db),
    redis = Depends(get_redis)
):
    """
    Renovação de access token usando refresh token
    """
    refresh_token = credentials.credentials
    
    try:
        # Verificar refresh token
        payload = verify_token(refresh_token, settings.REFRESH_SECRET_KEY)
        user_id = payload.get("sub")
        
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token inválido"
            )
        
        # Verificar se usuário existe e está ativo
        user = db.query(User).filter(User.id == int(user_id)).first()
        if not user or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Usuário não encontrado ou inativo"
            )
        
        # Gerar novo access token
        new_access_token = create_access_token(
            data={"sub": str(user.id), "email": user.email}
        )
        
        # Cache do novo token
        await cache_token(redis, new_access_token, user.id)
        
        logger.info("Token renovado com sucesso", user_id=user.id)
        
        return Token(
            access_token=new_access_token,
            refresh_token=refresh_token,  # Mantém o mesmo refresh token
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        )
        
    except Exception as e:
        logger.error("Erro ao renovar token", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido"
        )

@app.post("/auth/logout")
async def logout_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    redis = Depends(get_redis),
    current_user: User = Depends(get_current_user)
):
    """
    Logout do usuário (invalidação do token)
    """
    access_token = credentials.credentials
    
    # Invalidar token no cache
    await invalidate_token(redis, access_token)
    
    logger.info("Logout realizado", user_id=current_user.id)
    
    return {"message": "Logout realizado com sucesso"}

@app.get("/auth/verify")
async def verify_user_token(
    current_user: User = Depends(get_current_user)
):
    """
    Verificação de token (para outros serviços)
    """
    return {
        "valid": True,
        "user_id": current_user.id,
        "email": current_user.email,
        "is_active": current_user.is_active
    }

@app.get("/auth/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    """
    Informações do usuário atual
    """
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        full_name=current_user.full_name,
        is_active=current_user.is_active,
        created_at=current_user.created_at,
        last_login=current_user.last_login
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8001,
        reload=settings.DEBUG,
        log_level="info"
    )

