# Centralização e Unificação do Gerenciamento de Identidade e Acesso (IAM)

## Visão Geral da Solução

Para resolver as inconsistências de autenticação e autorização entre frontend, backend e dispositivos IoT da BazeX/QBeeX, implementaremos um sistema centralizado de Identity and Access Management (IAM). Esta solução garantirá que todos os componentes do sistema utilizem um mecanismo de autenticação unificado, com tokens JWT consistentes e adaptadores específicos para dispositivos com capacidades limitadas.

## Componentes da Solução

### 1. Serviço Central de IAM

Este serviço gerencia todas as operações relacionadas a identidade e acesso.

```typescript
// src/iam/services/iam-service.ts

import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { UserRepository } from '../repositories/user-repository';
import { TokenRepository } from '../repositories/token-repository';
import { DeviceRepository } from '../repositories/device-repository';

export interface UserCredentials {
  email: string;
  password: string;
}

export interface TokenPayload {
  userId: string;
  email: string;
  roles: string[];
  deviceId?: string;
  scope: string[];
  sessionId: string;
  iat: number;
  exp: number;
  iss: string;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: string;
}

export interface DeviceRegistrationRequest {
  deviceId: string;
  deviceType: string;
  deviceName: string;
  userId: string;
  publicKey?: string;
}

export class IAMService {
  private static instance: IAMService;
  private readonly JWT_SECRET: string;
  private readonly JWT_REFRESH_SECRET: string;
  private readonly JWT_EXPIRES_IN: string;
  private readonly JWT_REFRESH_EXPIRES_IN: string;
  private readonly JWT_ISSUER: string;
  
  private constructor(
    private userRepository: UserRepository,
    private tokenRepository: TokenRepository,
    private deviceRepository: DeviceRepository
  ) {
    // In production, these would be loaded from secure environment variables
    this.JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
    this.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || crypto.randomBytes(32).toString('hex');
    this.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';
    this.JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
    this.JWT_ISSUER = process.env.JWT_ISSUER || 'bazex-iam';
  }

  public static getInstance(
    userRepository?: UserRepository,
    tokenRepository?: TokenRepository,
    deviceRepository?: DeviceRepository
  ): IAMService {
    if (!IAMService.instance) {
      if (!userRepository || !tokenRepository || !deviceRepository) {
        throw new Error('Repositories must be provided when initializing IAMService');
      }
      IAMService.instance = new IAMService(userRepository, tokenRepository, deviceRepository);
    }
    return IAMService.instance;
  }

  public async authenticate(credentials: UserCredentials): Promise<TokenResponse> {
    const user = await this.userRepository.findByEmail(credentials.email);
    
    if (!user) {
      throw new Error('User not found');
    }
    
    const isPasswordValid = await bcrypt.compare(credentials.password, user.passwordHash);
    
    if (!isPasswordValid) {
      throw new Error('Invalid password');
    }
    
    return this.generateTokens(user.id, user.email, user.roles);
  }

  public async refreshToken(refreshToken: string): Promise<TokenResponse> {
    try {
      // Verify refresh token
      const decoded = jwt.verify(refreshToken, this.JWT_REFRESH_SECRET) as TokenPayload;
      
      // Check if token is in blacklist
      const isBlacklisted = await this.tokenRepository.isTokenBlacklisted(refreshToken);
      if (isBlacklisted) {
        throw new Error('Token has been revoked');
      }
      
      // Get user
      const user = await this.userRepository.findById(decoded.userId);
      if (!user) {
        throw new Error('User not found');
      }
      
      // Generate new tokens
      return this.generateTokens(user.id, user.email, user.roles, decoded.deviceId);
    } catch (error) {
      throw new Error('Invalid refresh token');
    }
  }

  public async validateToken(token: string): Promise<TokenPayload> {
    try {
      // Verify token
      const decoded = jwt.verify(token, this.JWT_SECRET) as TokenPayload;
      
      // Check if token is in blacklist
      const isBlacklisted = await this.tokenRepository.isTokenBlacklisted(token);
      if (isBlacklisted) {
        throw new Error('Token has been revoked');
      }
      
      return decoded;
    } catch (error) {
      throw new Error('Invalid token');
    }
  }

  public async revokeToken(token: string): Promise<void> {
    try {
      // Verify token to get expiration
      const decoded = jwt.verify(token, this.JWT_SECRET) as TokenPayload;
      
      // Add to blacklist until expiration
      const expiresAt = new Date(decoded.exp * 1000);
      await this.tokenRepository.blacklistToken(token, expiresAt);
    } catch (error) {
      throw new Error('Invalid token');
    }
  }

  public async revokeAllUserTokens(userId: string): Promise<void> {
    // This would invalidate all sessions for a user
    // Implementation depends on how sessions are tracked
    await this.tokenRepository.blacklistAllUserTokens(userId);
  }

  public async registerDevice(request: DeviceRegistrationRequest): Promise<string> {
    // Check if user exists
    const user = await this.userRepository.findById(request.userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Register device
    const deviceId = request.deviceId || uuidv4();
    await this.deviceRepository.registerDevice({
      id: deviceId,
      userId: request.userId,
      type: request.deviceType,
      name: request.deviceName,
      publicKey: request.publicKey,
      createdAt: new Date(),
      lastActive: new Date()
    });
    
    // Generate device-specific token with limited scope
    const { accessToken } = await this.generateTokens(
      user.id,
      user.email,
      ['device'],
      deviceId,
      ['device:read', 'device:update']
    );
    
    return accessToken;
  }

  public async unregisterDevice(userId: string, deviceId: string): Promise<void> {
    await this.deviceRepository.unregisterDevice(userId, deviceId);
    // Revoke any tokens associated with this device
    await this.tokenRepository.blacklistAllDeviceTokens(deviceId);
  }

  private async generateTokens(
    userId: string,
    email: string,
    roles: string[],
    deviceId?: string,
    scope: string[] = ['*']
  ): Promise<TokenResponse> {
    const sessionId = uuidv4();
    
    // Create token payload
    const payload: Omit<TokenPayload, 'iat' | 'exp' | 'iss'> = {
      userId,
      email,
      roles,
      scope,
      sessionId
    };
    
    if (deviceId) {
      payload.deviceId = deviceId;
    }
    
    // Generate access token
    const accessToken = jwt.sign(
      payload,
      this.JWT_SECRET,
      {
        expiresIn: this.JWT_EXPIRES_IN,
        issuer: this.JWT_ISSUER
      }
    );
    
    // Generate refresh token with longer expiry
    const refreshToken = jwt.sign(
      payload,
      this.JWT_REFRESH_SECRET,
      {
        expiresIn: this.JWT_REFRESH_EXPIRES_IN,
        issuer: this.JWT_ISSUER
      }
    );
    
    // Store session info
    await this.tokenRepository.saveSession({
      id: sessionId,
      userId,
      deviceId,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + this.parseExpiresIn(this.JWT_REFRESH_EXPIRES_IN))
    });
    
    return {
      accessToken,
      refreshToken,
      expiresIn: this.parseExpiresIn(this.JWT_EXPIRES_IN) / 1000, // Convert to seconds
      tokenType: 'Bearer'
    };
  }

  private parseExpiresIn(expiresIn: string): number {
    const match = expiresIn.match(/^(\d+)([smhd])$/);
    if (!match) {
      return 3600 * 1000; // Default to 1 hour in milliseconds
    }
    
    const value = parseInt(match[1], 10);
    const unit = match[2];
    
    switch (unit) {
      case 's': return value * 1000;
      case 'm': return value * 60 * 1000;
      case 'h': return value * 60 * 60 * 1000;
      case 'd': return value * 24 * 60 * 60 * 1000;
      default: return value * 1000;
    }
  }
}
```

### 2. Repositórios para Persistência

Interfaces e implementações para armazenar dados de usuários, tokens e dispositivos.

```typescript
// src/iam/repositories/user-repository.ts

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  roles: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface UserRepository {
  findById(id: string): Promise<User | null>;
  findByEmail(email: string): Promise<User | null>;
  create(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User>;
  update(id: string, user: Partial<User>): Promise<User>;
  delete(id: string): Promise<void>;
}

// src/iam/repositories/token-repository.ts

export interface Session {
  id: string;
  userId: string;
  deviceId?: string;
  createdAt: Date;
  expiresAt: Date;
}

export interface TokenRepository {
  saveSession(session: Session): Promise<void>;
  getSession(sessionId: string): Promise<Session | null>;
  deleteSession(sessionId: string): Promise<void>;
  blacklistToken(token: string, expiresAt: Date): Promise<void>;
  isTokenBlacklisted(token: string): Promise<boolean>;
  blacklistAllUserTokens(userId: string): Promise<void>;
  blacklistAllDeviceTokens(deviceId: string): Promise<void>;
  cleanupExpiredTokens(): Promise<void>;
}

// src/iam/repositories/device-repository.ts

export interface Device {
  id: string;
  userId: string;
  type: string;
  name: string;
  publicKey?: string;
  createdAt: Date;
  lastActive: Date;
}

export interface DeviceRepository {
  registerDevice(device: Device): Promise<void>;
  unregisterDevice(userId: string, deviceId: string): Promise<void>;
  getDevice(deviceId: string): Promise<Device | null>;
  getUserDevices(userId: string): Promise<Device[]>;
  updateDeviceActivity(deviceId: string): Promise<void>;
}
```

### 3. Implementações de Repositórios

Implementações concretas para PostgreSQL.

```typescript
// src/iam/repositories/postgres/postgres-user-repository.ts

import { Pool } from 'pg';
import { User, UserRepository } from '../user-repository';
import { v4 as uuidv4 } from 'uuid';

export class PostgresUserRepository implements UserRepository {
  constructor(private pool: Pool) {}

  async findById(id: string): Promise<User | null> {
    const result = await this.pool.query(
      'SELECT * FROM users WHERE id = $1',
      [id]
    );
    
    if (result.rows.length === 0) {
      return null;
    }
    
    return this.mapRowToUser(result.rows[0]);
  }

  async findByEmail(email: string): Promise<User | null> {
    const result = await this.pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    
    if (result.rows.length === 0) {
      return null;
    }
    
    return this.mapRowToUser(result.rows[0]);
  }

  async create(user: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User> {
    const id = uuidv4();
    const now = new Date();
    
    const result = await this.pool.query(
      `INSERT INTO users (id, email, password_hash, roles, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [id, user.email, user.passwordHash, JSON.stringify(user.roles), now, now]
    );
    
    return this.mapRowToUser(result.rows[0]);
  }

  async update(id: string, user: Partial<User>): Promise<User> {
    const updates: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;
    
    if (user.email !== undefined) {
      updates.push(`email = $${paramIndex++}`);
      values.push(user.email);
    }
    
    if (user.passwordHash !== undefined) {
      updates.push(`password_hash = $${paramIndex++}`);
      values.push(user.passwordHash);
    }
    
    if (user.roles !== undefined) {
      updates.push(`roles = $${paramIndex++}`);
      values.push(JSON.stringify(user.roles));
    }
    
    updates.push(`updated_at = $${paramIndex++}`);
    values.push(new Date());
    
    values.push(id);
    
    const result = await this.pool.query(
      `UPDATE users
       SET ${updates.join(', ')}
       WHERE id = $${paramIndex}
       RETURNING *`,
      values
    );
    
    if (result.rows.length === 0) {
      throw new Error('User not found');
    }
    
    return this.mapRowToUser(result.rows[0]);
  }

  async delete(id: string): Promise<void> {
    await this.pool.query(
      'DELETE FROM users WHERE id = $1',
      [id]
    );
  }

  private mapRowToUser(row: any): User {
    return {
      id: row.id,
      email: row.email,
      passwordHash: row.password_hash,
      roles: JSON.parse(row.roles),
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
}

// src/iam/repositories/postgres/postgres-token-repository.ts

import { Pool } from 'pg';
import { Session, TokenRepository } from '../token-repository';

export class PostgresTokenRepository implements TokenRepository {
  constructor(private pool: Pool) {}

  async saveSession(session: Session): Promise<void> {
    await this.pool.query(
      `INSERT INTO sessions (id, user_id, device_id, created_at, expires_at)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (id) DO UPDATE
       SET expires_at = $5`,
      [session.id, session.userId, session.deviceId, session.createdAt, session.expiresAt]
    );
  }

  async getSession(sessionId: string): Promise<Session | null> {
    const result = await this.pool.query(
      'SELECT * FROM sessions WHERE id = $1 AND expires_at > NOW()',
      [sessionId]
    );
    
    if (result.rows.length === 0) {
      return null;
    }
    
    return {
      id: result.rows[0].id,
      userId: result.rows[0].user_id,
      deviceId: result.rows[0].device_id,
      createdAt: result.rows[0].created_at,
      expiresAt: result.rows[0].expires_at
    };
  }

  async deleteSession(sessionId: string): Promise<void> {
    await this.pool.query(
      'DELETE FROM sessions WHERE id = $1',
      [sessionId]
    );
  }

  async blacklistToken(token: string, expiresAt: Date): Promise<void> {
    await this.pool.query(
      `INSERT INTO token_blacklist (token_hash, expires_at)
       VALUES ($1, $2)`,
      [this.hashToken(token), expiresAt]
    );
  }

  async isTokenBlacklisted(token: string): Promise<boolean> {
    const result = await this.pool.query(
      'SELECT 1 FROM token_blacklist WHERE token_hash = $1 AND expires_at > NOW()',
      [this.hashToken(token)]
    );
    
    return result.rows.length > 0;
  }

  async blacklistAllUserTokens(userId: string): Promise<void> {
    // Get all active sessions for user
    const sessions = await this.pool.query(
      'SELECT id FROM sessions WHERE user_id = $1 AND expires_at > NOW()',
      [userId]
    );
    
    // Mark all sessions as expired
    if (sessions.rows.length > 0) {
      const sessionIds = sessions.rows.map(row => row.id);
      await this.pool.query(
        `UPDATE sessions 
         SET expires_at = NOW() 
         WHERE id = ANY($1)`,
        [sessionIds]
      );
    }
  }

  async blacklistAllDeviceTokens(deviceId: string): Promise<void> {
    // Get all active sessions for device
    const sessions = await this.pool.query(
      'SELECT id FROM sessions WHERE device_id = $1 AND expires_at > NOW()',
      [deviceId]
    );
    
    // Mark all sessions as expired
    if (sessions.rows.length > 0) {
      const sessionIds = sessions.rows.map(row => row.id);
      await this.pool.query(
        `UPDATE sessions 
         SET expires_at = NOW() 
         WHERE id = ANY($1)`,
        [sessionIds]
      );
    }
  }

  async cleanupExpiredTokens(): Promise<void> {
    // Delete expired sessions and blacklisted tokens
    await this.pool.query('DELETE FROM sessions WHERE expires_at <= NOW()');
    await this.pool.query('DELETE FROM token_blacklist WHERE expires_at <= NOW()');
  }

  private hashToken(token: string): string {
    // In production, use a secure hashing algorithm
    // This is a simplified example
    const crypto = require('crypto');
    return crypto.createHash('sha256').update(token).digest('hex');
  }
}

// src/iam/repositories/postgres/postgres-device-repository.ts

import { Pool } from 'pg';
import { Device, DeviceRepository } from '../device-repository';

export class PostgresDeviceRepository implements DeviceRepository {
  constructor(private pool: Pool) {}

  async registerDevice(device: Device): Promise<void> {
    await this.pool.query(
      `INSERT INTO devices (id, user_id, type, name, public_key, created_at, last_active)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       ON CONFLICT (id) DO UPDATE
       SET name = $4, public_key = $5, last_active = $7`,
      [
        device.id,
        device.userId,
        device.type,
        device.name,
        device.publicKey,
        device.createdAt,
        device.lastActive
      ]
    );
  }

  async unregisterDevice(userId: string, deviceId: string): Promise<void> {
    await this.pool.query(
      'DELETE FROM devices WHERE id = $1 AND user_id = $2',
      [deviceId, userId]
    );
  }

  async getDevice(deviceId: string): Promise<Device | null> {
    const result = await this.pool.query(
      'SELECT * FROM devices WHERE id = $1',
      [deviceId]
    );
    
    if (result.rows.length === 0) {
      return null;
    }
    
    return this.mapRowToDevice(result.rows[0]);
  }

  async getUserDevices(userId: string): Promise<Device[]> {
    const result = await this.pool.query(
      'SELECT * FROM devices WHERE user_id = $1',
      [userId]
    );
    
    return result.rows.map(this.mapRowToDevice);
  }

  async updateDeviceActivity(deviceId: string): Promise<void> {
    await this.pool.query(
      'UPDATE devices SET last_active = $1 WHERE id = $2',
      [new Date(), deviceId]
    );
  }

  private mapRowToDevice(row: any): Device {
    return {
      id: row.id,
      userId: row.user_id,
      type: row.type,
      name: row.name,
      publicKey: row.public_key,
      createdAt: row.created_at,
      lastActive: row.last_active
    };
  }
}
```

### 4. Middleware de Autenticação para Backend

Middleware para Express que valida tokens JWT.

```typescript
// src/iam/middleware/auth-middleware.ts

import { Request, Response, NextFunction } from 'express';
import { IAMService } from '../services/iam-service';

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    roles: string[];
    deviceId?: string;
    scope: string[];
    sessionId: string;
  };
}

export function authMiddleware(
  requiredScopes: string[] = []
) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const authHeader = req.headers.authorization;
      
      if (!authHeader) {
        return res.status(401).json({ error: 'Authorization header missing' });
      }
      
      const [type, token] = authHeader.split(' ');
      
      if (type !== 'Bearer' || !token) {
        return res.status(401).json({ error: 'Invalid authorization format' });
      }
      
      try {
        const iamService = IAMService.getInstance();
        const decoded = await iamService.validateToken(token);
        
        // Check scopes if required
        if (requiredScopes.length > 0) {
          const hasAllScopes = requiredScopes.every(scope => 
            decoded.scope.includes(scope) || decoded.scope.includes('*')
          );
          
          if (!hasAllScopes) {
            return res.status(403).json({ error: 'Insufficient permissions' });
          }
        }
        
        // Attach user info to request
        req.user = {
          id: decoded.userId,
          email: decoded.email,
          roles: decoded.roles,
          deviceId: decoded.deviceId,
          scope: decoded.scope,
          sessionId: decoded.sessionId
        };
        
        next();
      } catch (error) {
        return res.status(401).json({ error: 'Invalid token' });
      }
    } catch (error) {
      next(error);
    }
  };
}
```

### 5. Cliente de Autenticação para Frontend

Cliente para interagir com o serviço IAM a partir do frontend.

```typescript
// src/frontend/services/auth-service.ts

import { TokenResponse } from '../../iam/services/iam-service';

export class AuthService {
  private static instance: AuthService;
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private tokenExpiry: number | null = null;
  private refreshPromise: Promise<void> | null = null;
  
  private constructor(private apiUrl: string) {}
  
  public static getInstance(apiUrl?: string): AuthService {
    if (!AuthService.instance) {
      if (!apiUrl) {
        throw new Error('API URL must be provided when initializing AuthService');
      }
      AuthService.instance = new AuthService(apiUrl);
    }
    return AuthService.instance;
  }
  
  public async login(email: string, password: string): Promise<void> {
    const response = await fetch(`${this.apiUrl}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Login failed');
    }
    
    const tokenResponse: TokenResponse = await response.json();
    this.setTokens(tokenResponse);
  }
  
  public async logout(): Promise<void> {
    if (!this.accessToken) {
      return;
    }
    
    try {
      await fetch(`${this.apiUrl}/auth/logout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.accessToken}`
        }
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.clearTokens();
    }
  }
  
  public async getToken(): Promise<string> {
    if (!this.accessToken) {
      throw new Error('Not authenticated');
    }
    
    // Check if token is expired or about to expire (within 30 seconds)
    if (this.tokenExpiry && this.tokenExpiry - Date.now() < 30000) {
      // Token is about to expire, refresh it
      await this.refreshAccessToken();
    }
    
    return this.accessToken;
  }
  
  public isAuthenticated(): boolean {
    return !!this.accessToken && !!this.tokenExpiry && this.tokenExpiry > Date.now();
  }
  
  private async refreshAccessToken(): Promise<void> {
    // If a refresh is already in progress, wait for it
    if (this.refreshPromise) {
      return this.refreshPromise;
    }
    
    if (!this.refreshToken) {
      this.clearTokens();
      throw new Error('No refresh token available');
    }
    
    this.refreshPromise = (async () => {
      try {
        const response = await fetch(`${this.apiUrl}/auth/refresh`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ refreshToken: this.refreshToken })
        });
        
        if (!response.ok) {
          this.clearTokens();
          throw new Error('Token refresh failed');
        }
        
        const tokenResponse: TokenResponse = await response.json();
        this.setTokens(tokenResponse);
      } catch (error) {
        this.clearTokens();
        throw error;
      } finally {
        this.refreshPromise = null;
      }
    })();
    
    return this.refreshPromise;
  }
  
  private setTokens(tokenResponse: TokenResponse): void {
    this.accessToken = tokenResponse.accessToken;
    this.refreshToken = tokenResponse.refreshToken;
    this.tokenExpiry = Date.now() + tokenResponse.expiresIn * 1000;
    
    // Store tokens in localStorage for persistence
    localStorage.setItem('accessToken', this.accessToken);
    localStorage.setItem('refreshToken', this.refreshToken);
    localStorage.setItem('tokenExpiry', this.tokenExpiry.toString());
  }
  
  private clearTokens(): void {
    this.accessToken = null;
    this.refreshToken = null;
    this.tokenExpiry = null;
    
    // Clear from localStorage
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('tokenExpiry');
  }
  
  public loadTokensFromStorage(): void {
    const accessToken = localStorage.getItem('accessToken');
    const refreshToken = localStorage.getItem('refreshToken');
    const tokenExpiry = localStorage.getItem('tokenExpiry');
    
    if (accessToken && refreshToken && tokenExpiry) {
      this.accessToken = accessToken;
      this.refreshToken = refreshToken;
      this.tokenExpiry = parseInt(tokenExpiry, 10);
      
      // If token is expired, try to refresh it
      if (this.tokenExpiry <= Date.now()) {
        this.refreshAccessToken().catch(() => {
          // If refresh fails, clear tokens
          this.clearTokens();
        });
      }
    }
  }
}
```

### 6. Cliente de Autenticação para IoT

Cliente leve para dispositivos IoT com recursos limitados.

```typescript
// src/iot/auth-client.ts

export interface IoTAuthConfig {
  apiUrl: string;
  deviceId: string;
  deviceSecret: string;
  tokenRefreshInterval?: number; // milliseconds
}

export class IoTAuthClient {
  private accessToken: string | null = null;
  private tokenExpiry: number | null = null;
  private refreshInterval: NodeJS.Timeout | null = null;
  
  constructor(private config: IoTAuthConfig) {
    // Default refresh interval: 80% of token lifetime or 1 hour
    this.config.tokenRefreshInterval = this.config.tokenRefreshInterval || 3600000; // 1 hour
    
    // Start token refresh cycle
    this.startRefreshCycle();
  }
  
  public async getToken(): Promise<string> {
    if (!this.accessToken || (this.tokenExpiry && this.tokenExpiry <= Date.now())) {
      await this.authenticate();
    }
    
    if (!this.accessToken) {
      throw new Error('Authentication failed');
    }
    
    return this.accessToken;
  }
  
  public isAuthenticated(): boolean {
    return !!this.accessToken && !!this.tokenExpiry && this.tokenExpiry > Date.now();
  }
  
  private async authenticate(): Promise<void> {
    try {
      const response = await fetch(`${this.config.apiUrl}/auth/device`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          deviceId: this.config.deviceId,
          deviceSecret: this.config.deviceSecret
        })
      });
      
      if (!response.ok) {
        throw new Error(`Authentication failed: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      this.accessToken = data.accessToken;
      this.tokenExpiry = Date.now() + data.expiresIn * 1000;
    } catch (error) {
      console.error('IoT authentication error:', error);
      throw error;
    }
  }
  
  private startRefreshCycle(): void {
    // Clear any existing interval
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
    
    // Set up new refresh interval
    this.refreshInterval = setInterval(async () => {
      try {
        await this.authenticate();
      } catch (error) {
        console.error('Token refresh failed:', error);
      }
    }, this.config.tokenRefreshInterval);
    
    // Ensure interval doesn't prevent Node.js from exiting
    if (this.refreshInterval.unref) {
      this.refreshInterval.unref();
    }
  }
  
  public stopRefreshCycle(): void {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
      this.refreshInterval = null;
    }
  }
}
```

### 7. Controladores de Autenticação para Backend

Controladores Express para endpoints de autenticação.

```typescript
// src/iam/controllers/auth-controller.ts

import { Request, Response } from 'express';
import { IAMService, UserCredentials, DeviceRegistrationRequest } from '../services/iam-service';
import { AuthenticatedRequest } from '../middleware/auth-middleware';

export class AuthController {
  constructor(private iamService: IAMService) {}
  
  async login(req: Request, res: Response): Promise<void> {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required' });
        return;
      }
      
      const credentials: UserCredentials = { email, password };
      const tokenResponse = await this.iamService.authenticate(credentials);
      
      res.json(tokenResponse);
    } catch (error) {
      console.error('Login error:', error);
      res.status(401).json({ error: 'Authentication failed' });
    }
  }
  
  async refresh(req: Request, res: Response): Promise<void> {
    try {
      const { refreshToken } = req.body;
      
      if (!refreshToken) {
        res.status(400).json({ error: 'Refresh token is required' });
        return;
      }
      
      const tokenResponse = await this.iamService.refreshToken(refreshToken);
      
      res.json(tokenResponse);
    } catch (error) {
      console.error('Token refresh error:', error);
      res.status(401).json({ error: 'Invalid refresh token' });
    }
  }
  
  async logout(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const authHeader = req.headers.authorization;
      
      if (!authHeader) {
        res.status(401).json({ error: 'Authorization header missing' });
        return;
      }
      
      const [type, token] = authHeader.split(' ');
      
      if (type !== 'Bearer' || !token) {
        res.status(401).json({ error: 'Invalid authorization format' });
        return;
      }
      
      await this.iamService.revokeToken(token);
      
      res.status(204).end();
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ error: 'Logout failed' });
    }
  }
  
  async deviceAuth(req: Request, res: Response): Promise<void> {
    try {
      const { deviceId, deviceSecret } = req.body;
      
      if (!deviceId || !deviceSecret) {
        res.status(400).json({ error: 'Device ID and secret are required' });
        return;
      }
      
      // In a real implementation, validate device secret against stored hash
      // This is a simplified example
      const deviceRepository = this.iamService.getDeviceRepository();
      const device = await deviceRepository.getDevice(deviceId);
      
      if (!device) {
        res.status(401).json({ error: 'Device not found' });
        return;
      }
      
      // Generate token for device
      const tokenResponse = await this.iamService.generateDeviceToken(device.id, device.userId);
      
      // Update device last active timestamp
      await deviceRepository.updateDeviceActivity(deviceId);
      
      res.json(tokenResponse);
    } catch (error) {
      console.error('Device authentication error:', error);
      res.status(401).json({ error: 'Device authentication failed' });
    }
  }
  
  async registerDevice(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required' });
        return;
      }
      
      const { deviceId, deviceType, deviceName, publicKey } = req.body;
      
      if (!deviceType || !deviceName) {
        res.status(400).json({ error: 'Device type and name are required' });
        return;
      }
      
      const request: DeviceRegistrationRequest = {
        deviceId,
        deviceType,
        deviceName,
        userId: req.user.id,
        publicKey
      };
      
      const deviceToken = await this.iamService.registerDevice(request);
      
      res.json({ deviceToken });
    } catch (error) {
      console.error('Device registration error:', error);
      res.status(500).json({ error: 'Device registration failed' });
    }
  }
  
  async unregisterDevice(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required' });
        return;
      }
      
      const { deviceId } = req.params;
      
      if (!deviceId) {
        res.status(400).json({ error: 'Device ID is required' });
        return;
      }
      
      await this.iamService.unregisterDevice(req.user.id, deviceId);
      
      res.status(204).end();
    } catch (error) {
      console.error('Device unregistration error:', error);
      res.status(500).json({ error: 'Device unregistration failed' });
    }
  }
}
```

### 8. Configuração de Rotas para Autenticação

Configuração de rotas Express para endpoints de autenticação.

```typescript
// src/iam/routes/auth-routes.ts

import express from 'express';
import { AuthController } from '../controllers/auth-controller';
import { authMiddleware } from '../middleware/auth-middleware';
import { IAMService } from '../services/iam-service';

export function setupAuthRoutes(app: express.Application): void {
  const iamService = IAMService.getInstance();
  const authController = new AuthController(iamService);
  
  // Public routes
  app.post('/api/auth/login', (req, res) => authController.login(req, res));
  app.post('/api/auth/refresh', (req, res) => authController.refresh(req, res));
  app.post('/api/auth/device', (req, res) => authController.deviceAuth(req, res));
  
  // Protected routes
  app.post('/api/auth/logout', authMiddleware(), (req, res) => authController.logout(req, res));
  app.post('/api/auth/devices', authMiddleware(['device:register']), (req, res) => authController.registerDevice(req, res));
  app.delete('/api/auth/devices/:deviceId', authMiddleware(['device:unregister']), (req, res) => authController.unregisterDevice(req, res));
}
```

### 9. Integração com Frontend React

Exemplo de integração com React usando Context API.

```typescript
// src/frontend/contexts/auth-context.tsx

import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthService } from '../services/auth-service';

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  user: {
    id: string;
    email: string;
    roles: string[];
  } | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [user, setUser] = useState<{ id: string; email: string; roles: string[] } | null>(null);
  
  const authService = AuthService.getInstance();
  
  useEffect(() => {
    // Load tokens from storage on mount
    authService.loadTokensFromStorage();
    
    // Check if authenticated
    const checkAuth = async () => {
      try {
        if (authService.isAuthenticated()) {
          // Fetch user info
          const userInfo = await fetchUserInfo();
          setUser(userInfo);
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.error('Auth check error:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuth();
  }, []);
  
  const fetchUserInfo = async () => {
    try {
      const token = await authService.getToken();
      const response = await fetch('/api/users/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch user info');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Fetch user info error:', error);
      throw error;
    }
  };
  
  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      await authService.login(email, password);
      const userInfo = await fetchUserInfo();
      setUser(userInfo);
      setIsAuthenticated(true);
    } finally {
      setIsLoading(false);
    }
  };
  
  const logout = async () => {
    setIsLoading(true);
    try {
      await authService.logout();
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      setIsLoading(false);
    }
  };
  
  return (
    <AuthContext.Provider value={{ isAuthenticated, isLoading, login, logout, user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
```

### 10. Integração com Axios para Requisições HTTP

Configuração do Axios para incluir automaticamente tokens de autenticação.

```typescript
// src/frontend/services/api-service.ts

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { AuthService } from './auth-service';

export class ApiService {
  private static instance: ApiService;
  private axiosInstance: AxiosInstance;
  private authService: AuthService;
  
  private constructor(baseURL: string) {
    this.authService = AuthService.getInstance();
    
    this.axiosInstance = axios.create({
      baseURL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    // Request interceptor to add auth token
    this.axiosInstance.interceptors.request.use(
      async (config) => {
        if (this.authService.isAuthenticated()) {
          const token = await this.authService.getToken();
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );
    
    // Response interceptor to handle auth errors
    this.axiosInstance.interceptors.response.use(
      (response) => {
        return response;
      },
      async (error) => {
        const originalRequest = error.config;
        
        // If error is 401 and not a retry
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;
          
          try {
            // Try to refresh token
            await this.authService.refreshAccessToken();
            
            // Retry with new token
            const token = await this.authService.getToken();
            originalRequest.headers.Authorization = `Bearer ${token}`;
            return this.axiosInstance(originalRequest);
          } catch (refreshError) {
            // If refresh fails, redirect to login
            window.location.href = '/login';
            return Promise.reject(refreshError);
          }
        }
        
        return Promise.reject(error);
      }
    );
  }
  
  public static getInstance(baseURL?: string): ApiService {
    if (!ApiService.instance) {
      if (!baseURL) {
        throw new Error('Base URL must be provided when initializing ApiService');
      }
      ApiService.instance = new ApiService(baseURL);
    }
    return ApiService.instance;
  }
  
  public async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.axiosInstance.get<T>(url, config);
  }
  
  public async post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.axiosInstance.post<T>(url, data, config);
  }
  
  public async put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.axiosInstance.put<T>(url, data, config);
  }
  
  public async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.axiosInstance.delete<T>(url, config);
  }
  
  public async patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    return this.axiosInstance.patch<T>(url, data, config);
  }
}
```

### 11. Integração com IoT

Exemplo de uso do cliente de autenticação em um dispositivo IoT.

```typescript
// src/iot/device-main.ts

import { IoTAuthClient } from './auth-client';
import { DeviceService } from './device-service';

async function main() {
  try {
    // Initialize auth client
    const authClient = new IoTAuthClient({
      apiUrl: process.env.API_URL || 'https://api.bazex.com',
      deviceId: process.env.DEVICE_ID || 'unknown',
      deviceSecret: process.env.DEVICE_SECRET || 'unknown',
      tokenRefreshInterval: 3600000 // 1 hour
    });
    
    // Wait for initial authentication
    await authClient.getToken();
    
    // Initialize device service with auth client
    const deviceService = new DeviceService(authClient);
    
    // Start device operations
    await deviceService.start();
    
    console.log('Device started successfully');
    
    // Handle graceful shutdown
    process.on('SIGINT', async () => {
      console.log('Shutting down...');
      await deviceService.stop();
      authClient.stopRefreshCycle();
      process.exit(0);
    });
  } catch (error) {
    console.error('Failed to start device:', error);
    process.exit(1);
  }
}

main();
```

### 12. Esquema de Banco de Dados

Esquema SQL para PostgreSQL.

```sql
-- Create users table
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  roles JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

-- Create sessions table
CREATE TABLE sessions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id UUID,
  created_at TIMESTAMP NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  INDEX (user_id),
  INDEX (device_id),
  INDEX (expires_at)
);

-- Create token blacklist table
CREATE TABLE token_blacklist (
  token_hash VARCHAR(255) PRIMARY KEY,
  expires_at TIMESTAMP NOT NULL,
  INDEX (expires_at)
);

-- Create devices table
CREATE TABLE devices (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  public_key TEXT,
  created_at TIMESTAMP NOT NULL,
  last_active TIMESTAMP NOT NULL,
  INDEX (user_id)
);

-- Create device secrets table (separate for security)
CREATE TABLE device_secrets (
  device_id UUID PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
  secret_hash VARCHAR(255) NOT NULL
);
```

## Fluxo de Autenticação

### 1. Autenticação de Usuário (Frontend)

1. Usuário insere credenciais no frontend
2. Frontend envia credenciais para `/api/auth/login`
3. Backend valida credenciais e retorna `accessToken` e `refreshToken`
4. Frontend armazena tokens e configura interceptor Axios
5. Todas as requisições subsequentes incluem automaticamente o token
6. Quando o `accessToken` expira, o interceptor usa o `refreshToken` para obter um novo

### 2. Autenticação de Dispositivo IoT

1. Dispositivo IoT é registrado pelo usuário através do frontend
2. Backend gera um ID e segredo para o dispositivo
3. Dispositivo IoT usa ID e segredo para autenticar-se em `/api/auth/device`
4. Backend valida credenciais do dispositivo e retorna um token específico para o dispositivo
5. Dispositivo IoT usa o token para todas as comunicações com o backend
6. Token é renovado automaticamente pelo cliente de autenticação IoT

### 3. Logout e Revogação

1. Quando o usuário faz logout, o frontend chama `/api/auth/logout`
2. Backend adiciona o token à lista negra
3. Todas as tentativas de usar o token revogado falham
4. Quando um dispositivo é desregistrado, todos os seus tokens são revogados

## Considerações de Segurança

1. **Armazenamento Seguro de Tokens**: Tokens são armazenados em localStorage no frontend, o que é conveniente mas não totalmente seguro contra ataques XSS. Em uma implementação de produção, considere usar cookies HttpOnly com flags Secure e SameSite para o refreshToken.

2. **Rotação de Chaves**: Implemente rotação periódica das chaves de assinatura JWT para limitar o impacto de chaves comprometidas.

3. **Limitação de Taxa**: Adicione limitação de taxa para endpoints de autenticação para prevenir ataques de força bruta.

4. **Monitoramento de Sessões**: Implemente um painel para usuários visualizarem e gerenciarem suas sessões ativas.

5. **Autenticação Multifator**: Estenda o sistema para suportar autenticação multifator para maior segurança.

## Considerações para o MVP

Para a fase inicial de desenvolvimento (MVP), o sistema de IAM deve focar em:

1. Implementação completa do fluxo de autenticação de usuário
2. Suporte básico para autenticação de dispositivos IoT
3. Middleware de autenticação para backend
4. Cliente de autenticação para frontend
5. Armazenamento seguro de tokens e senhas

Recursos avançados como rotação automática de chaves, autenticação multifator e federação de identidade podem ser adicionados em fases posteriores.

## Conclusão

Esta implementação de IAM centralizado resolve os problemas de inconsistência de autenticação entre frontend, backend e dispositivos IoT da BazeX/QBeeX. O sistema garante:

1. **Autenticação Unificada**: Todos os componentes usam o mesmo mecanismo de autenticação baseado em JWT.

2. **Gerenciamento Centralizado**: Um único serviço gerencia todas as operações relacionadas a identidade e acesso.

3. **Suporte a Dispositivos IoT**: Adaptadores específicos para dispositivos com capacidades limitadas.

4. **Revogação Eficiente**: Capacidade de revogar tokens individuais ou todas as sessões de um usuário.

5. **Escalabilidade**: Arquitetura que suporta um grande número de usuários e dispositivos.

Esta solução elimina as inconsistências de autenticação identificadas na revisão técnica e fornece uma base sólida para a integração perfeita entre frontend, backend e componentes IoT da plataforma BazeX/QBeeX.
