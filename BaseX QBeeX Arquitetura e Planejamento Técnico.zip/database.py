"""
Módulo de configuração do banco de dados
Autor: Maya Patel - Backend Developer
"""

from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
import structlog

from .config import settings

logger = structlog.get_logger()

# Configuração do engine do SQLAlchemy
engine = create_engine(
    settings.DATABASE_URL,
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    pool_pre_ping=True,  # Verifica conexões antes de usar
    echo=settings.DEBUG,  # Log SQL queries em debug
)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base para modelos
Base = declarative_base()

def get_db() -> Session:
    """
    Dependency para obter sessão do banco de dados
    
    Yields:
        Session: Sessão do SQLAlchemy
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

async def init_db():
    """
    Inicializa o banco de dados criando as tabelas
    """
    try:
        # Importar modelos para garantir que estão registrados
        from .models import User, RefreshToken, LoginAttempt
        
        # Criar todas as tabelas
        Base.metadata.create_all(bind=engine)
        
        logger.info("✅ Tabelas do banco de dados criadas/verificadas")
        
        # Criar usuário admin padrão se não existir
        await create_default_admin()
        
    except Exception as e:
        logger.error("❌ Erro ao inicializar banco de dados", error=str(e))
        raise

async def create_default_admin():
    """
    Cria usuário administrador padrão se não existir
    """
    try:
        from .models import User
        from .auth import hash_password
        
        db = SessionLocal()
        
        # Verificar se já existe um admin
        admin_user = db.query(User).filter(User.email == "admin@bazex.app").first()
        
        if not admin_user:
            # Criar usuário admin
            admin_password = hash_password("BazeX@Admin123!")
            admin_user = User(
                email="admin@bazex.app",
                full_name="Administrador BazeX",
                hashed_password=admin_password,
                is_active=True,
                is_superuser=True,
                privacy_level="minimal",
                data_sharing_consent=False,
                marketing_consent=False
            )
            
            db.add(admin_user)
            db.commit()
            
            logger.info("✅ Usuário administrador padrão criado", email="admin@bazex.app")
        else:
            logger.info("ℹ️ Usuário administrador já existe")
        
        db.close()
        
    except Exception as e:
        logger.error("❌ Erro ao criar usuário admin padrão", error=str(e))

def check_db_connection():
    """
    Verifica conexão com o banco de dados
    
    Returns:
        bool: True se a conexão estiver funcionando
    """
    try:
        db = SessionLocal()
        # Executar query simples para testar conexão
        db.execute("SELECT 1")
        db.close()
        return True
    except Exception as e:
        logger.error("❌ Erro de conexão com banco de dados", error=str(e))
        return False

class DatabaseManager:
    """Classe para gerenciar operações do banco de dados"""
    
    def __init__(self):
        self.engine = engine
        self.SessionLocal = SessionLocal
    
    def get_session(self) -> Session:
        """Retorna nova sessão do banco"""
        return self.SessionLocal()
    
    def create_tables(self):
        """Cria todas as tabelas"""
        Base.metadata.create_all(bind=self.engine)
    
    def drop_tables(self):
        """Remove todas as tabelas (cuidado!)"""
        Base.metadata.drop_all(bind=self.engine)
    
    def backup_database(self, backup_path: str):
        """
        Cria backup do banco de dados
        
        Args:
            backup_path: Caminho para salvar o backup
        """
        # Implementação específica para PostgreSQL
        import subprocess
        import os
        
        try:
            # Extrair informações da URL do banco
            from urllib.parse import urlparse
            parsed = urlparse(settings.DATABASE_URL)
            
            env = os.environ.copy()
            env['PGPASSWORD'] = parsed.password
            
            cmd = [
                'pg_dump',
                '-h', parsed.hostname,
                '-p', str(parsed.port),
                '-U', parsed.username,
                '-d', parsed.path[1:],  # Remove '/' do início
                '-f', backup_path
            ]
            
            subprocess.run(cmd, env=env, check=True)
            logger.info("✅ Backup criado com sucesso", path=backup_path)
            
        except Exception as e:
            logger.error("❌ Erro ao criar backup", error=str(e))
            raise
    
    def restore_database(self, backup_path: str):
        """
        Restaura banco de dados do backup
        
        Args:
            backup_path: Caminho do arquivo de backup
        """
        import subprocess
        import os
        
        try:
            # Extrair informações da URL do banco
            from urllib.parse import urlparse
            parsed = urlparse(settings.DATABASE_URL)
            
            env = os.environ.copy()
            env['PGPASSWORD'] = parsed.password
            
            cmd = [
                'psql',
                '-h', parsed.hostname,
                '-p', str(parsed.port),
                '-U', parsed.username,
                '-d', parsed.path[1:],
                '-f', backup_path
            ]
            
            subprocess.run(cmd, env=env, check=True)
            logger.info("✅ Backup restaurado com sucesso", path=backup_path)
            
        except Exception as e:
            logger.error("❌ Erro ao restaurar backup", error=str(e))
            raise

# Instância global do gerenciador
db_manager = DatabaseManager()

# Context manager para transações
class DatabaseTransaction:
    """Context manager para transações do banco"""
    
    def __init__(self):
        self.db = None
    
    def __enter__(self) -> Session:
        self.db = SessionLocal()
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.db.rollback()
            logger.error("Transação revertida", error=str(exc_val))
        else:
            self.db.commit()
        
        self.db.close()

# Funções utilitárias para operações comuns

def get_user_by_email(db: Session, email: str):
    """
    Busca usuário por email
    
    Args:
        db: Sessão do banco
        email: Email do usuário
        
    Returns:
        User ou None
    """
    from .models import User
    return db.query(User).filter(User.email == email).first()

def get_user_by_id(db: Session, user_id: int):
    """
    Busca usuário por ID
    
    Args:
        db: Sessão do banco
        user_id: ID do usuário
        
    Returns:
        User ou None
    """
    from .models import User
    return db.query(User).filter(User.id == user_id).first()

def create_user(db: Session, user_data: dict):
    """
    Cria novo usuário
    
    Args:
        db: Sessão do banco
        user_data: Dados do usuário
        
    Returns:
        User criado
    """
    from .models import User
    
    user = User(**user_data)
    db.add(user)
    db.commit()
    db.refresh(user)
    
    return user

def update_user(db: Session, user_id: int, update_data: dict):
    """
    Atualiza dados do usuário
    
    Args:
        db: Sessão do banco
        user_id: ID do usuário
        update_data: Dados para atualizar
        
    Returns:
        User atualizado ou None
    """
    from .models import User
    
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        for key, value in update_data.items():
            if hasattr(user, key):
                setattr(user, key, value)
        
        db.commit()
        db.refresh(user)
    
    return user

def delete_user(db: Session, user_id: int) -> bool:
    """
    Remove usuário (soft delete - marca como inativo)
    
    Args:
        db: Sessão do banco
        user_id: ID do usuário
        
    Returns:
        True se removido com sucesso
    """
    from .models import User
    
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        user.is_active = False
        db.commit()
        return True
    
    return False

def log_login_attempt(db: Session, email: str, ip_address: str, success: bool, user_agent: str = None, failure_reason: str = None):
    """
    Registra tentativa de login
    
    Args:
        db: Sessão do banco
        email: Email do usuário
        ip_address: IP da tentativa
        success: Se foi bem-sucedida
        user_agent: User agent do browser
        failure_reason: Motivo da falha (se houver)
    """
    from .models import LoginAttempt
    
    attempt = LoginAttempt(
        email=email,
        ip_address=ip_address,
        success=success,
        user_agent=user_agent,
        failure_reason=failure_reason
    )
    
    db.add(attempt)
    db.commit()

def cleanup_old_data(db: Session, days: int = None):
    """
    Remove dados antigos do banco
    
    Args:
        db: Sessão do banco
        days: Dias para manter (usa configuração se não especificado)
    """
    from .models import LoginAttempt, RefreshToken
    from datetime import datetime, timedelta
    
    if days is None:
        days = settings.DATA_RETENTION_DAYS
    
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Remover tentativas de login antigas
    old_attempts = db.query(LoginAttempt).filter(LoginAttempt.attempted_at < cutoff_date).delete()
    
    # Remover refresh tokens expirados
    old_tokens = db.query(RefreshToken).filter(RefreshToken.expires_at < datetime.utcnow()).delete()
    
    db.commit()
    
    logger.info("Limpeza de dados concluída", 
                login_attempts_removed=old_attempts,
                refresh_tokens_removed=old_tokens)

