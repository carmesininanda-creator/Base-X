# Sistema de Design BazeX/QBeeX

## Visão Geral

Este documento define o sistema de design completo da BazeX/QBeeX, estabelecendo os padrões visuais, componentes e princípios de interação que garantem uma experiência de usuário revolucionária, inspirada na abordagem de Steve Jobs para design de produtos.

## Princípios Fundamentais

### 1. Simplicidade Intencional
- **Definição**: Eliminar o desnecessário, garantindo que o essencial seja imediatamente compreensível
- **Aplicação**: Cada elemento deve ter propósito claro e comunicação visual eficiente
- **Exemplo**: Dashboard que apresenta apenas informações relevantes ao contexto atual do usuário

### 2. Magia Reveladora
- **Definição**: Interações que surpreendem positivamente e educam sutilmente sobre capacidades
- **Aplicação**: Feedback que comunica o "como" sem sobrecarregar com detalhes técnicos
- **Exemplo**: Transições suaves que revelam relações entre diferentes tipos de dados

### 3. Conexão Personalizada
- **Definição**: Interface que se adapta ao usuário individual, não apenas demograficamente
- **Aplicação**: Elementos que criam sensação de familiaridade desde o primeiro uso
- **Exemplo**: Saudações e recomendações que refletem o histórico e preferências do usuário

### 4. Detalhes com Propósito
- **Definição**: Refinamento meticuloso focado em melhorar a experiência, não apenas a estética
- **Aplicação**: Consistência que cria confiança e previsibilidade
- **Exemplo**: Microinterações específicas para cada tipo de ação que comunicam seu resultado

### 5. Design Invisível
- **Definição**: A melhor interface é aquela que desaparece durante o uso
- **Aplicação**: Tecnologia complexa apresentada de forma humana e acessível
- **Exemplo**: IA preditiva que antecipa necessidades sem exigir configuração explícita

## Identidade Visual

### Paleta de Cores

#### Cores Primárias
- **Azul Turquesa (#00E5FF)** - Inovação e tecnologia
- **Azul Profundo (#0066CC)** - Confiabilidade e segurança
- **Verde Esmeralda (#00CC99)** - Crescimento e proatividade

#### Cores Secundárias
- **Cinza Escuro (#121212)** - Fundo principal
- **Cinza Médio (#2A2A2A)** - Elementos de interface secundários
- **Cinza Claro (#E0E0E0)** - Texto em fundos escuros

#### Cores de Acento
- **Âmbar (#FFC107)** - Alertas e notificações
- **Vermelho (#FF3B30)** - Erros e ações destrutivas
- **Verde Sucesso (#34C759)** - Confirmações e ações positivas

#### Gradientes
- **Gradiente Principal**: Linear, 135°, Azul Turquesa → Azul Profundo → Verde Esmeralda
- **Gradiente Secundário**: Linear, 135°, Azul Profundo → Verde Esmeralda
- **Gradiente de Acento**: Linear, 135°, Azul Turquesa → Âmbar

### Tipografia

#### Fonte Principal
- **Família**: SF Pro Display (ou equivalente)
- **Pesos**: Regular (400), Medium (500), Semibold (600), Bold (700)
- **Uso**: Todo o texto da interface

#### Fonte Secundária
- **Família**: Roboto Mono (ou equivalente)
- **Pesos**: Regular (400), Medium (500)
- **Uso**: Dados técnicos, métricas, código

#### Hierarquia Tipográfica
- **Título Principal**: 32px/40px, Bold
- **Título Secundário**: 24px/32px, Semibold
- **Subtítulo**: 20px/28px, Medium
- **Corpo**: 16px/24px, Regular
- **Texto Secundário**: 14px/20px, Regular
- **Texto Pequeno**: 12px/16px, Regular

### Iconografia

#### Estilo de Ícones
- **Traço**: 2px, arredondado
- **Estilo**: Outline com preenchimento mínimo
- **Tamanhos**: 16px, 24px, 32px
- **Cores**: Adaptáveis ao tema (claro/escuro)

#### Conjunto Principal
- **Navegação**: Home, Descobrir, Perfil, Configurações
- **Ações**: Adicionar, Editar, Excluir, Compartilhar
- **Comunicação**: Mensagem, Notificação, Chamada
- **Dados**: Gráfico, Lista, Tabela, Documento

#### Ícones Especiais
- **Logo BazeX**: Versão simplificada do "X" para favicon e ícone de app
- **Assistente**: Ícone personalizado para o assistente de IA
- **Privacidade**: Ícone personalizado para configurações de privacidade

## Componentes de Interface

### 1. Cards

#### Card Padrão
- **Dimensões**: Flexíveis, mínimo 280px de largura
- **Cantos**: Raio de 20px
- **Sombra**: 0 5px 15px rgba(0, 0, 0, 0.2)
- **Padding**: 25px
- **Fundo**: Cinza Médio (#2A2A2A)
- **Animação**: Elevação suave ao hover (translateY(-5px))

#### Card de Contexto
- **Herda**: Card Padrão
- **Adição**: Ícone de contexto no cabeçalho
- **Conteúdo**: Título, descrição, ação opcional
- **Estados**: Padrão, Hover, Ativo, Desativado

#### Card de Insight
- **Herda**: Card Padrão
- **Adição**: Indicador de relevância (0-3 pontos)
- **Conteúdo**: Título, descrição, métricas, ação
- **Estados**: Padrão, Expandido, Arquivado

### 2. Botões

#### Botão Primário
- **Altura**: 48px (grande), 40px (médio), 32px (pequeno)
- **Cantos**: Raio de 24px (grande), 20px (médio), 16px (pequeno)
- **Fundo**: Gradiente Principal
- **Texto**: Branco, Semibold
- **Padding**: 16px 32px (grande), 12px 24px (médio), 8px 16px (pequeno)
- **Sombra**: 0 5px 15px rgba(0, 229, 255, 0.3)
- **Animação**: Elevação ao hover (translateY(-3px))
- **Estados**: Padrão, Hover, Pressionado, Desativado, Carregando

#### Botão Secundário
- **Herda**: Botão Primário
- **Diferenças**: Fundo transparente, borda 2px com gradiente, texto com gradiente
- **Estados**: Padrão, Hover, Pressionado, Desativado

#### Botão de Ícone
- **Dimensões**: 48px x 48px (grande), 40px x 40px (médio), 32px x 32px (pequeno)
- **Forma**: Circular
- **Fundo**: Variável (primário, secundário, terciário)
- **Ícone**: 24px (grande), 20px (médio), 16px (pequeno)
- **Estados**: Padrão, Hover, Pressionado, Desativado

### 3. Campos de Entrada

#### Campo de Texto
- **Altura**: 48px (grande), 40px (médio)
- **Cantos**: Raio de 12px
- **Fundo**: Cinza Médio (#2A2A2A)
- **Texto**: Branco, 16px
- **Padding**: 12px 16px
- **Borda**: Nenhuma (padrão), 2px com gradiente (foco)
- **Estados**: Padrão, Foco, Preenchido, Erro, Desativado

#### Campo de Busca
- **Herda**: Campo de Texto
- **Adição**: Ícone de busca à esquerda
- **Animação**: Expansão suave ao foco
- **Estados**: Padrão, Foco, Com Resultados, Sem Resultados

#### Seletor
- **Herda**: Campo de Texto
- **Adição**: Ícone de seta à direita
- **Dropdown**: Lista de opções com mesma estilização
- **Estados**: Padrão, Aberto, Selecionado, Desativado

### 4. Controles

#### Toggle
- **Dimensões**: 60px x 30px
- **Forma**: Cápsula com raio 15px
- **Handle**: Círculo branco 26px
- **Fundo**: Cinza (desativado), Gradiente (ativado)
- **Animação**: Movimento suave do handle (300ms)
- **Estados**: Desativado, Ativado, Desativado+Hover, Ativado+Hover

#### Slider
- **Altura**: 6px
- **Forma**: Cápsula com raio 3px
- **Handle**: Círculo branco 20px
- **Fundo**: Cinza (vazio), Gradiente (preenchido)
- **Animação**: Expansão sutil do handle ao hover/arrastar
- **Estados**: Padrão, Hover, Arrastando, Desativado

#### Checkbox
- **Dimensões**: 24px x 24px
- **Forma**: Quadrado com raio 6px
- **Fundo**: Transparente (desmarcado), Gradiente (marcado)
- **Ícone**: Check branco quando marcado
- **Animação**: Fade + escala ao marcar/desmarcar
- **Estados**: Desmarcado, Marcado, Indeterminado, Desativado

### 5. Navegação

#### Barra de Navegação
- **Altura**: 64px
- **Fundo**: Cinza Escuro com blur (80% opacidade)
- **Itens**: 3-5 itens de navegação
- **Indicador Ativo**: Sublinhado com gradiente ou ícone colorido
- **Posição**: Inferior em mobile, lateral ou superior em desktop

#### Tabs
- **Altura**: 48px
- **Fundo**: Transparente
- **Indicador Ativo**: Linha inferior com gradiente (2px)
- **Texto**: 16px, Medium
- **Espaçamento**: 24px entre tabs
- **Estados**: Inativo, Ativo, Hover, Desativado

#### Breadcrumbs
- **Altura**: 24px
- **Separador**: Ícone de seta pequeno
- **Texto**: 14px, Regular
- **Último Item**: Medium, com gradiente
- **Estados**: Padrão, Hover, Atual

### 6. Feedback

#### Toast
- **Dimensões**: Auto x 48px
- **Cantos**: Raio de 12px
- **Fundo**: Cinza Escuro (#121212)
- **Texto**: Branco, 14px
- **Ícone**: Opcional, à esquerda
- **Duração**: 3 segundos (padrão)
- **Animação**: Fade + slide de baixo
- **Variantes**: Informação, Sucesso, Alerta, Erro

#### Loader
- **Dimensões**: 48px (grande), 32px (médio), 24px (pequeno)
- **Estilo**: Círculo com gradiente animado
- **Animação**: Rotação contínua (1.5s)
- **Variantes**: Determinado (com progresso), Indeterminado

#### Dialog
- **Dimensões**: Máximo 90% da viewport
- **Cantos**: Raio de 24px
- **Fundo**: Cinza Escuro (#121212)
- **Sombra**: 0 10px 30px rgba(0, 0, 0, 0.4)
- **Animação**: Fade + escala ao abrir/fechar
- **Estrutura**: Cabeçalho, Conteúdo, Ações
- **Overlay**: Preto com 60% de opacidade

## Padrões de Interação

### 1. Navegação

#### Gestos
- **Swipe Horizontal**: Navegação entre páginas relacionadas
- **Swipe Vertical**: Scroll de conteúdo
- **Pinch**: Zoom em conteúdo visual
- **Tap Duplo**: Expandir/colapsar conteúdo
- **Pressionar e Segurar**: Ações contextuais

#### Transições
- **Página para Página**: Slide horizontal (300ms)
- **Modal**: Fade + escala (250ms)
- **Expansão de Conteúdo**: Accordion suave (200ms)
- **Carregamento de Dados**: Skeleton loading + fade

### 2. Feedback

#### Visual
- **Hover**: Sutis mudanças de escala ou elevação
- **Tap/Click**: Flash de highlight (100ms)
- **Sucesso**: Animação de check ou pulso verde
- **Erro**: Shake horizontal sutil (3 oscilações, 300ms)
- **Processamento**: Loader com gradiente animado

#### Háptico
- **Tap Padrão**: Feedback leve
- **Confirmação**: Feedback médio
- **Erro**: Feedback forte
- **Deslizar**: Feedback sutil durante o gesto

### 3. Microinterações

#### Botões
- **Hover**: Elevação sutil + aumento de sombra
- **Pressionar**: Escala para 95% do tamanho
- **Liberar**: Animação de onda circular (ripple)
- **Desativado**: Fade para 50% de opacidade

#### Campos
- **Foco**: Borda com gradiente aparece com animação
- **Validação**: Ícone de check aparece com fade
- **Erro**: Shake sutil + borda vermelha
- **Autocompletar**: Fade suave das sugestões

#### Notificações
- **Chegada**: Slide de cima + som sutil
- **Ação**: Highlight momentâneo
- **Saída**: Fade out ou slide para lado
- **Agrupamento**: Empilhamento com indicador de quantidade

### 4. Animações de Estado

#### Carregamento
- **Inicial**: Logo com pulso sutil
- **Dados**: Skeleton screens com gradiente animado
- **Transição**: Fade cruzado entre estados
- **Conclusão**: Fade in do conteúdo final

#### Vazio/Erro
- **Estado Vazio**: Ilustração minimalista + mensagem
- **Erro**: Ícone com animação + mensagem + ação
- **Reconexão**: Indicador de tentativa com contagem
- **Recuperação**: Transição suave para estado normal

## Responsividade

### Breakpoints
- **Mobile**: 320px - 767px
- **Tablet**: 768px - 1023px
- **Desktop**: 1024px - 1439px
- **Wide**: 1440px+

### Adaptações por Dispositivo

#### Mobile
- Navegação inferior
- Cards em coluna única
- Botões de ação flutuantes
- Menus em tela cheia

#### Tablet
- Navegação inferior ou lateral
- Grid de 2 colunas para cards
- Painéis laterais deslizantes
- Menus em popover

#### Desktop
- Navegação superior ou lateral
- Grid de 3+ colunas para cards
- Layout multi-painel
- Menus em dropdown

#### Wide
- Layout expandido
- Painéis múltiplos simultâneos
- Visualizações avançadas de dados
- Atalhos de teclado visíveis

## Acessibilidade

### Contraste e Legibilidade
- **Contraste Mínimo**: 4.5:1 para texto normal, 3:1 para texto grande
- **Tamanho Mínimo**: 16px para texto de corpo
- **Espaçamento**: Mínimo 1.5x para entrelinhas
- **Modo Alto Contraste**: Disponível via configurações

### Navegação Assistiva
- **Foco Visível**: Indicador claro para navegação por teclado
- **Ordem de Tab**: Lógica e consistente
- **Skip Links**: Para pular para conteúdo principal
- **ARIA Labels**: Em todos os elementos interativos

### Personalização
- **Tamanho de Texto**: Ajustável sem quebrar layout
- **Densidade**: Opções de densidade normal e compacta
- **Animações**: Opção para reduzir ou desativar
- **Contraste**: Ajustável via configurações

## Implementação Técnica

### CSS
- **Metodologia**: BEM (Block Element Modifier)
- **Variáveis**: Uso extensivo de CSS variables
- **Dark Mode**: Implementado via variáveis CSS
- **Prefixos**: Autoprefixer para compatibilidade

### JavaScript
- **Animações**: Preferencialmente CSS, JS para complexas
- **Interações**: Event listeners com debounce/throttle
- **Acessibilidade**: Suporte completo a keyboard e screen readers
- **Performance**: Otimização para 60fps em todas animações

### Assets
- **Ícones**: SVG com possibilidade de colorização
- **Imagens**: WebP com fallback para JPEG/PNG
- **Fontes**: WOFF2 com subsetting para performance
- **Ilustrações**: SVG para escalabilidade

## Evolução do Sistema

### Versionamento
- **Nomenclatura**: Semântica (Major.Minor.Patch)
- **Changelog**: Documentação detalhada de mudanças
- **Deprecação**: Aviso prévio de 2 versões antes de remover

### Processo de Design
- **Exploração**: Sketches e protótipos de baixa fidelidade
- **Refinamento**: Protótipos de alta fidelidade
- **Validação**: Testes com usuários reais
- **Implementação**: Desenvolvimento com QA contínuo

### Métricas de Sucesso
- **Usabilidade**: Tempo para completar tarefas
- **Engajamento**: Frequência e duração de uso
- **Satisfação**: NPS e feedback qualitativo
- **Acessibilidade**: Conformidade com WCAG 2.1 AA
