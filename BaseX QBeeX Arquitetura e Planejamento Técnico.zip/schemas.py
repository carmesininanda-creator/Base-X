"""
Schemas Pydantic para validação de dados
Autor: Maya Patel - Backend Developer
"""

from pydantic import BaseModel, EmailStr, validator
from typing import Optional
from datetime import datetime
import re

class UserBase(BaseModel):
    """Schema base para usuário"""
    email: EmailStr
    full_name: str
    is_active: bool = True
    timezone: str = "UTC"
    language: str = "pt-BR"

class UserCreate(BaseModel):
    """Schema para criação de usuário"""
    email: EmailStr
    password: str
    full_name: str
    timezone: str = "UTC"
    language: str = "pt-BR"
    privacy_level: str = "standard"
    data_sharing_consent: bool = False
    marketing_consent: bool = False
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Senha deve ter pelo menos 8 caracteres')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Senha deve conter pelo menos uma letra maiúscula')
        if not re.search(r'[a-z]', v):
            raise ValueError('Senha deve conter pelo menos uma letra minúscula')
        if not re.search(r'\d', v):
            raise ValueError('Senha deve conter pelo menos um número')
        if not re.search(r'[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]', v):
            raise ValueError('Senha deve conter pelo menos um caractere especial')
        return v
    
    @validator('full_name')
    def validate_full_name(cls, v):
        if len(v.strip()) < 2:
            raise ValueError('Nome deve ter pelo menos 2 caracteres')
        if not re.match(r'^[a-zA-ZÀ-ÿ\s]+$', v):
            raise ValueError('Nome deve conter apenas letras e espaços')
        return v.strip()
    
    @validator('privacy_level')
    def validate_privacy_level(cls, v):
        if v not in ['minimal', 'standard', 'maximum']:
            raise ValueError('Nível de privacidade deve ser: minimal, standard ou maximum')
        return v
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "usuario@exemplo.com",
                "password": "MinhaSenh@123",
                "full_name": "João Silva",
                "timezone": "America/Sao_Paulo",
                "language": "pt-BR",
                "privacy_level": "standard",
                "data_sharing_consent": False,
                "marketing_consent": False
            }
        }

class UserLogin(BaseModel):
    """Schema para login de usuário"""
    email: EmailStr
    password: str
    remember_me: bool = False
    device_info: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "usuario@exemplo.com",
                "password": "MinhaSenh@123",
                "remember_me": False,
                "device_info": "Chrome 119.0 on Windows 10"
            }
        }

class UserResponse(BaseModel):
    """Schema de resposta de usuário"""
    id: int
    email: str
    full_name: str
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    timezone: str
    language: str
    privacy_level: str
    
    class Config:
        from_attributes = True

class UserUpdate(BaseModel):
    """Schema para atualização de usuário"""
    full_name: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    timezone: Optional[str] = None
    language: Optional[str] = None
    privacy_level: Optional[str] = None
    data_sharing_consent: Optional[bool] = None
    marketing_consent: Optional[bool] = None
    
    @validator('full_name')
    def validate_full_name(cls, v):
        if v is not None:
            if len(v.strip()) < 2:
                raise ValueError('Nome deve ter pelo menos 2 caracteres')
            if not re.match(r'^[a-zA-ZÀ-ÿ\s]+$', v):
                raise ValueError('Nome deve conter apenas letras e espaços')
            return v.strip()
        return v
    
    @validator('bio')
    def validate_bio(cls, v):
        if v is not None and len(v) > 500:
            raise ValueError('Bio deve ter no máximo 500 caracteres')
        return v
    
    @validator('privacy_level')
    def validate_privacy_level(cls, v):
        if v is not None and v not in ['minimal', 'standard', 'maximum']:
            raise ValueError('Nível de privacidade deve ser: minimal, standard ou maximum')
        return v

class Token(BaseModel):
    """Schema de resposta de token"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # segundos
    
class TokenRefresh(BaseModel):
    """Schema para refresh de token"""
    refresh_token: str

class PasswordChange(BaseModel):
    """Schema para mudança de senha"""
    current_password: str
    new_password: str
    
    @validator('new_password')
    def validate_new_password(cls, v):
        if len(v) < 8:
            raise ValueError('Nova senha deve ter pelo menos 8 caracteres')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Nova senha deve conter pelo menos uma letra maiúscula')
        if not re.search(r'[a-z]', v):
            raise ValueError('Nova senha deve conter pelo menos uma letra minúscula')
        if not re.search(r'\d', v):
            raise ValueError('Nova senha deve conter pelo menos um número')
        if not re.search(r'[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]', v):
            raise ValueError('Nova senha deve conter pelo menos um caractere especial')
        return v

class PasswordReset(BaseModel):
    """Schema para solicitação de reset de senha"""
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    """Schema para confirmação de reset de senha"""
    token: str
    new_password: str
    
    @validator('new_password')
    def validate_new_password(cls, v):
        if len(v) < 8:
            raise ValueError('Nova senha deve ter pelo menos 8 caracteres')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Nova senha deve conter pelo menos uma letra maiúscula')
        if not re.search(r'[a-z]', v):
            raise ValueError('Nova senha deve conter pelo menos uma letra minúscula')
        if not re.search(r'\d', v):
            raise ValueError('Nova senha deve conter pelo menos um número')
        if not re.search(r'[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]', v):
            raise ValueError('Nova senha deve conter pelo menos um caractere especial')
        return v

class UserStats(BaseModel):
    """Schema para estatísticas do usuário"""
    total_logins: int
    last_login: Optional[datetime]
    account_age_days: int
    active_sessions: int

class SecurityEvent(BaseModel):
    """Schema para eventos de segurança"""
    event_type: str
    timestamp: datetime
    ip_address: str
    user_agent: Optional[str]
    details: Optional[dict] = None

class ApiResponse(BaseModel):
    """Schema padrão para respostas da API"""
    success: bool
    message: str
    data: Optional[dict] = None
    errors: Optional[list] = None

class HealthCheck(BaseModel):
    """Schema para health check"""
    status: str
    service: str
    version: str
    timestamp: datetime
    database: bool
    redis: bool

class TokenValidation(BaseModel):
    """Schema para validação de token"""
    valid: bool
    user_id: Optional[int] = None
    email: Optional[str] = None
    is_active: Optional[bool] = None
    expires_at: Optional[datetime] = None

