"""
BazeX AI-Core Service - Advanced Version
Autor: Dr. Nova Singh - AI/ML Scientist
Descrição: Serviço principal de IA com deep learning, predições avançadas e aprendizado contínuo
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any, Union
import asyncio
import structlog
from datetime import datetime
import json
import numpy as np
from contextlib import asynccontextmanager

from .deep_learning_engine import DeepLearningEngine
from .advanced_predictions import AdvancedPredictionSystem, PredictionType, PredictionResult

# Configurar logging estruturado
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# Instâncias globais dos sistemas de IA
deep_learning_engine = None
prediction_system = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia ciclo de vida da aplicação"""
    global deep_learning_engine, prediction_system
    
    logger.info("🚀 Inicializando BazeX AI-Core Service Advanced...")
    
    try:
        # Inicializar sistemas de IA
        deep_learning_engine = DeepLearningEngine()
        prediction_system = AdvancedPredictionSystem()
        
        await prediction_system.initialize()
        
        logger.info("✅ AI-Core Service Advanced inicializado com sucesso!")
        
        yield
        
    except Exception as e:
        logger.error(f"❌ Erro na inicialização: {str(e)}")
        raise
    finally:
        logger.info("🔄 Finalizando AI-Core Service...")

# Criar aplicação FastAPI
app = FastAPI(
    title="BazeX AI-Core Service Advanced",
    description="Serviço avançado de IA com deep learning e predições complexas",
    version="2.0.0",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modelos Pydantic para requests/responses

class UserContextData(BaseModel):
    """Dados contextuais do usuário"""
    user_id: str
    timestamp: datetime = Field(default_factory=datetime.now)
    location: Optional[Dict[str, Any]] = None
    activity_data: Optional[Dict[str, Any]] = None
    environmental_data: Optional[Dict[str, Any]] = None
    emotional_state: Optional[Dict[str, Any]] = None
    physiological_data: Optional[Dict[str, Any]] = None
    social_context: Optional[Dict[str, Any]] = None
    text_inputs: Optional[List[str]] = None
    historical_patterns: Optional[Dict[str, Any]] = None

class PredictionRequest(BaseModel):
    """Request para predições"""
    user_data: UserContextData
    prediction_types: List[str] = Field(default=["behavior"])
    prediction_horizon: Optional[str] = "24h"
    include_explanations: bool = True
    include_recommendations: bool = True

class BehaviorPredictionResponse(BaseModel):
    """Response para predições comportamentais"""
    prediction_id: str
    predictions: List[Dict[str, Any]]
    confidence_score: float
    confidence_level: str
    model_version: str
    timestamp: datetime
    explanation: Optional[str] = None
    recommendations: Optional[List[str]] = None
    metadata: Dict[str, Any]

# Dependency para verificar se os sistemas estão inicializados
async def get_prediction_system():
    if prediction_system is None:
        raise HTTPException(status_code=503, detail="Sistema de predições não inicializado")
    return prediction_system

async def get_deep_learning_engine():
    if deep_learning_engine is None:
        raise HTTPException(status_code=503, detail="Deep learning engine não inicializado")
    return deep_learning_engine

# Endpoints principais

@app.get("/", response_model=Dict[str, str])
async def root():
    """Endpoint raiz"""
    return {
        "service": "BazeX AI-Core Service Advanced",
        "version": "2.0.0",
        "status": "operational",
        "description": "Serviço avançado de IA com deep learning e predições complexas"
    }

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    try:
        models_loaded = prediction_system is not None and deep_learning_engine is not None
        
        system_metrics = {}
        if prediction_system:
            system_metrics = prediction_system.system_metrics
        
        return {
            "status": "healthy" if models_loaded else "initializing",
            "version": "2.0.0",
            "uptime": "running",
            "models_loaded": models_loaded,
            "system_metrics": system_metrics,
            "timestamp": datetime.now()
        }
    except Exception as e:
        logger.error(f"❌ Erro no health check: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/behavior", response_model=BehaviorPredictionResponse)
async def predict_behavior(
    request: PredictionRequest,
    prediction_system: AdvancedPredictionSystem = Depends(get_prediction_system)
):
    """
    Predição comportamental avançada usando deep learning
    
    Analisa padrões comportamentais complexos e prediz ações futuras
    com alta precisão usando redes neurais profundas.
    """
    try:
        logger.info(f"🧠 Iniciando predição comportamental para usuário {request.user_data.user_id}")
        
        # Converter dados para formato interno
        user_data = request.user_data.dict()
        
        # Executar predição comportamental
        results = await prediction_system.predict_comprehensive(
            user_data, 
            [PredictionType.BEHAVIOR]
        )
        
        behavior_result = results.get("behavior")
        if not behavior_result:
            raise HTTPException(status_code=500, detail="Falha na predição comportamental")
        
        response = BehaviorPredictionResponse(
            prediction_id=behavior_result.prediction_id,
            predictions=behavior_result.predictions,
            confidence_score=behavior_result.confidence_score,
            confidence_level=behavior_result.confidence_level.value,
            model_version=behavior_result.model_version,
            timestamp=behavior_result.timestamp,
            explanation=behavior_result.explanation if request.include_explanations else None,
            recommendations=behavior_result.recommendations if request.include_recommendations else None,
            metadata=behavior_result.metadata
        )
        
        logger.info(f"✅ Predição comportamental concluída com confiança: {behavior_result.confidence_score:.3f}")
        return response
        
    except Exception as e:
        logger.error(f"❌ Erro na predição comportamental: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/comprehensive")
async def predict_comprehensive(
    request: PredictionRequest,
    prediction_system: AdvancedPredictionSystem = Depends(get_prediction_system)
):
    """
    Predição abrangente usando múltiplos tipos de análise
    
    Combina predições comportamentais, detecção de anomalias,
    análise emocional e predições contextuais.
    """
    try:
        logger.info(f"🔮 Iniciando predição abrangente para usuário {request.user_data.user_id}")
        
        # Converter tipos de predição
        prediction_types = []
        for pred_type_str in request.prediction_types:
            try:
                prediction_types.append(PredictionType(pred_type_str))
            except ValueError:
                logger.warning(f"Tipo de predição inválido: {pred_type_str}")
        
        if not prediction_types:
            prediction_types = [PredictionType.BEHAVIOR]
        
        # Executar predições
        user_data = request.user_data.dict()
        results = await prediction_system.predict_comprehensive(user_data, prediction_types)
        
        # Converter resultados para formato de resposta
        response_data = {}
        for pred_type, result in results.items():
            response_data[pred_type] = {
                "prediction_id": result.prediction_id,
                "predictions": result.predictions,
                "confidence_score": result.confidence_score,
                "confidence_level": result.confidence_level.value,
                "model_version": result.model_version,
                "timestamp": result.timestamp.isoformat(),
                "metadata": result.metadata
            }
            
            if request.include_explanations and result.explanation:
                response_data[pred_type]["explanation"] = result.explanation
            
            if request.include_recommendations and result.recommendations:
                response_data[pred_type]["recommendations"] = result.recommendations
        
        logger.info(f"✅ Predição abrangente concluída com {len(results)} tipos")
        return response_data
        
    except Exception as e:
        logger.error(f"❌ Erro na predição abrangente: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/test/prediction")
async def test_prediction():
    """
    Endpoint de teste para predições
    
    Executa uma predição de teste com dados simulados
    para verificar se todos os sistemas estão funcionando.
    """
    try:
        logger.info("🧪 Executando teste de predição")
        
        # Dados de teste
        test_user_data = UserContextData(
            user_id="test_user",
            location={"name": "home", "type": "residential"},
            activity_data={"current_activity": "working", "duration": 120},
            emotional_state={"mood": "focused", "energy_level": 0.8}
        )
        
        test_request = PredictionRequest(
            user_data=test_user_data,
            prediction_types=["behavior", "anomaly"],
            include_explanations=True,
            include_recommendations=True
        )
        
        # Executar predição de teste
        result = await predict_comprehensive(test_request, prediction_system)
        
        logger.info("✅ Teste de predição concluído com sucesso")
        return {
            "test_status": "success",
            "test_results": result,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"❌ Erro no teste de predição: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    
    logger.info("🚀 Iniciando BazeX AI-Core Service Advanced...")
    
    uvicorn.run(
        "main_advanced:app",
        host="0.0.0.0",
        port=8001,
        reload=True,
        log_level="info"
    )

