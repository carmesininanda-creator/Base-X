"""
BazeX Auth Service
Autor: Maya Patel - Backend Developer
"""

__version__ = "1.0.0"
__author__ = "Maya Patel"
__email__ = "maya@bazex.app"

