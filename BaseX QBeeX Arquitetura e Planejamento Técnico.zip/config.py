"""
Configurações do Auth Service
Autor: Maya Patel - Backend Developer
"""

from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    """Configurações da aplicação"""
    
    # Configurações básicas
    APP_NAME: str = "BazeX Auth Service"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    
    # Configurações de segurança
    SECRET_KEY: str = "bazex-super-secret-key-change-in-production"
    REFRESH_SECRET_KEY: str = "bazex-refresh-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    PASSWORD_RESET_TOKEN_EXPIRE_HOURS: int = 1
    
    # Configurações de banco de dados
    DATABASE_URL: str = "postgresql://bazex_user:bazex_password@localhost:5432/bazex_auth"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # Configurações do Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_PASSWORD: str = ""
    REDIS_DB: int = 0
    REDIS_MAX_CONNECTIONS: int = 10
    
    # Configurações de CORS
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",  # Frontend development
        "http://localhost:8080",  # Frontend production
        "https://bazex.app",      # Production domain
        "https://www.bazex.app"   # Production domain with www
    ]
    
    ALLOWED_HOSTS: List[str] = [
        "localhost",
        "127.0.0.1",
        "auth-service",
        "bazex.app",
        "www.bazex.app"
    ]
    
    # Configurações de rate limiting
    RATE_LIMIT_LOGIN: str = "5/minute"  # 5 tentativas por minuto
    RATE_LIMIT_REGISTER: str = "3/minute"  # 3 registros por minuto
    RATE_LIMIT_PASSWORD_RESET: str = "2/minute"  # 2 resets por minuto
    
    # Configurações de email (para futuras implementações)
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_TLS: bool = True
    
    # Configurações de logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    # Configurações de monitoramento
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090
    
    # Configurações de segurança avançada
    ENABLE_ACCOUNT_LOCKOUT: bool = True
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 15
    
    # Configurações de sessão
    SESSION_TIMEOUT_MINUTES: int = 60
    REMEMBER_ME_DAYS: int = 30
    
    # Configurações de compliance
    ENABLE_AUDIT_LOG: bool = True
    DATA_RETENTION_DAYS: int = 365
    
    # Configurações de desenvolvimento
    ENABLE_SWAGGER: bool = True
    ENABLE_REDOC: bool = True
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

# Instância global das configurações
settings = Settings()

# Configurações específicas por ambiente
class DevelopmentSettings(Settings):
    """Configurações para desenvolvimento"""
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"
    
    # Banco de dados local
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/bazex_auth_dev"
    
    # Redis local
    REDIS_URL: str = "redis://localhost:6379/1"
    
    # CORS mais permissivo para desenvolvimento
    ALLOWED_ORIGINS: List[str] = ["*"]

class TestingSettings(Settings):
    """Configurações para testes"""
    DEBUG: bool = True
    
    # Banco de dados de teste
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/bazex_auth_test"
    
    # Redis de teste
    REDIS_URL: str = "redis://localhost:6379/2"
    
    # Tokens com expiração mais rápida para testes
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1
    REFRESH_TOKEN_EXPIRE_DAYS: int = 1

class ProductionSettings(Settings):
    """Configurações para produção"""
    DEBUG: bool = False
    LOG_LEVEL: str = "WARNING"
    
    # Configurações de segurança mais rigorosas
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 3
    
    # Rate limiting mais restritivo
    RATE_LIMIT_LOGIN: str = "3/minute"
    RATE_LIMIT_REGISTER: str = "1/minute"
    
    # Configurações de produção devem vir de variáveis de ambiente
    SECRET_KEY: str = os.getenv("SECRET_KEY", "")
    REFRESH_SECRET_KEY: str = os.getenv("REFRESH_SECRET_KEY", "")
    DATABASE_URL: str = os.getenv("DATABASE_URL", "")
    REDIS_URL: str = os.getenv("REDIS_URL", "")

def get_settings() -> Settings:
    """
    Retorna as configurações baseadas no ambiente
    """
    environment = os.getenv("ENVIRONMENT", "development").lower()
    
    if environment == "production":
        return ProductionSettings()
    elif environment == "testing":
        return TestingSettings()
    else:
        return DevelopmentSettings()

# Configurações globais baseadas no ambiente
settings = get_settings()

# Validações de configuração
def validate_settings():
    """Valida as configurações críticas"""
    errors = []
    
    if not settings.SECRET_KEY or settings.SECRET_KEY == "bazex-super-secret-key-change-in-production":
        if os.getenv("ENVIRONMENT", "development").lower() == "production":
            errors.append("SECRET_KEY deve ser definida em produção")
    
    if not settings.DATABASE_URL:
        errors.append("DATABASE_URL é obrigatória")
    
    if not settings.REDIS_URL:
        errors.append("REDIS_URL é obrigatória")
    
    if settings.ACCESS_TOKEN_EXPIRE_MINUTES < 1:
        errors.append("ACCESS_TOKEN_EXPIRE_MINUTES deve ser pelo menos 1")
    
    if settings.REFRESH_TOKEN_EXPIRE_DAYS < 1:
        errors.append("REFRESH_TOKEN_EXPIRE_DAYS deve ser pelo menos 1")
    
    if errors:
        raise ValueError(f"Configurações inválidas: {', '.join(errors)}")

# Validar configurações na inicialização
validate_settings()

