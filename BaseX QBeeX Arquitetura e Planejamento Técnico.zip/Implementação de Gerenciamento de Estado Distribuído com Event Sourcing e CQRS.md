# Implementação de Gerenciamento de Estado Distribuído com Event Sourcing e CQRS

## Visão Geral da Solução

Para garantir consistência de estado e operações offline robustas na plataforma BazeX/QBeeX, implementaremos um sistema de gerenciamento de estado distribuído baseado nos padrões Event Sourcing e Command Query Responsibility Segregation (CQRS). Esta abordagem permitirá que o sistema mantenha um histórico completo de todas as mudanças de estado, facilitando a sincronização entre dispositivos após períodos offline e proporcionando uma base sólida para auditoria e análise de dados.

## Princípios de Design

1. **Event Sourcing**: O estado do sistema é determinado pela sequência de eventos que ocorreram, não apenas pelo estado atual.
2. **CQRS**: Separação entre operações de leitura (queries) e escrita (commands), permitindo otimização independente.
3. **Idempotência**: Comandos podem ser processados múltiplas vezes sem efeitos colaterais indesejados.
4. **Consistência Eventual**: O sistema eventualmente converge para um estado consistente, mesmo com operações offline.
5. **Rastreabilidade**: Todas as mudanças são rastreáveis até os eventos que as causaram.

## Componentes da Solução

### 1. Modelo de Domínio e Eventos

Definição das entidades de domínio e eventos relacionados.

```typescript
// src/domain/events/base-event.ts

export interface EventMetadata {
  eventId: string;
  eventType: string;
  aggregateId: string;
  aggregateType: string;
  version: number;
  timestamp: number;
  userId?: string;
  deviceId?: string;
  correlationId?: string;
  causationId?: string;
}

export interface DomainEvent<T = any> {
  metadata: EventMetadata;
  data: T;
}

export abstract class BaseDomainEvent<T = any> implements DomainEvent<T> {
  public readonly metadata: EventMetadata;
  public readonly data: T;

  constructor(
    aggregateId: string,
    aggregateType: string,
    data: T,
    metadata?: Partial<EventMetadata>
  ) {
    this.data = data;
    this.metadata = {
      eventId: metadata?.eventId || crypto.randomUUID(),
      eventType: this.constructor.name,
      aggregateId,
      aggregateType,
      version: metadata?.version || 1,
      timestamp: metadata?.timestamp || Date.now(),
      userId: metadata?.userId,
      deviceId: metadata?.deviceId,
      correlationId: metadata?.correlationId,
      causationId: metadata?.causationId,
    };
  }

  public toJSON(): { metadata: EventMetadata; data: T } {
    return {
      metadata: this.metadata,
      data: this.data,
    };
  }
}
```

### 2. Agregados e Entidades

Implementação de agregados que encapsulam regras de negócio e gerenciam eventos.

```typescript
// src/domain/aggregates/aggregate-root.ts

import { BaseDomainEvent, DomainEvent } from '../events/base-event';

export abstract class AggregateRoot<T = any> {
  protected _id: string;
  protected _version: number = 0;
  protected _state: T;
  protected _uncommittedEvents: DomainEvent[] = [];

  constructor(id: string, initialState: T) {
    this._id = id;
    this._state = initialState;
  }

  get id(): string {
    return this._id;
  }

  get version(): number {
    return this._version;
  }

  get state(): T {
    return { ...this._state }; // Return a copy to prevent direct mutation
  }

  get uncommittedEvents(): DomainEvent[] {
    return [...this._uncommittedEvents];
  }

  public markEventsAsCommitted(): void {
    this._uncommittedEvents = [];
  }

  protected applyEvent(event: DomainEvent): void {
    this._state = this.apply(event, this._state);
    this._version = event.metadata.version;
  }

  protected abstract apply(event: DomainEvent, state: T): T;

  protected raiseEvent<E extends BaseDomainEvent>(event: E): void {
    // Update version
    event.metadata.version = this._version + 1;
    
    // Apply the event to update the state
    this.applyEvent(event);
    
    // Add to uncommitted events
    this._uncommittedEvents.push(event);
  }

  public loadFromHistory(events: DomainEvent[]): void {
    // Sort events by version to ensure correct order
    events.sort((a, b) => a.metadata.version - b.metadata.version);
    
    for (const event of events) {
      this.applyEvent(event);
    }
  }
}

// src/domain/aggregates/user-profile-aggregate.ts

import { AggregateRoot } from './aggregate-root';
import { DomainEvent } from '../events/base-event';
import { 
  UserProfileCreated, 
  UserProfileUpdated, 
  PreferenceAdded, 
  PreferenceRemoved 
} from '../events/user-profile-events';

export interface UserProfileState {
  id: string;
  name: string;
  email: string;
  preferences: Record<string, any>;
  createdAt: number;
  updatedAt: number;
}

export class UserProfileAggregate extends AggregateRoot<UserProfileState> {
  constructor(id: string) {
    super(id, {
      id,
      name: '',
      email: '',
      preferences: {},
      createdAt: 0,
      updatedAt: 0
    });
  }

  public createProfile(name: string, email: string, userId: string, deviceId?: string): void {
    if (this._version > 0) {
      throw new Error('Profile already exists');
    }

    this.raiseEvent(
      new UserProfileCreated(
        this._id,
        { name, email },
        { userId, deviceId }
      )
    );
  }

  public updateProfile(name?: string, email?: string, userId: string, deviceId?: string): void {
    if (this._version === 0) {
      throw new Error('Profile does not exist');
    }

    const updates: { name?: string; email?: string } = {};
    if (name !== undefined && name !== this._state.name) updates.name = name;
    if (email !== undefined && email !== this._state.email) updates.email = email;

    if (Object.keys(updates).length === 0) {
      return; // No changes
    }

    this.raiseEvent(
      new UserProfileUpdated(
        this._id,
        updates,
        { userId, deviceId }
      )
    );
  }

  public addPreference(key: string, value: any, userId: string, deviceId?: string): void {
    if (this._version === 0) {
      throw new Error('Profile does not exist');
    }

    if (this._state.preferences[key] === value) {
      return; // No change
    }

    this.raiseEvent(
      new PreferenceAdded(
        this._id,
        { key, value },
        { userId, deviceId }
      )
    );
  }

  public removePreference(key: string, userId: string, deviceId?: string): void {
    if (this._version === 0) {
      throw new Error('Profile does not exist');
    }

    if (!(key in this._state.preferences)) {
      return; // Preference doesn't exist
    }

    this.raiseEvent(
      new PreferenceRemoved(
        this._id,
        { key },
        { userId, deviceId }
      )
    );
  }

  protected apply(event: DomainEvent, state: UserProfileState): UserProfileState {
    const newState = { ...state };
    
    switch (event.metadata.eventType) {
      case 'UserProfileCreated':
        return {
          ...newState,
          name: event.data.name,
          email: event.data.email,
          createdAt: event.metadata.timestamp,
          updatedAt: event.metadata.timestamp
        };
      
      case 'UserProfileUpdated':
        return {
          ...newState,
          ...(event.data.name !== undefined ? { name: event.data.name } : {}),
          ...(event.data.email !== undefined ? { email: event.data.email } : {}),
          updatedAt: event.metadata.timestamp
        };
      
      case 'PreferenceAdded':
        return {
          ...newState,
          preferences: {
            ...newState.preferences,
            [event.data.key]: event.data.value
          },
          updatedAt: event.metadata.timestamp
        };
      
      case 'PreferenceRemoved': {
        const { [event.data.key]: _, ...remainingPreferences } = newState.preferences;
        return {
          ...newState,
          preferences: remainingPreferences,
          updatedAt: event.metadata.timestamp
        };
      }
      
      default:
        return state;
    }
  }
}
```

### 3. Eventos de Domínio Específicos

Implementação de eventos específicos do domínio.

```typescript
// src/domain/events/user-profile-events.ts

import { BaseDomainEvent } from './base-event';

export class UserProfileCreated extends BaseDomainEvent<{
  name: string;
  email: string;
}> {
  constructor(
    aggregateId: string,
    data: { name: string; email: string },
    metadata?: { userId?: string; deviceId?: string }
  ) {
    super(aggregateId, 'UserProfile', data, metadata);
  }
}

export class UserProfileUpdated extends BaseDomainEvent<{
  name?: string;
  email?: string;
}> {
  constructor(
    aggregateId: string,
    data: { name?: string; email?: string },
    metadata?: { userId?: string; deviceId?: string }
  ) {
    super(aggregateId, 'UserProfile', data, metadata);
  }
}

export class PreferenceAdded extends BaseDomainEvent<{
  key: string;
  value: any;
}> {
  constructor(
    aggregateId: string,
    data: { key: string; value: any },
    metadata?: { userId?: string; deviceId?: string }
  ) {
    super(aggregateId, 'UserProfile', data, metadata);
  }
}

export class PreferenceRemoved extends BaseDomainEvent<{
  key: string;
}> {
  constructor(
    aggregateId: string,
    data: { key: string },
    metadata?: { userId?: string; deviceId?: string }
  ) {
    super(aggregateId, 'UserProfile', data, metadata);
  }
}
```

### 4. Comandos e Manipuladores de Comandos

Implementação do padrão Command para operações de escrita.

```typescript
// src/domain/commands/base-command.ts

export interface CommandMetadata {
  commandId: string;
  timestamp: number;
  userId?: string;
  deviceId?: string;
  correlationId?: string;
}

export interface Command<T = any> {
  metadata: CommandMetadata;
  data: T;
}

export abstract class BaseCommand<T = any> implements Command<T> {
  public readonly metadata: CommandMetadata;
  public readonly data: T;

  constructor(data: T, metadata?: Partial<CommandMetadata>) {
    this.data = data;
    this.metadata = {
      commandId: metadata?.commandId || crypto.randomUUID(),
      timestamp: metadata?.timestamp || Date.now(),
      userId: metadata?.userId,
      deviceId: metadata?.deviceId,
      correlationId: metadata?.correlationId,
    };
  }
}

// src/domain/commands/user-profile-commands.ts

import { BaseCommand } from './base-command';

export class CreateUserProfileCommand extends BaseCommand<{
  profileId: string;
  name: string;
  email: string;
}> {}

export class UpdateUserProfileCommand extends BaseCommand<{
  profileId: string;
  name?: string;
  email?: string;
}> {}

export class AddPreferenceCommand extends BaseCommand<{
  profileId: string;
  key: string;
  value: any;
}> {}

export class RemovePreferenceCommand extends BaseCommand<{
  profileId: string;
  key: string;
}> {}

// src/application/command-handlers/user-profile-command-handlers.ts

import { 
  CreateUserProfileCommand, 
  UpdateUserProfileCommand,
  AddPreferenceCommand,
  RemovePreferenceCommand 
} from '../../domain/commands/user-profile-commands';
import { UserProfileAggregate } from '../../domain/aggregates/user-profile-aggregate';
import { EventStore } from '../event-store/event-store';

export class UserProfileCommandHandlers {
  constructor(private eventStore: EventStore) {}

  async handleCreateUserProfile(command: CreateUserProfileCommand): Promise<void> {
    const { profileId, name, email } = command.data;
    const { userId, deviceId } = command.metadata;

    // Create and initialize the aggregate
    const userProfile = new UserProfileAggregate(profileId);
    
    // Apply business logic
    userProfile.createProfile(name, email, userId!, deviceId);
    
    // Save events
    await this.eventStore.saveEvents(
      'UserProfile',
      profileId,
      userProfile.uncommittedEvents,
      -1 // Expected version for new aggregate
    );
    
    // Mark events as committed
    userProfile.markEventsAsCommitted();
  }

  async handleUpdateUserProfile(command: UpdateUserProfileCommand): Promise<void> {
    const { profileId, name, email } = command.data;
    const { userId, deviceId } = command.metadata;

    // Load the aggregate
    const events = await this.eventStore.getEvents('UserProfile', profileId);
    const userProfile = new UserProfileAggregate(profileId);
    userProfile.loadFromHistory(events);
    
    // Apply business logic
    userProfile.updateProfile(name, email, userId!, deviceId);
    
    // Save events
    await this.eventStore.saveEvents(
      'UserProfile',
      profileId,
      userProfile.uncommittedEvents,
      userProfile.version
    );
    
    // Mark events as committed
    userProfile.markEventsAsCommitted();
  }

  async handleAddPreference(command: AddPreferenceCommand): Promise<void> {
    const { profileId, key, value } = command.data;
    const { userId, deviceId } = command.metadata;

    // Load the aggregate
    const events = await this.eventStore.getEvents('UserProfile', profileId);
    const userProfile = new UserProfileAggregate(profileId);
    userProfile.loadFromHistory(events);
    
    // Apply business logic
    userProfile.addPreference(key, value, userId!, deviceId);
    
    // Save events
    await this.eventStore.saveEvents(
      'UserProfile',
      profileId,
      userProfile.uncommittedEvents,
      userProfile.version
    );
    
    // Mark events as committed
    userProfile.markEventsAsCommitted();
  }

  async handleRemovePreference(command: RemovePreferenceCommand): Promise<void> {
    const { profileId, key } = command.data;
    const { userId, deviceId } = command.metadata;

    // Load the aggregate
    const events = await this.eventStore.getEvents('UserProfile', profileId);
    const userProfile = new UserProfileAggregate(profileId);
    userProfile.loadFromHistory(events);
    
    // Apply business logic
    userProfile.removePreference(key, userId!, deviceId);
    
    // Save events
    await this.eventStore.saveEvents(
      'UserProfile',
      profileId,
      userProfile.uncommittedEvents,
      userProfile.version
    );
    
    // Mark events as committed
    userProfile.markEventsAsCommitted();
  }
}
```

### 5. Event Store

Implementação do armazenamento de eventos.

```typescript
// src/application/event-store/event-store.ts

import { DomainEvent } from '../../domain/events/base-event';

export interface EventStore {
  saveEvents(
    aggregateType: string,
    aggregateId: string,
    events: DomainEvent[],
    expectedVersion: number
  ): Promise<void>;
  
  getEvents(
    aggregateType: string,
    aggregateId: string,
    fromVersion?: number
  ): Promise<DomainEvent[]>;
  
  getAllEvents(
    aggregateType?: string,
    fromTimestamp?: number,
    toTimestamp?: number
  ): Promise<DomainEvent[]>;
  
  subscribeToEvents(
    callback: (event: DomainEvent) => void,
    aggregateType?: string
  ): () => void; // Returns unsubscribe function
}

// src/infrastructure/event-store/postgres-event-store.ts

import { Pool } from 'pg';
import { DomainEvent } from '../../domain/events/base-event';
import { EventStore } from '../../application/event-store/event-store';
import { EventBus } from '../event-bus/event-bus';

export class PostgresEventStore implements EventStore {
  private subscribers: Array<{
    callback: (event: DomainEvent) => void;
    aggregateType?: string;
  }> = [];

  constructor(
    private pool: Pool,
    private eventBus: EventBus
  ) {}

  async saveEvents(
    aggregateType: string,
    aggregateId: string,
    events: DomainEvent[],
    expectedVersion: number
  ): Promise<void> {
    if (events.length === 0) {
      return;
    }

    // Start a transaction
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      // Check version
      if (expectedVersion >= 0) {
        const result = await client.query(
          'SELECT MAX(version) as version FROM events WHERE aggregate_type = $1 AND aggregate_id = $2',
          [aggregateType, aggregateId]
        );
        
        const currentVersion = result.rows[0]?.version || 0;
        if (currentVersion !== expectedVersion) {
          throw new Error(`Concurrency conflict. Expected version ${expectedVersion}, got ${currentVersion}`);
        }
      }

      // Insert events
      for (const event of events) {
        await client.query(
          `INSERT INTO events (
            event_id, event_type, aggregate_id, aggregate_type, 
            version, timestamp, user_id, device_id, 
            correlation_id, causation_id, data
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
          [
            event.metadata.eventId,
            event.metadata.eventType,
            event.metadata.aggregateId,
            event.metadata.aggregateType,
            event.metadata.version,
            new Date(event.metadata.timestamp),
            event.metadata.userId,
            event.metadata.deviceId,
            event.metadata.correlationId,
            event.metadata.causationId,
            JSON.stringify(event.data)
          ]
        );
      }

      await client.query('COMMIT');

      // Publish events to subscribers and event bus
      for (const event of events) {
        // Notify subscribers
        this.notifySubscribers(event);
        
        // Publish to event bus for broader distribution
        await this.eventBus.publish(event);
      }
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async getEvents(
    aggregateType: string,
    aggregateId: string,
    fromVersion: number = 0
  ): Promise<DomainEvent[]> {
    const result = await this.pool.query(
      `SELECT * FROM events 
       WHERE aggregate_type = $1 AND aggregate_id = $2 AND version > $3
       ORDER BY version ASC`,
      [aggregateType, aggregateId, fromVersion]
    );

    return result.rows.map(this.mapRowToEvent);
  }

  async getAllEvents(
    aggregateType?: string,
    fromTimestamp?: number,
    toTimestamp?: number
  ): Promise<DomainEvent[]> {
    let query = 'SELECT * FROM events';
    const params: any[] = [];
    const conditions: string[] = [];

    if (aggregateType) {
      conditions.push(`aggregate_type = $${params.length + 1}`);
      params.push(aggregateType);
    }

    if (fromTimestamp) {
      conditions.push(`timestamp >= $${params.length + 1}`);
      params.push(new Date(fromTimestamp));
    }

    if (toTimestamp) {
      conditions.push(`timestamp <= $${params.length + 1}`);
      params.push(new Date(toTimestamp));
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    query += ' ORDER BY timestamp ASC';

    const result = await this.pool.query(query, params);
    return result.rows.map(this.mapRowToEvent);
  }

  subscribeToEvents(
    callback: (event: DomainEvent) => void,
    aggregateType?: string
  ): () => void {
    const subscription = { callback, aggregateType };
    this.subscribers.push(subscription);

    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(subscription);
      if (index !== -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  private notifySubscribers(event: DomainEvent): void {
    for (const subscriber of this.subscribers) {
      if (!subscriber.aggregateType || subscriber.aggregateType === event.metadata.aggregateType) {
        try {
          subscriber.callback(event);
        } catch (error) {
          console.error('Error in event subscriber:', error);
        }
      }
    }
  }

  private mapRowToEvent(row: any): DomainEvent {
    return {
      metadata: {
        eventId: row.event_id,
        eventType: row.event_type,
        aggregateId: row.aggregate_id,
        aggregateType: row.aggregate_type,
        version: row.version,
        timestamp: row.timestamp.getTime(),
        userId: row.user_id,
        deviceId: row.device_id,
        correlationId: row.correlation_id,
        causationId: row.causation_id
      },
      data: JSON.parse(row.data)
    };
  }
}
```

### 6. Projeções (Read Models)

Implementação de projeções para consultas otimizadas.

```typescript
// src/application/projections/projection-manager.ts

import { DomainEvent } from '../../domain/events/base-event';
import { EventStore } from '../event-store/event-store';

export interface Projection {
  name: string;
  handleEvent(event: DomainEvent): Promise<void>;
  rebuild?(): Promise<void>;
}

export class ProjectionManager {
  private projections: Map<string, Projection> = new Map();

  constructor(private eventStore: EventStore) {}

  registerProjection(projection: Projection): void {
    if (this.projections.has(projection.name)) {
      throw new Error(`Projection with name ${projection.name} already registered`);
    }
    this.projections.set(projection.name, projection);
  }

  async startProjections(): Promise<void> {
    // Subscribe to all events
    this.eventStore.subscribeToEvents(async (event) => {
      await this.handleEvent(event);
    });
  }

  async rebuildProjection(projectionName: string): Promise<void> {
    const projection = this.projections.get(projectionName);
    if (!projection) {
      throw new Error(`Projection ${projectionName} not found`);
    }

    if (!projection.rebuild) {
      throw new Error(`Projection ${projectionName} does not support rebuilding`);
    }

    await projection.rebuild();
  }

  async rebuildAllProjections(): Promise<void> {
    for (const [name, projection] of this.projections.entries()) {
      if (projection.rebuild) {
        await projection.rebuild();
      }
    }
  }

  private async handleEvent(event: DomainEvent): Promise<void> {
    for (const projection of this.projections.values()) {
      try {
        await projection.handleEvent(event);
      } catch (error) {
        console.error(`Error handling event in projection ${projection.name}:`, error);
      }
    }
  }
}

// src/application/projections/user-profile-projection.ts

import { DomainEvent } from '../../domain/events/base-event';
import { Projection } from './projection-manager';
import { EventStore } from '../event-store/event-store';
import { Pool } from 'pg';

export interface UserProfileReadModel {
  id: string;
  name: string;
  email: string;
  preferences: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export class UserProfileProjection implements Projection {
  readonly name = 'UserProfileProjection';

  constructor(
    private pool: Pool,
    private eventStore: EventStore
  ) {}

  async handleEvent(event: DomainEvent): Promise<void> {
    if (event.metadata.aggregateType !== 'UserProfile') {
      return;
    }

    switch (event.metadata.eventType) {
      case 'UserProfileCreated':
        await this.handleUserProfileCreated(event);
        break;
      case 'UserProfileUpdated':
        await this.handleUserProfileUpdated(event);
        break;
      case 'PreferenceAdded':
        await this.handlePreferenceAdded(event);
        break;
      case 'PreferenceRemoved':
        await this.handlePreferenceRemoved(event);
        break;
    }
  }

  async rebuild(): Promise<void> {
    // Clear existing projection data
    await this.pool.query('TRUNCATE TABLE user_profiles');

    // Get all events for UserProfile aggregate
    const events = await this.eventStore.getAllEvents('UserProfile');

    // Process events in order
    for (const event of events) {
      await this.handleEvent(event);
    }
  }

  private async handleUserProfileCreated(event: DomainEvent): Promise<void> {
    const { name, email } = event.data;
    const timestamp = new Date(event.metadata.timestamp);

    await this.pool.query(
      `INSERT INTO user_profiles (
        id, name, email, preferences, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        event.metadata.aggregateId,
        name,
        email,
        JSON.stringify({}),
        timestamp,
        timestamp
      ]
    );
  }

  private async handleUserProfileUpdated(event: DomainEvent): Promise<void> {
    const updates: string[] = [];
    const values: any[] = [event.metadata.aggregateId];
    let paramIndex = 2;

    if (event.data.name !== undefined) {
      updates.push(`name = $${paramIndex++}`);
      values.push(event.data.name);
    }

    if (event.data.email !== undefined) {
      updates.push(`email = $${paramIndex++}`);
      values.push(event.data.email);
    }

    updates.push(`updated_at = $${paramIndex++}`);
    values.push(new Date(event.metadata.timestamp));

    if (updates.length > 1) { // At least one field plus updated_at
      await this.pool.query(
        `UPDATE user_profiles
         SET ${updates.join(', ')}
         WHERE id = $1`,
        values
      );
    }
  }

  private async handlePreferenceAdded(event: DomainEvent): Promise<void> {
    const { key, value } = event.data;

    // Get current preferences
    const result = await this.pool.query(
      'SELECT preferences FROM user_profiles WHERE id = $1',
      [event.metadata.aggregateId]
    );

    if (result.rows.length === 0) {
      return; // Profile doesn't exist yet
    }

    const preferences = result.rows[0].preferences || {};
    preferences[key] = value;

    await this.pool.query(
      `UPDATE user_profiles
       SET preferences = $1, updated_at = $2
       WHERE id = $3`,
      [JSON.stringify(preferences), new Date(event.metadata.timestamp), event.metadata.aggregateId]
    );
  }

  private async handlePreferenceRemoved(event: DomainEvent): Promise<void> {
    const { key } = event.data;

    // Get current preferences
    const result = await this.pool.query(
      'SELECT preferences FROM user_profiles WHERE id = $1',
      [event.metadata.aggregateId]
    );

    if (result.rows.length === 0) {
      return; // Profile doesn't exist yet
    }

    const preferences = result.rows[0].preferences || {};
    delete preferences[key];

    await this.pool.query(
      `UPDATE user_profiles
       SET preferences = $1, updated_at = $2
       WHERE id = $3`,
      [JSON.stringify(preferences), new Date(event.metadata.timestamp), event.metadata.aggregateId]
    );
  }
}
```

### 7. Serviços de Consulta (Query Services)

Implementação de serviços para consultas otimizadas.

```typescript
// src/application/queries/user-profile-queries.ts

import { Pool } from 'pg';
import { UserProfileReadModel } from '../projections/user-profile-projection';

export class UserProfileQueries {
  constructor(private pool: Pool) {}

  async getUserProfile(id: string): Promise<UserProfileReadModel | null> {
    const result = await this.pool.query(
      'SELECT * FROM user_profiles WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return null;
    }

    return this.mapRowToUserProfile(result.rows[0]);
  }

  async getUserProfiles(ids: string[]): Promise<UserProfileReadModel[]> {
    if (ids.length === 0) {
      return [];
    }

    const result = await this.pool.query(
      'SELECT * FROM user_profiles WHERE id = ANY($1)',
      [ids]
    );

    return result.rows.map(this.mapRowToUserProfile);
  }

  async searchUserProfiles(query: string, limit: number = 10, offset: number = 0): Promise<UserProfileReadModel[]> {
    const result = await this.pool.query(
      `SELECT * FROM user_profiles 
       WHERE name ILIKE $1 OR email ILIKE $1
       ORDER BY name ASC
       LIMIT $2 OFFSET $3`,
      [`%${query}%`, limit, offset]
    );

    return result.rows.map(this.mapRowToUserProfile);
  }

  private mapRowToUserProfile(row: any): UserProfileReadModel {
    return {
      id: row.id,
      name: row.name,
      email: row.email,
      preferences: row.preferences || {},
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }
}
```

### 8. Barramento de Eventos (Event Bus)

Implementação do barramento de eventos para distribuição de eventos.

```typescript
// src/infrastructure/event-bus/event-bus.ts

import { DomainEvent } from '../../domain/events/base-event';

export interface EventBus {
  publish(event: DomainEvent): Promise<void>;
  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void; // Returns unsubscribe function
}

// src/infrastructure/event-bus/in-memory-event-bus.ts

import { DomainEvent } from '../../domain/events/base-event';
import { EventBus } from './event-bus';

interface Subscription {
  callback: (event: DomainEvent) => void | Promise<void>;
  filter?: (event: DomainEvent) => boolean;
}

export class InMemoryEventBus implements EventBus {
  private subscribers: Subscription[] = [];

  async publish(event: DomainEvent): Promise<void> {
    const promises: Promise<void>[] = [];

    for (const subscriber of this.subscribers) {
      if (!subscriber.filter || subscriber.filter(event)) {
        const result = subscriber.callback(event);
        if (result instanceof Promise) {
          promises.push(result);
        }
      }
    }

    // Wait for all async subscribers to complete
    if (promises.length > 0) {
      await Promise.all(promises);
    }
  }

  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void {
    const subscription: Subscription = { callback, filter };
    this.subscribers.push(subscription);

    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(subscription);
      if (index !== -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }
}

// src/infrastructure/event-bus/kafka-event-bus.ts

import { Kafka, Producer, Consumer } from 'kafkajs';
import { DomainEvent } from '../../domain/events/base-event';
import { EventBus } from './event-bus';

export class KafkaEventBus implements EventBus {
  private producer: Producer;
  private consumer: Consumer;
  private subscribers: Array<{
    callback: (event: DomainEvent) => void | Promise<void>;
    filter?: (event: DomainEvent) => boolean;
  }> = [];
  private isConnected = false;
  private isConsuming = false;

  constructor(
    private kafka: Kafka,
    private topic: string,
    private groupId: string
  ) {
    this.producer = kafka.producer();
    this.consumer = kafka.consumer({ groupId });
  }

  async connect(): Promise<void> {
    if (!this.isConnected) {
      await this.producer.connect();
      await this.consumer.connect();
      this.isConnected = true;
    }
  }

  async disconnect(): Promise<void> {
    if (this.isConnected) {
      await this.producer.disconnect();
      await this.consumer.disconnect();
      this.isConnected = false;
      this.isConsuming = false;
    }
  }

  async publish(event: DomainEvent): Promise<void> {
    if (!this.isConnected) {
      await this.connect();
    }

    await this.producer.send({
      topic: this.topic,
      messages: [
        {
          key: `${event.metadata.aggregateType}-${event.metadata.aggregateId}`,
          value: JSON.stringify(event),
          headers: {
            eventType: event.metadata.eventType,
            aggregateType: event.metadata.aggregateType,
            timestamp: event.metadata.timestamp.toString()
          }
        }
      ]
    });
  }

  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void {
    const subscription = { callback, filter };
    this.subscribers.push(subscription);

    // Start consuming if not already
    this.startConsuming().catch(err => {
      console.error('Error starting Kafka consumer:', err);
    });

    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(subscription);
      if (index !== -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  private async startConsuming(): Promise<void> {
    if (this.isConsuming || this.subscribers.length === 0) {
      return;
    }

    if (!this.isConnected) {
      await this.connect();
    }

    await this.consumer.subscribe({ topic: this.topic, fromBeginning: false });

    await this.consumer.run({
      eachMessage: async ({ message }) => {
        try {
          if (!message.value) return;

          const event = JSON.parse(message.value.toString()) as DomainEvent;

          for (const subscriber of this.subscribers) {
            if (!subscriber.filter || subscriber.filter(event)) {
              await Promise.resolve(subscriber.callback(event));
            }
          }
        } catch (error) {
          console.error('Error processing Kafka message:', error);
        }
      }
    });

    this.isConsuming = true;
  }
}
```

### 9. Barramento de Comandos (Command Bus)

Implementação do barramento de comandos para processamento de comandos.

```typescript
// src/application/command-bus/command-bus.ts

import { Command } from '../../domain/commands/base-command';

export interface CommandHandler<T extends Command> {
  handle(command: T): Promise<void>;
}

export interface CommandBus {
  registerHandler<T extends Command>(
    commandType: string,
    handler: CommandHandler<T>
  ): void;
  
  dispatch<T extends Command>(command: T): Promise<void>;
}

// src/application/command-bus/in-memory-command-bus.ts

import { Command } from '../../domain/commands/base-command';
import { CommandBus, CommandHandler } from './command-bus';

export class InMemoryCommandBus implements CommandBus {
  private handlers: Map<string, CommandHandler<any>> = new Map();

  registerHandler<T extends Command>(
    commandType: string,
    handler: CommandHandler<T>
  ): void {
    if (this.handlers.has(commandType)) {
      throw new Error(`Handler for command type ${commandType} already registered`);
    }
    this.handlers.set(commandType, handler);
  }

  async dispatch<T extends Command>(command: T): Promise<void> {
    const commandType = command.constructor.name;
    const handler = this.handlers.get(commandType);

    if (!handler) {
      throw new Error(`No handler registered for command type ${commandType}`);
    }

    await handler.handle(command);
  }
}
```

### 10. Integração com Frontend

Implementação de serviços para integração com o frontend.

```typescript
// src/frontend/services/event-sourcing-service.ts

import { Command } from '../../domain/commands/base-command';
import { DomainEvent } from '../../domain/events/base-event';
import { ApiService } from './api-service';

export class EventSourcingService {
  private offlineCommands: Command[] = [];
  private isOnline: boolean = navigator.onLine;
  private eventListeners: Array<(event: DomainEvent) => void> = [];

  constructor(private apiService: ApiService) {
    // Load offline commands from storage
    this.loadOfflineCommands();

    // Set up online/offline listeners
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.processPendingCommands();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
    });

    // Set up event source for server-sent events
    this.setupEventSource();
  }

  async dispatchCommand(command: Command): Promise<void> {
    if (this.isOnline) {
      try {
        await this.apiService.post('/api/commands', command);
      } catch (error) {
        console.error('Error dispatching command:', error);
        // If API call fails, store command for later
        this.storeCommandOffline(command);
      }
    } else {
      // Store command for later when offline
      this.storeCommandOffline(command);
    }
  }

  addEventListener(callback: (event: DomainEvent) => void): () => void {
    this.eventListeners.push(callback);
    return () => {
      const index = this.eventListeners.indexOf(callback);
      if (index !== -1) {
        this.eventListeners.splice(index, 1);
      }
    };
  }

  private storeCommandOffline(command: Command): void {
    this.offlineCommands.push(command);
    localStorage.setItem('offlineCommands', JSON.stringify(this.offlineCommands));
  }

  private loadOfflineCommands(): void {
    const stored = localStorage.getItem('offlineCommands');
    if (stored) {
      try {
        this.offlineCommands = JSON.parse(stored);
      } catch (error) {
        console.error('Error loading offline commands:', error);
        localStorage.removeItem('offlineCommands');
      }
    }
  }

  private async processPendingCommands(): Promise<void> {
    if (this.offlineCommands.length === 0) {
      return;
    }

    const commands = [...this.offlineCommands];
    this.offlineCommands = [];
    localStorage.removeItem('offlineCommands');

    for (const command of commands) {
      try {
        await this.apiService.post('/api/commands', command);
      } catch (error) {
        console.error('Error processing pending command:', error);
        // Put back in queue
        this.storeCommandOffline(command);
      }
    }
  }

  private setupEventSource(): void {
    const eventSource = new EventSource('/api/events');

    eventSource.onmessage = (messageEvent) => {
      try {
        const event = JSON.parse(messageEvent.data) as DomainEvent;
        this.notifyEventListeners(event);
      } catch (error) {
        console.error('Error processing event:', error);
      }
    };

    eventSource.onerror = () => {
      console.error('EventSource error');
      // Reconnect after delay
      setTimeout(() => this.setupEventSource(), 5000);
    };
  }

  private notifyEventListeners(event: DomainEvent): void {
    for (const listener of this.eventListeners) {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in event listener:', error);
      }
    }
  }
}
```

### 11. Integração com IoT

Implementação de serviços para integração com dispositivos IoT.

```typescript
// src/iot/event-sourcing-client.ts

import { Command } from '../domain/commands/base-command';
import { DomainEvent } from '../domain/events/base-event';
import { IoTAuthClient } from './auth-client';

export class IoTEventSourcingClient {
  private offlineCommands: Command[] = [];
  private isOnline: boolean = true;
  private eventListeners: Array<(event: DomainEvent) => void> = [];
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private ws: WebSocket | null = null;

  constructor(
    private apiUrl: string,
    private authClient: IoTAuthClient,
    private offlineStoragePath: string = './data/offline-commands.json'
  ) {
    // Load offline commands from storage
    this.loadOfflineCommands();

    // Connect to WebSocket
    this.connect();
  }

  async dispatchCommand(command: Command): Promise<void> {
    if (this.isOnline) {
      try {
        const token = await this.authClient.getToken();
        const response = await fetch(`${this.apiUrl}/api/commands`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(command)
        });

        if (!response.ok) {
          throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
      } catch (error) {
        console.error('Error dispatching command:', error);
        // If API call fails, store command for later
        this.storeCommandOffline(command);
      }
    } else {
      // Store command for later when offline
      this.storeCommandOffline(command);
    }
  }

  addEventListener(callback: (event: DomainEvent) => void): () => void {
    this.eventListeners.push(callback);
    return () => {
      const index = this.eventListeners.indexOf(callback);
      if (index !== -1) {
        this.eventListeners.splice(index, 1);
      }
    };
  }

  private storeCommandOffline(command: Command): void {
    this.offlineCommands.push(command);
    this.saveOfflineCommands();
  }

  private loadOfflineCommands(): void {
    try {
      const fs = require('fs');
      if (fs.existsSync(this.offlineStoragePath)) {
        const data = fs.readFileSync(this.offlineStoragePath, 'utf8');
        this.offlineCommands = JSON.parse(data);
      }
    } catch (error) {
      console.error('Error loading offline commands:', error);
    }
  }

  private saveOfflineCommands(): void {
    try {
      const fs = require('fs');
      const data = JSON.stringify(this.offlineCommands);
      fs.writeFileSync(this.offlineStoragePath, data, 'utf8');
    } catch (error) {
      console.error('Error saving offline commands:', error);
    }
  }

  private async processPendingCommands(): Promise<void> {
    if (this.offlineCommands.length === 0) {
      return;
    }

    const commands = [...this.offlineCommands];
    this.offlineCommands = [];
    this.saveOfflineCommands();

    for (const command of commands) {
      try {
        await this.dispatchCommand(command);
      } catch (error) {
        console.error('Error processing pending command:', error);
        // Put back in queue
        this.storeCommandOffline(command);
      }
    }
  }

  private async connect(): Promise<void> {
    try {
      const token = await this.authClient.getToken();
      this.ws = new WebSocket(`${this.apiUrl.replace('http', 'ws')}/api/events?token=${token}`);

      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.isOnline = true;
        this.processPendingCommands();
      };

      this.ws.onmessage = (messageEvent) => {
        try {
          const event = JSON.parse(messageEvent.data) as DomainEvent;
          this.notifyEventListeners(event);
        } catch (error) {
          console.error('Error processing event:', error);
        }
      };

      this.ws.onclose = () => {
        console.log('WebSocket disconnected');
        this.isOnline = false;
        
        // Reconnect after delay
        if (this.reconnectTimeout) {
          clearTimeout(this.reconnectTimeout);
        }
        this.reconnectTimeout = setTimeout(() => this.connect(), 5000);
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.ws?.close();
      };
    } catch (error) {
      console.error('Error connecting to WebSocket:', error);
      this.isOnline = false;
      
      // Retry after delay
      if (this.reconnectTimeout) {
        clearTimeout(this.reconnectTimeout);
      }
      this.reconnectTimeout = setTimeout(() => this.connect(), 5000);
    }
  }

  private notifyEventListeners(event: DomainEvent): void {
    for (const listener of this.eventListeners) {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in event listener:', error);
      }
    }
  }
}
```

### 12. Esquema de Banco de Dados

Esquema SQL para PostgreSQL.

```sql
-- Events table for event store
CREATE TABLE events (
  event_id UUID PRIMARY KEY,
  event_type VARCHAR(255) NOT NULL,
  aggregate_id VARCHAR(255) NOT NULL,
  aggregate_type VARCHAR(255) NOT NULL,
  version INT NOT NULL,
  timestamp TIMESTAMP NOT NULL,
  user_id VARCHAR(255),
  device_id VARCHAR(255),
  correlation_id VARCHAR(255),
  causation_id VARCHAR(255),
  data JSONB NOT NULL,
  UNIQUE (aggregate_id, aggregate_type, version)
);

-- Indexes for efficient querying
CREATE INDEX idx_events_aggregate ON events(aggregate_type, aggregate_id, version);
CREATE INDEX idx_events_timestamp ON events(timestamp);
CREATE INDEX idx_events_correlation ON events(correlation_id);

-- Read model for user profiles
CREATE TABLE user_profiles (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  preferences JSONB NOT NULL,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE INDEX idx_user_profiles_email ON user_profiles(email);
CREATE INDEX idx_user_profiles_name ON user_profiles(name);
```

## Fluxo de Operação

### 1. Fluxo de Comando (Write Path)

1. **Cliente (Frontend/IoT)** envia um comando para o sistema.
2. **Command Bus** recebe o comando e o encaminha para o handler apropriado.
3. **Command Handler** carrega o agregado correspondente do Event Store.
4. **Aggregate** aplica regras de negócio e gera eventos.
5. **Event Store** persiste os eventos e os publica no Event Bus.
6. **Event Bus** distribui os eventos para os subscribers, incluindo projeções.
7. **Projections** atualizam os modelos de leitura com base nos eventos.

### 2. Fluxo de Consulta (Read Path)

1. **Cliente (Frontend/IoT)** envia uma consulta para o sistema.
2. **Query Service** consulta diretamente o modelo de leitura otimizado.
3. **Read Model** retorna os dados solicitados.

### 3. Fluxo Offline

1. **Cliente (Frontend/IoT)** perde conexão com o servidor.
2. **Cliente** armazena comandos localmente.
3. **Cliente** reconecta ao servidor.
4. **Cliente** envia comandos armazenados para processamento.
5. **Servidor** processa os comandos e gera eventos.
6. **Cliente** recebe eventos e atualiza seu estado local.

## Benefícios da Implementação

1. **Histórico Completo**: Todos os eventos são armazenados, permitindo reconstrução de estado em qualquer ponto no tempo.
2. **Operações Offline**: Clientes podem continuar operando offline e sincronizar quando voltarem online.
3. **Desempenho Otimizado**: Separação entre modelos de leitura e escrita permite otimização independente.
4. **Auditoria Integrada**: O log de eventos serve como trilha de auditoria natural.
5. **Escalabilidade**: Leituras e escritas podem ser escaladas independentemente.
6. **Evolução do Sistema**: Novos modelos de leitura podem ser criados a partir do histórico de eventos.

## Considerações para o MVP

Para a fase inicial de desenvolvimento (MVP), o sistema de gerenciamento de estado distribuído deve focar em:

1. Implementação básica de Event Sourcing para agregados críticos.
2. Projeções simples para modelos de leitura essenciais.
3. Suporte a operações offline no frontend e dispositivos IoT.
4. Barramento de eventos simples (in-memory para desenvolvimento, Kafka para produção).

Recursos avançados como snapshots de agregados, versionamento de eventos e projeções personalizadas podem ser adicionados em fases posteriores.

## Conclusão

Esta implementação de gerenciamento de estado distribuído com Event Sourcing e CQRS resolve os problemas de consistência e operações offline da BazeX/QBeeX. O sistema garante:

1. **Consistência Eventual**: Todos os componentes eventualmente convergem para um estado consistente.
2. **Operações Offline Robustas**: Clientes podem continuar operando mesmo sem conectividade.
3. **Rastreabilidade**: Todas as mudanças são rastreáveis até os eventos que as causaram.
4. **Desempenho Otimizado**: Separação entre modelos de leitura e escrita permite otimização independente.
5. **Escalabilidade**: Arquitetura que suporta crescimento horizontal.

Esta solução elimina as inconsistências de estado identificadas na revisão técnica e fornece uma base sólida para a integração perfeita entre frontend, backend e componentes IoT da plataforma BazeX/QBeeX.
