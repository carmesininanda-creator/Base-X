/**
 * Live AI Demo Component - BazeX Demo
 * Autor: Dr. Nova Singh - AI/ML Scientist
 * Descrição: Demonstração ao vivo impressionante da IA preditiva
 */

import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Play, 
  Pause, 
  Brain, 
  Clock, 
  User, 
  MapPin, 
  Activity,
  Coffee,
  Smartphone,
  Calendar,
  TrendingUp,
  Zap,
  Target,
  CheckCircle
} from 'lucide-react'

const LiveAIDemo = () => {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentScenario, setCurrentScenario] = useState(0)
  const [predictionStep, setPredictionStep] = useState(0)

  const scenarios = [
    {
      id: 'executive',
      title: 'Executivo em Reunião',
      user: 'Carlos Silva, CEO',
      context: {
        time: '14:30',
        location: 'Sala de Reunião A',
        activity: 'Reunião de Board',
        mood: 'Focado',
        devices: ['iPhone', 'MacBook']
      },
      predictions: [
        {
          step: 0,
          type: 'Análise Contextual',
          content: 'Detectando padrões comportamentais...',
          confidence: 0,
          icon: Brain,
          color: 'text-blue-400'
        },
        {
          step: 1,
          type: 'Predição Imediata',
          content: 'Próxima ação: Verificar emails (89% confiança)',
          confidence: 89,
          icon: Smartphone,
          color: 'text-green-400',
          reasoning: 'Baseado em 47 reuniões similares nos últimos 3 meses'
        },
        {
          step: 2,
          type: 'Predição de Médio Prazo',
          content: 'Pedirá café em 12 minutos (94% confiança)',
          confidence: 94,
          icon: Coffee,
          color: 'text-orange-400',
          reasoning: 'Padrão consistente: café sempre após reuniões longas'
        },
        {
          step: 3,
          type: 'Predição Avançada',
          content: 'Agendará follow-up para amanhã 10h (91% confiança)',
          confidence: 91,
          icon: Calendar,
          color: 'text-purple-400',
          reasoning: 'Análise de agenda + importância da reunião + histórico'
        }
      ],
      accuracy: 94.2,
      realTime: true
    },
    {
      id: 'student',
      title: 'Estudante Universitário',
      user: 'Ana Costa, 22 anos',
      context: {
        time: '20:15',
        location: 'Biblioteca Central',
        activity: 'Estudando para prova',
        mood: 'Concentrada',
        devices: ['Laptop', 'Smartphone']
      },
      predictions: [
        {
          step: 0,
          type: 'Análise Comportamental',
          content: 'Processando dados de estudo...',
          confidence: 0,
          icon: Brain,
          color: 'text-blue-400'
        },
        {
          step: 1,
          type: 'Predição Imediata',
          content: 'Pausa para alongamento em 8 minutos (92% confiança)',
          confidence: 92,
          icon: Activity,
          color: 'text-green-400',
          reasoning: 'Ciclo de estudo de 45min + sinais de fadiga detectados'
        },
        {
          step: 2,
          type: 'Predição Contextual',
          content: 'Consultará material de apoio específico (87% confiança)',
          confidence: 87,
          icon: Target,
          color: 'text-blue-400',
          reasoning: 'Padrão de dificuldade + histórico de consultas'
        },
        {
          step: 3,
          type: 'Predição de Bem-estar',
          content: 'Precisará de lanche energético em 25min (89% confiança)',
          confidence: 89,
          icon: TrendingUp,
          color: 'text-yellow-400',
          reasoning: 'Análise de glicemia + padrões alimentares + performance'
        }
      ],
      accuracy: 96.8,
      realTime: true
    },
    {
      id: 'remote_worker',
      title: 'Trabalhador Remoto',
      user: 'Pedro Santos, Designer',
      context: {
        time: '16:45',
        location: 'Home Office',
        activity: 'Criando apresentação',
        mood: 'Criativo',
        devices: ['iMac', 'iPad', 'iPhone']
      },
      predictions: [
        {
          step: 0,
          type: 'Análise de Produtividade',
          content: 'Avaliando padrões de trabalho...',
          confidence: 0,
          icon: Brain,
          color: 'text-blue-400'
        },
        {
          step: 1,
          type: 'Predição de Workflow',
          content: 'Mudará para iPad para esboços (88% confiança)',
          confidence: 88,
          icon: Target,
          color: 'text-purple-400',
          reasoning: 'Fase criativa detectada + preferência por desenho manual'
        },
        {
          step: 2,
          type: 'Predição de Pausa',
          content: 'Exercício às 17:15 (91% confiança)',
          confidence: 91,
          icon: Activity,
          color: 'text-green-400',
          reasoning: 'Rotina de exercícios + alertas de saúde + produtividade'
        },
        {
          step: 3,
          type: 'Predição Social',
          content: 'Ligará para cliente às 18h (85% confiança)',
          confidence: 85,
          icon: Smartphone,
          color: 'text-orange-400',
          reasoning: 'Agenda + deadline do projeto + padrão de comunicação'
        }
      ],
      accuracy: 91.5,
      realTime: true
    }
  ]

  // Controlar animação das predições
  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setPredictionStep(prev => {
        const maxSteps = scenarios[currentScenario].predictions.length - 1
        if (prev >= maxSteps) {
          // Mover para próximo cenário
          setCurrentScenario(prevScenario => 
            prevScenario >= scenarios.length - 1 ? 0 : prevScenario + 1
          )
          return 0
        }
        return prev + 1
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [isPlaying, currentScenario])

  const currentScenarioData = scenarios[currentScenario]
  const currentPrediction = currentScenarioData.predictions[predictionStep]

  const toggleDemo = () => {
    setIsPlaying(!isPlaying)
    if (!isPlaying) {
      setPredictionStep(0)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header com controles */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-4xl font-bold mb-2">IA em Ação</h2>
          <p className="text-gray-300 text-lg">
            Veja nossa IA predizendo comportamentos em tempo real
          </p>
        </div>
        
        <motion.button
          onClick={toggleDemo}
          className={`flex items-center space-x-3 px-6 py-3 rounded-xl font-semibold transition-all ${
            isPlaying 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-green-500 hover:bg-green-600 text-white'
          }`}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          <span>{isPlaying ? 'Pausar Demo' : 'Iniciar Demo'}</span>
        </motion.button>
      </div>

      {/* Seletor de cenários */}
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {scenarios.map((scenario, index) => (
          <motion.button
            key={scenario.id}
            onClick={() => {
              setCurrentScenario(index)
              setPredictionStep(0)
            }}
            className={`flex-shrink-0 px-4 py-2 rounded-lg font-medium transition-all ${
              currentScenario === index
                ? 'bg-blue-500 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {scenario.title}
          </motion.button>
        ))}
      </div>

      {/* Demo principal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Contexto do usuário */}
        <motion.div 
          className="bg-gradient-to-br from-gray-900/50 to-gray-800/50 backdrop-blur-sm border border-white/10 rounded-2xl p-6"
          key={currentScenario}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <User className="w-6 h-6 text-blue-400 mr-3" />
            Contexto do Usuário
          </h3>
          
          <div className="space-y-4">
            <div>
              <div className="text-sm text-gray-400 mb-1">Usuário</div>
              <div className="font-semibold">{currentScenarioData.user}</div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-sm text-gray-400 mb-1">Horário</div>
                <div className="flex items-center">
                  <Clock className="w-4 h-4 text-green-400 mr-2" />
                  {currentScenarioData.context.time}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-400 mb-1">Local</div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 text-red-400 mr-2" />
                  {currentScenarioData.context.location}
                </div>
              </div>
            </div>
            
            <div>
              <div className="text-sm text-gray-400 mb-1">Atividade</div>
              <div className="flex items-center">
                <Activity className="w-4 h-4 text-purple-400 mr-2" />
                {currentScenarioData.context.activity}
              </div>
            </div>
            
            <div>
              <div className="text-sm text-gray-400 mb-1">Dispositivos Conectados</div>
              <div className="flex flex-wrap gap-2">
                {currentScenarioData.context.devices.map(device => (
                  <span key={device} className="px-2 py-1 bg-blue-500/20 text-blue-300 rounded text-xs">
                    {device}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Predição atual */}
        <motion.div 
          className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 border border-blue-500/20 rounded-2xl p-6"
          key={`${currentScenario}-${predictionStep}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <Brain className="w-6 h-6 text-purple-400 mr-3" />
            Predição Ativa
          </h3>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={predictionStep}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              transition={{ duration: 0.4 }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <currentPrediction.icon className={`w-6 h-6 ${currentPrediction.color}`} />
                  <span className="font-semibold">{currentPrediction.type}</span>
                </div>
                {currentPrediction.confidence > 0 && (
                  <div className="text-right">
                    <div className={`text-lg font-bold ${currentPrediction.color}`}>
                      {currentPrediction.confidence}%
                    </div>
                    <div className="text-xs text-gray-400">confiança</div>
                  </div>
                )}
              </div>
              
              <div className="bg-black/20 border border-white/10 rounded-lg p-4">
                <div className="font-medium mb-2">{currentPrediction.content}</div>
                {currentPrediction.reasoning && (
                  <div className="text-sm text-gray-400">
                    💡 {currentPrediction.reasoning}
                  </div>
                )}
              </div>
              
              {currentPrediction.confidence > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Precisão</span>
                    <span>{currentPrediction.confidence}%</span>
                  </div>
                  <div className="bg-gray-700 rounded-full h-2">
                    <motion.div 
                      className={`h-2 rounded-full bg-gradient-to-r ${
                        currentPrediction.confidence >= 90 ? 'from-green-500 to-green-400' :
                        currentPrediction.confidence >= 80 ? 'from-yellow-500 to-yellow-400' :
                        'from-orange-500 to-orange-400'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${currentPrediction.confidence}%` }}
                      transition={{ duration: 1 }}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </motion.div>

        {/* Métricas do cenário */}
        <motion.div 
          className="bg-gradient-to-br from-green-900/20 to-emerald-900/20 border border-green-500/20 rounded-2xl p-6"
          key={`metrics-${currentScenario}`}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-xl font-bold mb-4 flex items-center">
            <CheckCircle className="w-6 h-6 text-green-400 mr-3" />
            Performance
          </h3>
          
          <div className="space-y-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">
                {currentScenarioData.accuracy}%
              </div>
              <div className="text-sm text-gray-300">Precisão do Cenário</div>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">Predições Realizadas</span>
                <span className="font-semibold">{predictionStep + 1}/4</span>
              </div>
              
              <div className="bg-gray-700 rounded-full h-2">
                <motion.div 
                  className="h-2 rounded-full bg-gradient-to-r from-green-500 to-green-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${((predictionStep + 1) / 4) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              
              <div className="text-center">
                <div className="text-sm text-gray-400 mb-2">Status</div>
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-green-400 text-sm font-medium">
                    {isPlaying ? 'Analisando...' : 'Pausado'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Progresso da demo */}
      <motion.div 
        className="bg-black/20 border border-white/10 rounded-xl p-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Progresso da Demo</span>
          <span className="text-sm text-gray-400">
            Cenário {currentScenario + 1} de {scenarios.length}
          </span>
        </div>
        <div className="bg-gray-700 rounded-full h-2">
          <motion.div 
            className="h-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
            initial={{ width: 0 }}
            animate={{ width: `${((currentScenario * 4 + predictionStep + 1) / (scenarios.length * 4)) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </motion.div>
    </div>
  )
}

export default LiveAIDemo

