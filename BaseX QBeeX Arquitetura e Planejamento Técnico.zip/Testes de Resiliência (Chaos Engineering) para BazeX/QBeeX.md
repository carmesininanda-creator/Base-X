# Testes de Resiliência (Chaos Engineering) para BazeX/QBeeX

## Visão Geral da Abordagem

Para garantir que a plataforma BazeX/QBeeX seja robusta e resiliente em condições adversas, implementaremos uma estratégia abrangente de testes de resiliência baseada nos princípios de Chaos Engineering. Esta abordagem nos permitirá identificar proativamente pontos fracos na arquitetura, validar os mecanismos de recuperação e garantir que o sistema mantenha sua funcionalidade mesmo quando componentes individuais falham.

## Princípios de Design

1. **Experimentação Controlada**: Testes executados em ambiente controlado antes de aplicar em produção.
2. **Hipóteses Claras**: Cada teste deve ter uma hipótese clara sobre o comportamento esperado do sistema.
3. **Impacto Minimizado**: Começar com testes de pequena escala e aumentar gradualmente o escopo.
4. **Monitoramento Abrangente**: Observar todos os aspectos do sistema durante os testes.
5. **Automação**: Automatizar a execução de testes para garantir consistência e repetibilidade.
6. **Aprendizado Contínuo**: Documentar resultados e incorporar aprendizados na arquitetura.

## Ferramentas e Tecnologias

1. **Chaos Toolkit**: Framework de código aberto para orquestração de experimentos de chaos engineering.
2. **Chaos Mesh**: Plataforma de chaos engineering para Kubernetes.
3. **Toxiproxy**: Proxy para simular falhas de rede.
4. **Pumba/Chaos Monkey**: Ferramentas para injetar falhas em contêineres Docker.
5. **Gremlin**: Plataforma comercial de chaos engineering (opcional para fases avançadas).

## Plano de Testes de Resiliência

### 1. Preparação do Ambiente de Testes

```python
# setup_chaos_environment.py
import os
import subprocess
import yaml
import time

def setup_monitoring():
    """Configurar monitoramento intensivo para o ambiente de testes"""
    print("Configurando monitoramento avançado...")
    
    # Aumentar frequência de coleta de métricas no Prometheus
    prometheus_config = {
        "global": {
            "scrape_interval": "5s",
            "evaluation_interval": "5s"
        },
        # Resto da configuração...
    }
    
    with open("prometheus-chaos-test.yml", "w") as f:
        yaml.dump(prometheus_config, f)
    
    # Aplicar configuração
    subprocess.run(["kubectl", "apply", "-f", "prometheus-chaos-test.yml"])
    
    # Configurar alertas específicos para testes de caos
    alerts_config = {
        "groups": [
            {
                "name": "chaos_testing",
                "rules": [
                    {
                        "alert": "HighErrorRateDuringChaos",
                        "expr": "sum(rate(http_requests_total{status=~\"5..\"}[1m])) / sum(rate(http_requests_total[1m])) > 0.1",
                        "for": "30s",
                        "labels": {"severity": "critical", "testing": "chaos"},
                        "annotations": {
                            "summary": "High error rate during chaos testing",
                            "description": "Error rate is above 10% during chaos testing"
                        }
                    }
                    # Mais regras de alerta...
                ]
            }
        ]
    }
    
    with open("chaos-alerts.yml", "w") as f:
        yaml.dump(alerts_config, f)
    
    subprocess.run(["kubectl", "apply", "-f", "chaos-alerts.yml"])
    
    print("Monitoramento configurado com sucesso")

def setup_chaos_toolkit():
    """Instalar e configurar Chaos Toolkit"""
    print("Configurando Chaos Toolkit...")
    
    # Instalar Chaos Toolkit e plugins necessários
    subprocess.run(["pip", "install", "chaostoolkit", "chaostoolkit-kubernetes", 
                   "chaostoolkit-prometheus", "chaostoolkit-aws"])
    
    # Configuração básica
    chaos_config = {
        "endpoint_url": "http://localhost:8080",
        "controls": {
            "prometheus": {
                "url": "http://prometheus:9090"
            }
        }
    }
    
    with open("chaos-config.yml", "w") as f:
        yaml.dump(chaos_config, f)
    
    print("Chaos Toolkit configurado com sucesso")

def setup_chaos_mesh():
    """Instalar e configurar Chaos Mesh no cluster Kubernetes"""
    print("Configurando Chaos Mesh...")
    
    # Adicionar repositório Helm
    subprocess.run(["helm", "repo", "add", "chaos-mesh", "https://charts.chaos-mesh.org"])
    subprocess.run(["helm", "repo", "update"])
    
    # Instalar Chaos Mesh
    subprocess.run(["helm", "install", "chaos-mesh", "chaos-mesh/chaos-mesh", 
                   "--namespace=chaos-testing", "--create-namespace"])
    
    # Esperar pela inicialização
    print("Aguardando inicialização do Chaos Mesh...")
    time.sleep(30)
    
    # Verificar status
    result = subprocess.run(["kubectl", "get", "pods", "-n", "chaos-testing"], 
                           capture_output=True, text=True)
    print(result.stdout)
    
    print("Chaos Mesh configurado com sucesso")

def setup_test_environment():
    """Configurar ambiente de teste isolado"""
    print("Configurando ambiente de teste isolado...")
    
    # Criar namespace dedicado
    subprocess.run(["kubectl", "create", "namespace", "bazex-chaos-test"])
    
    # Implantar versão de teste da aplicação
    subprocess.run(["kubectl", "apply", "-f", "bazex-test-deployment.yml", 
                   "-n", "bazex-chaos-test"])
    
    # Esperar pela inicialização
    print("Aguardando inicialização do ambiente de teste...")
    time.sleep(60)
    
    # Verificar status
    result = subprocess.run(["kubectl", "get", "pods", "-n", "bazex-chaos-test"], 
                           capture_output=True, text=True)
    print(result.stdout)
    
    print("Ambiente de teste configurado com sucesso")

if __name__ == "__main__":
    setup_monitoring()
    setup_chaos_toolkit()
    setup_chaos_mesh()
    setup_test_environment()
    print("Ambiente de testes de resiliência configurado e pronto para execução")
```

### 2. Testes de Resiliência de Rede

#### a. Experimento: Latência entre Microserviços

```yaml
# network_latency_experiment.yaml
---
version: 1.0.0
title: Latência entre Microserviços
description: Introduz latência na comunicação entre microserviços para verificar comportamento do sistema

steady-state-hypothesis:
  title: Serviços respondem dentro do SLA
  probes:
  - name: api-response-time
    type: probe
    tolerance: 200
    provider:
      type: http
      url: http://api-gateway.bazex-chaos-test:8080/health
      timeout: 3

method:
- type: action
  name: inject-latency
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: delay
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: backend-service
        delay:
          latency: "200ms"
          correlation: "100"
          jitter: "50ms"
  pauses:
    after: 60

rollbacks:
- type: action
  name: remove-latency
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: delay
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: backend-service
        delay:
          latency: "0ms"
```

#### b. Experimento: Perda de Pacotes

```yaml
# packet_loss_experiment.yaml
---
version: 1.0.0
title: Perda de Pacotes entre Serviços
description: Simula perda de pacotes na comunicação entre serviços para testar resiliência

steady-state-hypothesis:
  title: Sistema mantém funcionalidade com perda de pacotes
  probes:
  - name: successful-operations
    type: probe
    tolerance: true
    provider:
      type: python
      module: bazex.chaos.probes
      func: check_operations_success_rate
      arguments:
        min_success_rate: 0.95

method:
- type: action
  name: inject-packet-loss
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: loss
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: event-bus
        loss:
          loss: "20"
          correlation: "100"
  pauses:
    after: 120

rollbacks:
- type: action
  name: remove-packet-loss
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: loss
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: event-bus
        loss:
          loss: "0"
```

### 3. Testes de Falha de Serviço

#### a. Experimento: Falha de Microserviço

```yaml
# service_failure_experiment.yaml
---
version: 1.0.0
title: Falha de Microserviço
description: Simula falha completa de um microserviço para testar recuperação

steady-state-hypothesis:
  title: Sistema mantém funcionalidade com serviço em falha
  probes:
  - name: critical-functions
    type: probe
    tolerance: true
    provider:
      type: python
      module: bazex.chaos.probes
      func: check_critical_functions
      arguments:
        functions: ["user_auth", "event_processing", "data_sync"]

method:
- type: action
  name: terminate-service
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      podChaos:
        action: pod-kill
        mode: one
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: user-profile-service
  pauses:
    after: 30

- type: probe
  name: verify-service-recovery
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    func: pod_count
    arguments:
      label_selector: "app=user-profile-service"
      expected_count: 1
  pauses:
    after: 60

- type: probe
  name: verify-functionality
  provider:
    type: http
    url: http://api-gateway.bazex-chaos-test:8080/users/profile
    timeout: 5
    expected_status: 200
```

#### b. Experimento: Falha de Banco de Dados

```yaml
# database_failure_experiment.yaml
---
version: 1.0.0
title: Falha de Banco de Dados
description: Simula falha do banco de dados para testar mecanismos de fallback e recuperação

steady-state-hypothesis:
  title: Sistema mantém operação básica durante falha de banco de dados
  probes:
  - name: read-operations
    type: probe
    tolerance: true
    provider:
      type: python
      module: bazex.chaos.probes
      func: check_read_operations
      arguments:
        min_success_rate: 0.9

method:
- type: action
  name: terminate-database
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      podChaos:
        action: pod-kill
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: postgres
  pauses:
    after: 30

- type: probe
  name: verify-fallback-mode
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_system_mode
    arguments:
      expected_mode: "fallback"
  pauses:
    after: 30

- type: action
  name: restore-database
  provider:
    type: process
    path: kubectl
    arguments: ["apply", "-f", "database-deployment.yaml", "-n", "bazex-chaos-test"]
  pauses:
    after: 60

- type: probe
  name: verify-recovery
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_system_mode
    arguments:
      expected_mode: "normal"
```

### 4. Testes de Carga e Estresse

#### a. Experimento: Picos de Tráfego com Recursos Limitados

```yaml
# traffic_spike_experiment.yaml
---
version: 1.0.0
title: Picos de Tráfego com Recursos Limitados
description: Simula picos de tráfego enquanto limita recursos de CPU e memória

steady-state-hypothesis:
  title: Sistema mantém SLAs sob carga
  probes:
  - name: response-time
    type: probe
    tolerance: 500
    provider:
      type: http
      url: http://api-gateway.bazex-chaos-test:8080/health/response-time
      timeout: 5

method:
- type: action
  name: limit-resources
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      stressChaos:
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: api-gateway
        stressors:
          cpu:
            workers: 2
            load: 70
          memory:
            workers: 2
            size: "256MB"
  pauses:
    after: 30

- type: action
  name: generate-traffic
  provider:
    type: process
    path: ./load-test.sh
    arguments: ["--target=api-gateway", "--users=1000", "--duration=120"]
  pauses:
    after: 150

rollbacks:
- type: action
  name: remove-resource-limits
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      stressChaos:
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: api-gateway
```

### 5. Testes de Resiliência de IoT

#### a. Experimento: Conectividade Intermitente de Dispositivos IoT

```python
# iot_connectivity_test.py
import time
import random
import requests
from chaoslib.types import Configuration, Secrets
from chaoslib.experiment import run_experiment

def disrupt_iot_connectivity(device_ids=None, disruption_pattern="random"):
    """
    Simula problemas de conectividade em dispositivos IoT
    
    Args:
        device_ids: Lista de IDs de dispositivos para afetar (None = todos)
        disruption_pattern: Padrão de disrupção ("random", "periodic", "gradual")
    """
    if device_ids is None:
        # Obter todos os dispositivos de teste
        response = requests.get("http://iot-manager.bazex-chaos-test:8080/devices")
        devices = response.json()
        device_ids = [d["id"] for d in devices]
    
    print(f"Iniciando teste de conectividade intermitente para {len(device_ids)} dispositivos")
    
    if disruption_pattern == "random":
        # Desconectar dispositivos aleatoriamente
        for _ in range(30):  # 30 ciclos de disrupção
            target_device = random.choice(device_ids)
            print(f"Desconectando dispositivo {target_device}")
            
            requests.post(
                f"http://iot-manager.bazex-chaos-test:8080/devices/{target_device}/disconnect"
            )
            
            # Esperar tempo aleatório
            time.sleep(random.uniform(5, 20))
            
            # Reconectar
            print(f"Reconectando dispositivo {target_device}")
            requests.post(
                f"http://iot-manager.bazex-chaos-test:8080/devices/{target_device}/connect"
            )
            
            time.sleep(random.uniform(10, 30))
    
    elif disruption_pattern == "periodic":
        # Desconectar todos os dispositivos periodicamente
        for _ in range(5):  # 5 ciclos
            print("Desconectando todos os dispositivos")
            for device_id in device_ids:
                requests.post(
                    f"http://iot-manager.bazex-chaos-test:8080/devices/{device_id}/disconnect"
                )
            
            time.sleep(30)  # 30 segundos desconectados
            
            print("Reconectando todos os dispositivos")
            for device_id in device_ids:
                requests.post(
                    f"http://iot-manager.bazex-chaos-test:8080/devices/{device_id}/connect"
                )
            
            time.sleep(60)  # 60 segundos conectados
    
    elif disruption_pattern == "gradual":
        # Desconectar dispositivos gradualmente
        batch_size = max(1, len(device_ids) // 5)
        
        for i in range(0, len(device_ids), batch_size):
            batch = device_ids[i:i+batch_size]
            print(f"Desconectando lote de {len(batch)} dispositivos")
            
            for device_id in batch:
                requests.post(
                    f"http://iot-manager.bazex-chaos-test:8080/devices/{device_id}/disconnect"
                )
            
            time.sleep(30)
        
        # Reconectar todos
        print("Reconectando todos os dispositivos")
        for device_id in device_ids:
            requests.post(
                f"http://iot-manager.bazex-chaos-test:8080/devices/{device_id}/connect"
            )

def check_data_consistency():
    """Verifica consistência dos dados após reconexão dos dispositivos"""
    print("Verificando consistência de dados...")
    
    # Esperar sincronização
    time.sleep(120)
    
    # Verificar consistência
    response = requests.get("http://data-service.bazex-chaos-test:8080/consistency-check")
    result = response.json()
    
    print(f"Resultado da verificação de consistência: {result}")
    return result["consistent"]

# Definir experimento
experiment = {
    "version": "1.0.0",
    "title": "Teste de Conectividade Intermitente de IoT",
    "description": "Verifica se o sistema mantém consistência de dados com conectividade intermitente",
    "tags": ["iot", "connectivity", "resilience"],
    "steady-state-hypothesis": {
        "title": "Dados permanecem consistentes após reconexão",
        "probes": [
            {
                "name": "data-consistency-check",
                "type": "python",
                "module": __name__,
                "func": "check_data_consistency"
            }
        ]
    },
    "method": [
        {
            "name": "disrupt-connectivity-random",
            "type": "python",
            "module": __name__,
            "func": "disrupt_iot_connectivity",
            "arguments": {
                "disruption_pattern": "random"
            }
        },
        {
            "name": "verify-consistency-after-random",
            "type": "python",
            "module": __name__,
            "func": "check_data_consistency"
        },
        {
            "name": "disrupt-connectivity-periodic",
            "type": "python",
            "module": __name__,
            "func": "disrupt_iot_connectivity",
            "arguments": {
                "disruption_pattern": "periodic"
            }
        },
        {
            "name": "verify-consistency-after-periodic",
            "type": "python",
            "module": __name__,
            "func": "check_data_consistency"
        },
        {
            "name": "disrupt-connectivity-gradual",
            "type": "python",
            "module": __name__,
            "func": "disrupt_iot_connectivity",
            "arguments": {
                "disruption_pattern": "gradual"
            }
        }
    ]
}

if __name__ == "__main__":
    # Executar experimento
    run_experiment(experiment)
```

#### b. Experimento: Falha de Edge Computing

```yaml
# edge_computing_failure_experiment.yaml
---
version: 1.0.0
title: Falha de Edge Computing
description: Simula falha de nós edge computing para testar failover para cloud

steady-state-hypothesis:
  title: Sistema mantém processamento com falha de edge
  probes:
  - name: processing-continuity
    type: probe
    tolerance: true
    provider:
      type: python
      module: bazex.chaos.probes
      func: check_processing_continuity
      arguments:
        data_source: "sensor_stream"
        max_delay_ms: 5000

method:
- type: action
  name: terminate-edge-nodes
  provider:
    type: process
    path: ./simulate-edge-failure.sh
    arguments: ["--region=us-east", "--count=5"]
  pauses:
    after: 30

- type: probe
  name: verify-cloud-failover
  provider:
    type: http
    url: http://cloud-manager.bazex-chaos-test:8080/processing/status
    timeout: 5
    expected_pattern: ".*active_nodes\":.*cloud.*"
  pauses:
    after: 60

- type: probe
  name: verify-data-processing
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_data_processing_rate
    arguments:
      min_rate: 0.9
  pauses:
    after: 30

- type: action
  name: restore-edge-nodes
  provider:
    type: process
    path: ./restore-edge-nodes.sh
    arguments: ["--region=us-east"]
  pauses:
    after: 60

- type: probe
  name: verify-edge-recovery
  provider:
    type: http
    url: http://edge-manager.bazex-chaos-test:8080/nodes/status
    timeout: 5
    expected_status: 200
```

### 6. Testes de Resiliência de Barramento de Eventos

```yaml
# event_bus_resilience_experiment.yaml
---
version: 1.0.0
title: Resiliência do Barramento de Eventos
description: Testa a resiliência do barramento de eventos sob falhas de broker

steady-state-hypothesis:
  title: Eventos são processados corretamente
  probes:
  - name: event-processing-check
    type: probe
    tolerance: true
    provider:
      type: python
      module: bazex.chaos.probes
      func: check_event_processing
      arguments:
        success_rate: 0.99

method:
- type: action
  name: generate-event-load
  provider:
    type: process
    path: ./generate-events.sh
    arguments: ["--rate=1000", "--duration=300"]
  background: true

- type: action
  name: kill-kafka-broker
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      podChaos:
        action: pod-kill
        mode: one
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: kafka
  pauses:
    after: 30

- type: probe
  name: verify-event-delivery
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_event_delivery
    arguments:
      max_delay_ms: 5000
  pauses:
    after: 60

- type: action
  name: network-partition-kafka
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: partition
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: kafka
        direction: to
        target:
          selector:
            namespaces:
              - bazex-chaos-test
            labelSelectors:
              app: event-consumer
  pauses:
    after: 60

- type: probe
  name: verify-fallback-mechanism
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_event_bus_mode
    arguments:
      expected_mode: "fallback"
  pauses:
    after: 30

rollbacks:
- type: action
  name: restore-network
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      networkChaos:
        action: partition
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: kafka
```

### 7. Testes de Resiliência de Autenticação e Autorização

```yaml
# auth_resilience_experiment.yaml
---
version: 1.0.0
title: Resiliência do Sistema de Autenticação
description: Testa a resiliência do sistema de autenticação sob falhas

steady-state-hypothesis:
  title: Autenticação funciona corretamente
  probes:
  - name: auth-service-check
    type: probe
    tolerance: 200
    provider:
      type: http
      url: http://auth-service.bazex-chaos-test:8080/health
      timeout: 3

method:
- type: action
  name: terminate-auth-service
  provider:
    type: kubernetes
    namespace: bazex-chaos-test
    spec:
      podChaos:
        action: pod-kill
        mode: all
        selector:
          namespaces:
            - bazex-chaos-test
          labelSelectors:
            app: auth-service
  pauses:
    after: 30

- type: probe
  name: verify-cached-tokens
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_token_validation
    arguments:
      token_type: "cached"
  pauses:
    after: 30

- type: action
  name: simulate-user-login
  provider:
    type: process
    path: ./simulate-login.sh
    arguments: ["--users=10"]
  pauses:
    after: 30

- type: probe
  name: verify-auth-fallback
  provider:
    type: python
    module: bazex.chaos.probes
    func: check_auth_fallback_mode
  pauses:
    after: 30

- type: action
  name: restore-auth-service
  provider:
    type: process
    path: kubectl
    arguments: ["apply", "-f", "auth-service-deployment.yaml", "-n", "bazex-chaos-test"]
  pauses:
    after: 60

- type: probe
  name: verify-auth-recovery
  provider:
    type: http
    url: http://auth-service.bazex-chaos-test:8080/health
    timeout: 5
    expected_status: 200
```

### 8. Análise e Relatório de Resultados

```python
# analyze_chaos_results.py
import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

def load_experiment_results(results_dir):
    """Carrega resultados de experimentos de chaos engineering"""
    results = []
    
    for filename in os.listdir(results_dir):
        if filename.endswith('.json'):
            with open(os.path.join(results_dir, filename), 'r') as f:
                try:
                    data = json.load(f)
                    results.append(data)
                except json.JSONDecodeError:
                    print(f"Erro ao carregar {filename}")
    
    return results

def extract_metrics(results):
    """Extrai métricas relevantes dos resultados"""
    metrics = []
    
    for result in results:
        experiment_name = result.get('title', 'Unknown')
        status = result.get('status', 'Unknown')
        
        # Extrair métricas de tempo de resposta
        response_times = []
        for step in result.get('run', []):
            if 'output' in step and isinstance(step['output'], dict):
                if 'response_time_ms' in step['output']:
                    response_times.append(step['output']['response_time_ms'])
        
        # Extrair métricas de taxa de sucesso
        success_rates = []
        for step in result.get('run', []):
            if 'output' in step and isinstance(step['output'], dict):
                if 'success_rate' in step['output']:
                    success_rates.append(step['output']['success_rate'])
        
        # Calcular médias
        avg_response_time = sum(response_times) / len(response_times) if response_times else None
        avg_success_rate = sum(success_rates) / len(success_rates) if success_rates else None
        
        metrics.append({
            'experiment': experiment_name,
            'status': status,
            'avg_response_time_ms': avg_response_time,
            'avg_success_rate': avg_success_rate,
            'passed': status == 'completed',
            'start_time': result.get('start', ''),
            'end_time': result.get('end', '')
        })
    
    return metrics

def generate_report(metrics, output_dir):
    """Gera relatório de análise dos testes de resiliência"""
    # Converter para DataFrame
    df = pd.DataFrame(metrics)
    
    # Criar diretório de saída se não existir
    os.makedirs(output_dir, exist_ok=True)
    
    # Salvar dados em CSV
    df.to_csv(os.path.join(output_dir, 'chaos_test_results.csv'), index=False)
    
    # Gerar gráficos
    plt.figure(figsize=(12, 6))
    
    # Gráfico de tempo de resposta
    plt.subplot(1, 2, 1)
    sns.barplot(x='experiment', y='avg_response_time_ms', data=df)
    plt.title('Tempo Médio de Resposta por Experimento')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    # Gráfico de taxa de sucesso
    plt.subplot(1, 2, 2)
    sns.barplot(x='experiment', y='avg_success_rate', data=df)
    plt.title('Taxa Média de Sucesso por Experimento')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    # Salvar gráfico
    plt.savefig(os.path.join(output_dir, 'chaos_test_metrics.png'), dpi=300, bbox_inches='tight')
    
    # Gerar relatório HTML
    html_content = f"""
    <html>
    <head>
        <title>Relatório de Testes de Resiliência - BazeX/QBeeX</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            h1, h2 {{ color: #333; }}
            table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
            th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
            th {{ background-color: #f2f2f2; }}
            tr:nth-child(even) {{ background-color: #f9f9f9; }}
            .pass {{ color: green; }}
            .fail {{ color: red; }}
            .summary {{ background-color: #eef; padding: 10px; margin-bottom: 20px; }}
        </style>
    </head>
    <body>
        <h1>Relatório de Testes de Resiliência - BazeX/QBeeX</h1>
        <p>Gerado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        
        <div class="summary">
            <h2>Resumo</h2>
            <p>Total de experimentos: {len(df)}</p>
            <p>Experimentos bem-sucedidos: {df['passed'].sum()} ({df['passed'].sum()/len(df)*100:.1f}%)</p>
            <p>Tempo médio de resposta geral: {df['avg_response_time_ms'].mean():.2f} ms</p>
            <p>Taxa média de sucesso geral: {df['avg_success_rate'].mean()*100:.1f}%</p>
        </div>
        
        <h2>Resultados por Experimento</h2>
        <table>
            <tr>
                <th>Experimento</th>
                <th>Status</th>
                <th>Tempo Médio de Resposta (ms)</th>
                <th>Taxa Média de Sucesso</th>
                <th>Início</th>
                <th>Fim</th>
            </tr>
    """
    
    for _, row in df.iterrows():
        status_class = "pass" if row['passed'] else "fail"
        html_content += f"""
            <tr>
                <td>{row['experiment']}</td>
                <td class="{status_class}">{row['status']}</td>
                <td>{row['avg_response_time_ms']:.2f}</td>
                <td>{row['avg_success_rate']*100:.1f}%</td>
                <td>{row['start_time']}</td>
                <td>{row['end_time']}</td>
            </tr>
        """
    
    html_content += """
        </table>
        
        <h2>Gráficos</h2>
        <img src="chaos_test_metrics.png" alt="Métricas de Testes de Resiliência" style="max-width: 100%;">
        
        <h2>Conclusões e Recomendações</h2>
        <div id="conclusions">
            <!-- Será preenchido manualmente após análise -->
            <p>Análise pendente.</p>
        </div>
    </body>
    </html>
    """
    
    with open(os.path.join(output_dir, 'chaos_test_report.html'), 'w') as f:
        f.write(html_content)
    
    print(f"Relatório gerado em {os.path.join(output_dir, 'chaos_test_report.html')}")

if __name__ == "__main__":
    results_dir = "./chaos-results"
    output_dir = "./chaos-report"
    
    results = load_experiment_results(results_dir)
    metrics = extract_metrics(results)
    generate_report(metrics, output_dir)
```

## Execução dos Testes

### 1. Script de Orquestração de Testes

```python
# run_chaos_tests.py
import os
import subprocess
import argparse
import json
import time
from datetime import datetime

def setup_environment():
    """Configura o ambiente de testes"""
    print("Configurando ambiente de testes...")
    subprocess.run(["python", "setup_chaos_environment.py"])

def run_experiment(experiment_file, results_dir):
    """Executa um experimento de chaos engineering"""
    print(f"Executando experimento: {experiment_file}")
    
    # Criar diretório de resultados se não existir
    os.makedirs(results_dir, exist_ok=True)
    
    # Nome do arquivo de saída
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(
        results_dir, 
        f"{os.path.splitext(os.path.basename(experiment_file))[0]}_{timestamp}.json"
    )
    
    # Executar experimento
    if experiment_file.endswith('.yaml') or experiment_file.endswith('.yml'):
        result = subprocess.run(
            ["chaos", "run", experiment_file, "--journal-path", output_file],
            capture_output=True,
            text=True
        )
    elif experiment_file.endswith('.py'):
        result = subprocess.run(
            ["python", experiment_file, "--output", output_file],
            capture_output=True,
            text=True
        )
    else:
        print(f"Formato de arquivo não suportado: {experiment_file}")
        return False
    
    # Verificar resultado
    if result.returncode == 0:
        print(f"Experimento concluído com sucesso: {experiment_file}")
        print(f"Resultados salvos em: {output_file}")
        return True
    else:
        print(f"Erro ao executar experimento: {experiment_file}")
        print(f"Saída: {result.stdout}")
        print(f"Erro: {result.stderr}")
        return False

def run_all_experiments(experiments_dir, results_dir):
    """Executa todos os experimentos no diretório"""
    print(f"Executando todos os experimentos em: {experiments_dir}")
    
    # Listar arquivos de experimento
    experiments = []
    for filename in os.listdir(experiments_dir):
        if filename.endswith(('.yaml', '.yml', '.py')):
            experiments.append(os.path.join(experiments_dir, filename))
    
    # Ordenar experimentos
    experiments.sort()
    
    # Executar experimentos
    results = []
    for experiment in experiments:
        success = run_experiment(experiment, results_dir)
        results.append({
            "experiment": experiment,
            "success": success,
            "timestamp": datetime.now().isoformat()
        })
        
        # Pausa entre experimentos
        time.sleep(30)
    
    # Salvar resumo
    with open(os.path.join(results_dir, "summary.json"), "w") as f:
        json.dump(results, f, indent=2)
    
    return results

def generate_final_report(results_dir):
    """Gera relatório final de todos os testes"""
    print("Gerando relatório final...")
    subprocess.run(["python", "analyze_chaos_results.py"])

def cleanup_environment():
    """Limpa o ambiente de testes"""
    print("Limpando ambiente de testes...")
    subprocess.run(["kubectl", "delete", "namespace", "bazex-chaos-test"])

def main():
    parser = argparse.ArgumentParser(description="Executa testes de resiliência (chaos engineering)")
    parser.add_argument("--setup", action="store_true", help="Configurar ambiente de testes")
    parser.add_argument("--experiment", help="Arquivo de experimento específico para executar")
    parser.add_argument("--all", action="store_true", help="Executar todos os experimentos")
    parser.add_argument("--report", action="store_true", help="Gerar relatório final")
    parser.add_argument("--cleanup", action="store_true", help="Limpar ambiente de testes")
    parser.add_argument("--experiments-dir", default="./chaos-experiments", help="Diretório de experimentos")
    parser.add_argument("--results-dir", default="./chaos-results", help="Diretório de resultados")
    
    args = parser.parse_args()
    
    if args.setup:
        setup_environment()
    
    if args.experiment:
        run_experiment(args.experiment, args.results_dir)
    
    if args.all:
        run_all_experiments(args.experiments_dir, args.results_dir)
    
    if args.report:
        generate_final_report(args.results_dir)
    
    if args.cleanup:
        cleanup_environment()

if __name__ == "__main__":
    main()
```

### 2. Execução Automatizada

```bash
#!/bin/bash
# run_chaos_test_suite.sh

# Configurar ambiente
echo "Configurando ambiente de testes de resiliência..."
python run_chaos_tests.py --setup

# Executar todos os experimentos
echo "Executando todos os experimentos de chaos engineering..."
python run_chaos_tests.py --all

# Gerar relatório
echo "Gerando relatório de resultados..."
python run_chaos_tests.py --report

# Notificar conclusão
echo "Testes de resiliência concluídos. Relatório disponível em ./chaos-report/chaos_test_report.html"

# Opcional: limpar ambiente
# python run_chaos_tests.py --cleanup
```

## Benefícios da Implementação

1. **Identificação Proativa de Falhas**: Descoberta de pontos fracos antes que afetem os usuários em produção.
2. **Validação de Mecanismos de Resiliência**: Confirmação de que os mecanismos de recuperação e fallback funcionam conforme esperado.
3. **Confiança na Arquitetura**: Maior confiança na robustez do sistema sob condições adversas.
4. **Melhoria Contínua**: Insights para aprimorar a arquitetura e implementação.
5. **Documentação de Comportamento**: Documentação clara de como o sistema se comporta sob falhas.

## Considerações para o MVP

Para a fase inicial (MVP), os testes de resiliência devem focar em:

1. **Testes Básicos de Rede**: Latência e perda de pacotes entre componentes críticos.
2. **Falhas de Serviço**: Simulação de falha de microserviços essenciais.
3. **Testes de Barramento de Eventos**: Validação da resiliência do barramento de eventos.
4. **Testes de Autenticação**: Verificação da robustez do sistema de autenticação.

Testes mais avançados, como simulações complexas de falha de IoT e testes de carga combinados com falhas, podem ser adicionados em fases posteriores.

## Conclusão

A implementação de testes de resiliência (Chaos Engineering) é essencial para garantir que a plataforma BazeX/QBeeX seja robusta e confiável em condições adversas. Ao simular falhas de forma controlada e observar o comportamento do sistema, podemos identificar e corrigir pontos fracos antes que afetem os usuários em produção.

Os testes descritos neste documento cobrem os principais aspectos da arquitetura, incluindo rede, serviços, banco de dados, barramento de eventos, autenticação e dispositivos IoT. A execução regular desses testes, combinada com a análise dos resultados, permitirá uma melhoria contínua da resiliência do sistema.

Com a implementação desses testes, a BazeX/QBeeX estará bem posicionada para oferecer uma experiência confiável e robusta aos seus usuários, mesmo em face de falhas parciais ou condições adversas de operação.
