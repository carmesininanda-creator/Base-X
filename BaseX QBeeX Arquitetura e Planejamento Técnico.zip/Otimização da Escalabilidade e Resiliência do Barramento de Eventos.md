# Otimização da Escalabilidade e Resiliência do Barramento de Eventos

## Visão Geral da Solução

O barramento de eventos é um componente crítico da arquitetura da BazeX/QBeeX, responsável pela comunicação assíncrona entre os diversos componentes do sistema. Para garantir alta disponibilidade, escalabilidade e resiliência, implementaremos um barramento de eventos distribuído e tolerante a falhas, capaz de lidar com picos de tráfego e falhas parciais do sistema.

## Princípios de Design

1. **Distribuição e Escalabilidade**: Arquitetura distribuída que permite escalar horizontalmente conforme a demanda.
2. **Resiliência a Falhas**: Capacidade de continuar operando mesmo com falhas parciais.
3. **Garantia de Entrega**: Eventos são entregues pelo menos uma vez, mesmo em caso de falhas.
4. **Ordenação de Eventos**: Preservação da ordem dos eventos por agregado.
5. **Baixa Latência**: Processamento rápido de eventos para manter a responsividade do sistema.
6. **Observabilidade**: Monitoramento detalhado do fluxo de eventos.

## Componentes da Solução

### 1. Arquitetura Multi-Camada do Barramento de Eventos

Implementaremos uma arquitetura em camadas para o barramento de eventos:

```typescript
// src/infrastructure/event-bus/layered-event-bus.ts

import { DomainEvent } from '../../domain/events/base-event';
import { EventBus } from './event-bus';
import { KafkaEventBus } from './kafka-event-bus';
import { InMemoryEventBus } from './in-memory-event-bus';
import { EventLogger } from '../logging/event-logger';
import { MetricsCollector } from '../metrics/metrics-collector';

export class LayeredEventBus implements EventBus {
  private primaryBus: EventBus;
  private fallbackBus: EventBus;
  private logger: EventLogger;
  private metrics: MetricsCollector;
  private isPrimaryAvailable: boolean = true;
  private healthCheckInterval: NodeJS.Timeout | null = null;

  constructor(
    primaryBus: EventBus,
    fallbackBus: EventBus,
    logger: EventLogger,
    metrics: MetricsCollector,
    healthCheckIntervalMs: number = 30000
  ) {
    this.primaryBus = primaryBus;
    this.fallbackBus = fallbackBus;
    this.logger = logger;
    this.metrics = metrics;

    // Start health check for primary bus
    this.startHealthCheck(healthCheckIntervalMs);
  }

  async publish(event: DomainEvent): Promise<void> {
    const startTime = Date.now();
    
    try {
      // Log event for debugging and audit
      this.logger.logEventPublished(event);
      
      // Track metrics
      this.metrics.incrementEventPublished(event.metadata.eventType);
      
      if (this.isPrimaryAvailable) {
        try {
          await this.primaryBus.publish(event);
          this.metrics.recordEventLatency(event.metadata.eventType, Date.now() - startTime);
          return;
        } catch (error) {
          // Primary bus failed, mark as unavailable
          this.isPrimaryAvailable = false;
          this.logger.logError('Primary event bus failed, switching to fallback', error);
          this.metrics.incrementEventBusFailover();
        }
      }
      
      // Use fallback bus
      await this.fallbackBus.publish(event);
      this.metrics.recordEventLatency(event.metadata.eventType, Date.now() - startTime);
    } catch (error) {
      this.logger.logError('Event publication failed on all buses', error);
      this.metrics.incrementEventPublishFailure(event.metadata.eventType);
      throw error;
    }
  }

  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void {
    // Subscribe to both buses to ensure no events are missed
    const primaryUnsubscribe = this.primaryBus.subscribe(callback, filter);
    const fallbackUnsubscribe = this.fallbackBus.subscribe(callback, filter);
    
    // Return combined unsubscribe function
    return () => {
      primaryUnsubscribe();
      fallbackUnsubscribe();
    };
  }

  private startHealthCheck(intervalMs: number): void {
    this.healthCheckInterval = setInterval(async () => {
      try {
        // Implement health check for primary bus
        // This is a simplified example - actual implementation would depend on the bus type
        const isHealthy = await this.checkPrimaryBusHealth();
        
        if (isHealthy && !this.isPrimaryAvailable) {
          this.isPrimaryAvailable = true;
          this.logger.logInfo('Primary event bus is available again');
          this.metrics.incrementEventBusRecovery();
        } else if (!isHealthy && this.isPrimaryAvailable) {
          this.isPrimaryAvailable = false;
          this.logger.logWarning('Primary event bus is unavailable, using fallback');
          this.metrics.incrementEventBusFailover();
        }
      } catch (error) {
        this.logger.logError('Error during event bus health check', error);
      }
    }, intervalMs);
  }

  private async checkPrimaryBusHealth(): Promise<boolean> {
    // Implementation depends on the specific bus type
    if (this.primaryBus instanceof KafkaEventBus) {
      return await (this.primaryBus as KafkaEventBus).isHealthy();
    }
    
    // Default to true for other bus types that don't expose health check
    return true;
  }

  public stopHealthCheck(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }
}
```

### 2. Implementação Kafka Otimizada

Implementação de um barramento de eventos baseado em Kafka com configurações otimizadas para alta disponibilidade e throughput:

```typescript
// src/infrastructure/event-bus/kafka-event-bus.ts

import { Kafka, Producer, Consumer, CompressionTypes, logLevel } from 'kafkajs';
import { DomainEvent } from '../../domain/events/base-event';
import { EventBus } from './event-bus';
import { EventLogger } from '../logging/event-logger';
import { MetricsCollector } from '../metrics/metrics-collector';
import { RetryBackoff } from '../utils/retry-backoff';

export interface KafkaEventBusConfig {
  brokers: string[];
  clientId: string;
  groupId: string;
  topic: string;
  partitions?: number;
  replicationFactor?: number;
  compressionType?: CompressionTypes;
  maxRetries?: number;
  initialRetryTimeMs?: number;
  maxRetryTimeMs?: number;
  acks?: number; // -1 = all, 0 = none, 1 = leader
  idempotent?: boolean;
  batchSize?: number;
  linger?: number; // ms
}

export class KafkaEventBus implements EventBus {
  private kafka: Kafka;
  private producer: Producer;
  private consumer: Consumer;
  private config: Required<KafkaEventBusConfig>;
  private logger: EventLogger;
  private metrics: MetricsCollector;
  private isConnected: boolean = false;
  private isConsuming: boolean = false;
  private subscribers: Array<{
    callback: (event: DomainEvent) => void | Promise<void>;
    filter?: (event: DomainEvent) => boolean;
  }> = [];
  private retryBackoff: RetryBackoff;

  constructor(
    config: KafkaEventBusConfig,
    logger: EventLogger,
    metrics: MetricsCollector
  ) {
    // Set defaults for optional config
    this.config = {
      ...config,
      partitions: config.partitions || 10,
      replicationFactor: config.replicationFactor || 3,
      compressionType: config.compressionType || CompressionTypes.GZIP,
      maxRetries: config.maxRetries || 5,
      initialRetryTimeMs: config.initialRetryTimeMs || 100,
      maxRetryTimeMs: config.maxRetryTimeMs || 30000,
      acks: config.acks !== undefined ? config.acks : -1, // Default to all replicas
      idempotent: config.idempotent !== undefined ? config.idempotent : true,
      batchSize: config.batchSize || 16384, // 16KB
      linger: config.linger || 5, // 5ms
    };

    this.logger = logger;
    this.metrics = metrics;
    this.retryBackoff = new RetryBackoff(
      this.config.maxRetries,
      this.config.initialRetryTimeMs,
      this.config.maxRetryTimeMs
    );

    // Initialize Kafka
    this.kafka = new Kafka({
      clientId: this.config.clientId,
      brokers: this.config.brokers,
      logLevel: logLevel.ERROR,
      retry: {
        initialRetryTime: this.config.initialRetryTimeMs,
        retries: this.config.maxRetries,
      },
    });

    // Initialize producer with optimized settings
    this.producer = this.kafka.producer({
      allowAutoTopicCreation: true,
      idempotent: this.config.idempotent,
      maxInFlightRequests: 5,
      transactionalId: `${this.config.clientId}-producer`,
    });

    // Initialize consumer
    this.consumer = this.kafka.consumer({
      groupId: this.config.groupId,
      maxBytesPerPartition: 1048576, // 1MB
      sessionTimeout: 30000, // 30s
      heartbeatInterval: 3000, // 3s
    });
  }

  async connect(): Promise<void> {
    if (this.isConnected) {
      return;
    }

    try {
      this.logger.logInfo('Connecting to Kafka');
      
      // Connect producer
      await this.producer.connect();
      
      // Connect consumer
      await this.consumer.connect();
      
      // Create topic if it doesn't exist
      const admin = this.kafka.admin();
      await admin.connect();
      
      const topics = await admin.listTopics();
      if (!topics.includes(this.config.topic)) {
        await admin.createTopics({
          topics: [{
            topic: this.config.topic,
            numPartitions: this.config.partitions,
            replicationFactor: this.config.replicationFactor,
            configEntries: [
              { name: 'retention.ms', value: '604800000' }, // 7 days
              { name: 'cleanup.policy', value: 'delete' },
              { name: 'min.insync.replicas', value: '2' },
            ],
          }],
        });
        this.logger.logInfo(`Created Kafka topic: ${this.config.topic}`);
      }
      
      await admin.disconnect();
      
      this.isConnected = true;
      this.logger.logInfo('Connected to Kafka');
      this.metrics.incrementEventBusConnection();
      
      // Start consuming if we have subscribers
      if (this.subscribers.length > 0 && !this.isConsuming) {
        await this.startConsuming();
      }
    } catch (error) {
      this.logger.logError('Failed to connect to Kafka', error);
      this.metrics.incrementEventBusConnectionFailure();
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    if (!this.isConnected) {
      return;
    }

    try {
      this.logger.logInfo('Disconnecting from Kafka');
      
      // Stop consuming
      if (this.isConsuming) {
        await this.consumer.stop();
        this.isConsuming = false;
      }
      
      // Disconnect consumer and producer
      await this.consumer.disconnect();
      await this.producer.disconnect();
      
      this.isConnected = false;
      this.logger.logInfo('Disconnected from Kafka');
    } catch (error) {
      this.logger.logError('Error disconnecting from Kafka', error);
      throw error;
    }
  }

  async publish(event: DomainEvent): Promise<void> {
    if (!this.isConnected) {
      await this.connect();
    }

    const startTime = Date.now();
    
    try {
      // Determine partition key based on aggregate ID to ensure ordering
      const key = `${event.metadata.aggregateType}-${event.metadata.aggregateId}`;
      
      // Publish with retry logic
      await this.retryBackoff.execute(async () => {
        await this.producer.send({
          topic: this.config.topic,
          compression: this.config.compressionType,
          acks: this.config.acks,
          messages: [{
            key,
            value: JSON.stringify(event),
            headers: {
              eventType: event.metadata.eventType,
              aggregateType: event.metadata.aggregateType,
              timestamp: event.metadata.timestamp.toString(),
              version: event.metadata.version.toString(),
            },
          }],
        });
      });
      
      this.metrics.recordEventLatency(event.metadata.eventType, Date.now() - startTime);
      this.logger.logDebug(`Published event ${event.metadata.eventType} to Kafka`);
    } catch (error) {
      this.metrics.incrementEventPublishFailure(event.metadata.eventType);
      this.logger.logError(`Failed to publish event ${event.metadata.eventType} to Kafka`, error);
      throw error;
    }
  }

  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void {
    const subscription = { callback, filter };
    this.subscribers.push(subscription);
    
    // Start consuming if connected but not already consuming
    if (this.isConnected && !this.isConsuming) {
      this.startConsuming().catch(error => {
        this.logger.logError('Failed to start consuming after subscription', error);
      });
    }
    
    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(subscription);
      if (index !== -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  async isHealthy(): Promise<boolean> {
    try {
      const admin = this.kafka.admin();
      await admin.connect();
      const topics = await admin.listTopics();
      await admin.disconnect();
      return topics.includes(this.config.topic);
    } catch (error) {
      this.logger.logError('Kafka health check failed', error);
      return false;
    }
  }

  private async startConsuming(): Promise<void> {
    if (this.isConsuming || this.subscribers.length === 0) {
      return;
    }

    try {
      await this.consumer.subscribe({
        topic: this.config.topic,
        fromBeginning: false,
      });
      
      await this.consumer.run({
        partitionsConsumedConcurrently: 3,
        eachMessage: async ({ message }) => {
          try {
            if (!message.value) return;
            
            const startTime = Date.now();
            const event = JSON.parse(message.value.toString()) as DomainEvent;
            
            this.metrics.incrementEventConsumed(event.metadata.eventType);
            this.logger.logDebug(`Consumed event ${event.metadata.eventType} from Kafka`);
            
            // Notify subscribers
            await this.notifySubscribers(event);
            
            this.metrics.recordEventProcessingTime(
              event.metadata.eventType,
              Date.now() - startTime
            );
          } catch (error) {
            this.logger.logError('Error processing Kafka message', error);
            this.metrics.incrementEventProcessingFailure();
          }
        },
      });
      
      this.isConsuming = true;
      this.logger.logInfo('Started consuming from Kafka topic');
    } catch (error) {
      this.logger.logError('Failed to start consuming from Kafka', error);
      throw error;
    }
  }

  private async notifySubscribers(event: DomainEvent): Promise<void> {
    const promises: Promise<void>[] = [];
    
    for (const subscriber of this.subscribers) {
      if (!subscriber.filter || subscriber.filter(event)) {
        try {
          const result = subscriber.callback(event);
          if (result instanceof Promise) {
            promises.push(result);
          }
        } catch (error) {
          this.logger.logError('Error in event subscriber', error);
          this.metrics.incrementEventSubscriberFailure();
        }
      }
    }
    
    // Wait for all async subscribers to complete
    if (promises.length > 0) {
      await Promise.all(promises);
    }
  }
}
```

### 3. Barramento de Eventos Local para Edge Devices

Implementação de um barramento de eventos local para dispositivos edge, com capacidade de sincronização com o barramento central:

```typescript
// src/edge/event-bus/edge-event-bus.ts

import { DomainEvent } from '../../domain/events/base-event';
import { EventBus } from '../../infrastructure/event-bus/event-bus';
import { LocalStorage } from '../storage/local-storage';
import { NetworkMonitor } from '../network/network-monitor';
import { EdgeLogger } from '../logging/edge-logger';

export class EdgeEventBus implements EventBus {
  private localStorage: LocalStorage;
  private centralBus: EventBus | null;
  private networkMonitor: NetworkMonitor;
  private logger: EdgeLogger;
  private subscribers: Array<{
    callback: (event: DomainEvent) => void | Promise<void>;
    filter?: (event: DomainEvent) => boolean;
  }> = [];
  private pendingEvents: DomainEvent[] = [];
  private syncInterval: NodeJS.Timeout | null = null;

  constructor(
    localStorage: LocalStorage,
    networkMonitor: NetworkMonitor,
    logger: EdgeLogger,
    centralBus?: EventBus,
    syncIntervalMs: number = 60000
  ) {
    this.localStorage = localStorage;
    this.centralBus = centralBus || null;
    this.networkMonitor = networkMonitor;
    this.logger = logger;
    
    // Load pending events from storage
    this.loadPendingEvents();
    
    // Set up network status change handler
    this.networkMonitor.onStatusChange(this.handleNetworkStatusChange.bind(this));
    
    // Start sync interval
    this.startSyncInterval(syncIntervalMs);
  }

  async publish(event: DomainEvent): Promise<void> {
    // Always notify local subscribers immediately
    await this.notifySubscribers(event);
    
    // Try to publish to central bus if online
    if (this.centralBus && this.networkMonitor.isOnline()) {
      try {
        await this.centralBus.publish(event);
        this.logger.log('Published event to central bus', { eventType: event.metadata.eventType });
        return;
      } catch (error) {
        this.logger.error('Failed to publish to central bus, storing locally', { error });
        // Fall through to local storage
      }
    }
    
    // Store event locally for later sync
    this.pendingEvents.push(event);
    await this.savePendingEvents();
    this.logger.log('Stored event locally for later sync', { eventType: event.metadata.eventType });
  }

  subscribe(
    callback: (event: DomainEvent) => void | Promise<void>,
    filter?: (event: DomainEvent) => boolean
  ): () => void {
    const subscription = { callback, filter };
    this.subscribers.push(subscription);
    
    // Return unsubscribe function
    return () => {
      const index = this.subscribers.indexOf(subscription);
      if (index !== -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  setCentralBus(centralBus: EventBus): void {
    this.centralBus = centralBus;
    
    // Try to sync pending events immediately
    if (this.networkMonitor.isOnline()) {
      this.syncPendingEvents();
    }
  }

  private async notifySubscribers(event: DomainEvent): Promise<void> {
    const promises: Promise<void>[] = [];
    
    for (const subscriber of this.subscribers) {
      if (!subscriber.filter || subscriber.filter(event)) {
        try {
          const result = subscriber.callback(event);
          if (result instanceof Promise) {
            promises.push(result);
          }
        } catch (error) {
          this.logger.error('Error in event subscriber', { error });
        }
      }
    }
    
    // Wait for all async subscribers to complete
    if (promises.length > 0) {
      await Promise.all(promises);
    }
  }

  private async loadPendingEvents(): Promise<void> {
    try {
      const storedEvents = await this.localStorage.getItem('pendingEvents');
      if (storedEvents) {
        this.pendingEvents = JSON.parse(storedEvents);
        this.logger.log(`Loaded ${this.pendingEvents.length} pending events from storage`);
      }
    } catch (error) {
      this.logger.error('Failed to load pending events', { error });
    }
  }

  private async savePendingEvents(): Promise<void> {
    try {
      await this.localStorage.setItem('pendingEvents', JSON.stringify(this.pendingEvents));
    } catch (error) {
      this.logger.error('Failed to save pending events', { error });
    }
  }

  private async syncPendingEvents(): Promise<void> {
    if (!this.centralBus || !this.networkMonitor.isOnline() || this.pendingEvents.length === 0) {
      return;
    }

    this.logger.log(`Attempting to sync ${this.pendingEvents.length} pending events`);
    
    // Create a copy of pending events and clear the original array
    // This prevents new events from being lost if sync fails
    const eventsToSync = [...this.pendingEvents];
    
    try {
      // Process events in batches to avoid overwhelming the network
      const batchSize = 10;
      for (let i = 0; i < eventsToSync.length; i += batchSize) {
        const batch = eventsToSync.slice(i, i + batchSize);
        
        // Publish each event in the batch
        for (const event of batch) {
          await this.centralBus.publish(event);
        }
        
        // Remove successfully synced events from pending list
        this.pendingEvents = this.pendingEvents.filter(
          event => !batch.some(e => e.metadata.eventId === event.metadata.eventId)
        );
        
        // Save updated pending events
        await this.savePendingEvents();
        
        this.logger.log(`Synced batch of ${batch.length} events, ${this.pendingEvents.length} remaining`);
        
        // If we've gone offline during sync, stop
        if (!this.networkMonitor.isOnline()) {
          this.logger.log('Network connection lost during sync, will retry later');
          break;
        }
      }
    } catch (error) {
      this.logger.error('Error syncing pending events', { error });
    }
  }

  private handleNetworkStatusChange(isOnline: boolean): void {
    if (isOnline && this.centralBus) {
      this.logger.log('Network connection restored, syncing pending events');
      this.syncPendingEvents();
    }
  }

  private startSyncInterval(intervalMs: number): void {
    this.syncInterval = setInterval(() => {
      if (this.networkMonitor.isOnline() && this.centralBus) {
        this.syncPendingEvents();
      }
    }, intervalMs);
  }

  public stopSyncInterval(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }
}
```

### 4. Utilitário de Retry com Backoff Exponencial

Implementação de um utilitário para retry com backoff exponencial:

```typescript
// src/infrastructure/utils/retry-backoff.ts

export class RetryBackoff {
  private maxRetries: number;
  private initialDelayMs: number;
  private maxDelayMs: number;

  constructor(
    maxRetries: number = 5,
    initialDelayMs: number = 100,
    maxDelayMs: number = 30000
  ) {
    this.maxRetries = maxRetries;
    this.initialDelayMs = initialDelayMs;
    this.maxDelayMs = maxDelayMs;
  }

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt === this.maxRetries) {
          break;
        }
        
        // Calculate delay with exponential backoff and jitter
        const delay = Math.min(
          this.maxDelayMs,
          this.initialDelayMs * Math.pow(2, attempt)
        );
        
        // Add jitter to prevent thundering herd
        const jitteredDelay = delay * (0.5 + Math.random());
        
        await new Promise(resolve => setTimeout(resolve, jitteredDelay));
      }
    }
    
    throw lastError || new Error('Operation failed after retries');
  }
}
```

### 5. Monitoramento e Métricas para o Barramento de Eventos

Implementação de coleta de métricas para o barramento de eventos:

```typescript
// src/infrastructure/metrics/metrics-collector.ts

export interface MetricsCollector {
  incrementEventPublished(eventType: string): void;
  incrementEventConsumed(eventType: string): void;
  incrementEventPublishFailure(eventType: string): void;
  incrementEventProcessingFailure(): void;
  incrementEventSubscriberFailure(): void;
  incrementEventBusConnection(): void;
  incrementEventBusConnectionFailure(): void;
  incrementEventBusFailover(): void;
  incrementEventBusRecovery(): void;
  recordEventLatency(eventType: string, latencyMs: number): void;
  recordEventProcessingTime(eventType: string, processingTimeMs: number): void;
}

// src/infrastructure/metrics/prometheus-metrics-collector.ts

import { Counter, Gauge, Histogram, Registry } from 'prom-client';
import { MetricsCollector } from './metrics-collector';

export class PrometheusMetricsCollector implements MetricsCollector {
  private registry: Registry;
  
  // Counters
  private eventPublished: Counter;
  private eventConsumed: Counter;
  private eventPublishFailure: Counter;
  private eventProcessingFailure: Counter;
  private eventSubscriberFailure: Counter;
  private eventBusConnection: Counter;
  private eventBusConnectionFailure: Counter;
  private eventBusFailover: Counter;
  private eventBusRecovery: Counter;
  
  // Histograms
  private eventLatency: Histogram;
  private eventProcessingTime: Histogram;
  
  // Gauges
  private pendingEvents: Gauge;

  constructor(registry: Registry) {
    this.registry = registry;
    
    // Initialize counters
    this.eventPublished = new Counter({
      name: 'event_bus_events_published_total',
      help: 'Total number of events published',
      labelNames: ['event_type'],
      registers: [this.registry],
    });
    
    this.eventConsumed = new Counter({
      name: 'event_bus_events_consumed_total',
      help: 'Total number of events consumed',
      labelNames: ['event_type'],
      registers: [this.registry],
    });
    
    this.eventPublishFailure = new Counter({
      name: 'event_bus_publish_failures_total',
      help: 'Total number of event publish failures',
      labelNames: ['event_type'],
      registers: [this.registry],
    });
    
    this.eventProcessingFailure = new Counter({
      name: 'event_bus_processing_failures_total',
      help: 'Total number of event processing failures',
      registers: [this.registry],
    });
    
    this.eventSubscriberFailure = new Counter({
      name: 'event_bus_subscriber_failures_total',
      help: 'Total number of event subscriber failures',
      registers: [this.registry],
    });
    
    this.eventBusConnection = new Counter({
      name: 'event_bus_connections_total',
      help: 'Total number of event bus connections',
      registers: [this.registry],
    });
    
    this.eventBusConnectionFailure = new Counter({
      name: 'event_bus_connection_failures_total',
      help: 'Total number of event bus connection failures',
      registers: [this.registry],
    });
    
    this.eventBusFailover = new Counter({
      name: 'event_bus_failovers_total',
      help: 'Total number of event bus failovers',
      registers: [this.registry],
    });
    
    this.eventBusRecovery = new Counter({
      name: 'event_bus_recoveries_total',
      help: 'Total number of event bus recoveries',
      registers: [this.registry],
    });
    
    // Initialize histograms
    this.eventLatency = new Histogram({
      name: 'event_bus_publish_latency_milliseconds',
      help: 'Event publish latency in milliseconds',
      labelNames: ['event_type'],
      buckets: [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
      registers: [this.registry],
    });
    
    this.eventProcessingTime = new Histogram({
      name: 'event_bus_processing_time_milliseconds',
      help: 'Event processing time in milliseconds',
      labelNames: ['event_type'],
      buckets: [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
      registers: [this.registry],
    });
    
    // Initialize gauges
    this.pendingEvents = new Gauge({
      name: 'event_bus_pending_events',
      help: 'Number of events pending publication',
      registers: [this.registry],
    });
  }

  incrementEventPublished(eventType: string): void {
    this.eventPublished.inc({ event_type: eventType });
  }

  incrementEventConsumed(eventType: string): void {
    this.eventConsumed.inc({ event_type: eventType });
  }

  incrementEventPublishFailure(eventType: string): void {
    this.eventPublishFailure.inc({ event_type: eventType });
  }

  incrementEventProcessingFailure(): void {
    this.eventProcessingFailure.inc();
  }

  incrementEventSubscriberFailure(): void {
    this.eventSubscriberFailure.inc();
  }

  incrementEventBusConnection(): void {
    this.eventBusConnection.inc();
  }

  incrementEventBusConnectionFailure(): void {
    this.eventBusConnectionFailure.inc();
  }

  incrementEventBusFailover(): void {
    this.eventBusFailover.inc();
  }

  incrementEventBusRecovery(): void {
    this.eventBusRecovery.inc();
  }

  recordEventLatency(eventType: string, latencyMs: number): void {
    this.eventLatency.observe({ event_type: eventType }, latencyMs);
  }

  recordEventProcessingTime(eventType: string, processingTimeMs: number): void {
    this.eventProcessingTime.observe({ event_type: eventType }, processingTimeMs);
  }

  setPendingEvents(count: number): void {
    this.pendingEvents.set(count);
  }
}
```

### 6. Configuração de Alta Disponibilidade para Kafka

Configuração de cluster Kafka para alta disponibilidade:

```typescript
// src/infrastructure/config/kafka-config.ts

export interface KafkaClusterConfig {
  brokers: string[];
  clientId: string;
  groupId: string;
  topic: string;
  replicationFactor: number;
  partitions: number;
  minInSyncReplicas: number;
}

export const developmentConfig: KafkaClusterConfig = {
  brokers: ['localhost:9092'],
  clientId: 'bazex-dev',
  groupId: 'bazex-consumer-dev',
  topic: 'bazex-events-dev',
  replicationFactor: 1,
  partitions: 3,
  minInSyncReplicas: 1,
};

export const stagingConfig: KafkaClusterConfig = {
  brokers: [
    'kafka-0.staging.bazex.com:9092',
    'kafka-1.staging.bazex.com:9092',
    'kafka-2.staging.bazex.com:9092',
  ],
  clientId: 'bazex-staging',
  groupId: 'bazex-consumer-staging',
  topic: 'bazex-events-staging',
  replicationFactor: 3,
  partitions: 10,
  minInSyncReplicas: 2,
};

export const productionConfig: KafkaClusterConfig = {
  brokers: [
    'kafka-0.production.bazex.com:9092',
    'kafka-1.production.bazex.com:9092',
    'kafka-2.production.bazex.com:9092',
    'kafka-3.production.bazex.com:9092',
    'kafka-4.production.bazex.com:9092',
  ],
  clientId: 'bazex-production',
  groupId: 'bazex-consumer-production',
  topic: 'bazex-events-production',
  replicationFactor: 3,
  partitions: 30,
  minInSyncReplicas: 2,
};

export function getKafkaConfig(environment: string): KafkaClusterConfig {
  switch (environment) {
    case 'production':
      return productionConfig;
    case 'staging':
      return stagingConfig;
    case 'development':
    default:
      return developmentConfig;
  }
}
```

### 7. Integração com o Sistema de Event Sourcing

Integração do barramento de eventos com o sistema de Event Sourcing:

```typescript
// src/application/event-store/event-store-event-bus-integration.ts

import { DomainEvent } from '../../domain/events/base-event';
import { EventStore } from './event-store';
import { EventBus } from '../../infrastructure/event-bus/event-bus';
import { EventLogger } from '../../infrastructure/logging/event-logger';

export class EventStoreEventBusIntegration {
  constructor(
    private eventStore: EventStore,
    private eventBus: EventBus,
    private logger: EventLogger
  ) {
    this.setupIntegration();
  }

  private setupIntegration(): void {
    // Subscribe to event store events and publish to event bus
    this.eventStore.subscribeToEvents(async (event) => {
      try {
        await this.eventBus.publish(event);
      } catch (error) {
        this.logger.logError('Failed to publish event store event to event bus', error);
      }
    });

    // Log integration setup
    this.logger.logInfo('Event store to event bus integration set up');
  }

  // Method to replay historical events to the event bus
  async replayEvents(
    fromTimestamp?: number,
    toTimestamp?: number,
    aggregateType?: string
  ): Promise<number> {
    this.logger.logInfo('Starting event replay to event bus', {
      fromTimestamp,
      toTimestamp,
      aggregateType,
    });

    const events = await this.eventStore.getAllEvents(
      aggregateType,
      fromTimestamp,
      toTimestamp
    );

    this.logger.logInfo(`Replaying ${events.length} events to event bus`);

    let publishedCount = 0;
    for (const event of events) {
      try {
        await this.eventBus.publish(event);
        publishedCount++;
        
        // Log progress periodically
        if (publishedCount % 100 === 0) {
          this.logger.logInfo(`Replayed ${publishedCount}/${events.length} events`);
        }
      } catch (error) {
        this.logger.logError(`Failed to replay event ${event.metadata.eventId}`, error);
      }
    }

    this.logger.logInfo(`Completed event replay: ${publishedCount}/${events.length} events published`);
    return publishedCount;
  }
}
```

## Configuração e Inicialização

Exemplo de configuração e inicialização do barramento de eventos:

```typescript
// src/infrastructure/bootstrap/event-bus-bootstrap.ts

import { Registry } from 'prom-client';
import { KafkaEventBus } from '../event-bus/kafka-event-bus';
import { InMemoryEventBus } from '../event-bus/in-memory-event-bus';
import { LayeredEventBus } from '../event-bus/layered-event-bus';
import { PrometheusMetricsCollector } from '../metrics/prometheus-metrics-collector';
import { ConsoleEventLogger } from '../logging/console-event-logger';
import { getKafkaConfig } from '../config/kafka-config';

export async function bootstrapEventBus(
  environment: string,
  registry: Registry
): Promise<LayeredEventBus> {
  const logger = new ConsoleEventLogger();
  const metrics = new PrometheusMetricsCollector(registry);
  
  logger.logInfo('Bootstrapping event bus', { environment });
  
  // Create Kafka event bus (primary)
  const kafkaConfig = getKafkaConfig(environment);
  const kafkaEventBus = new KafkaEventBus(
    {
      brokers: kafkaConfig.brokers,
      clientId: kafkaConfig.clientId,
      groupId: kafkaConfig.groupId,
      topic: kafkaConfig.topic,
      replicationFactor: kafkaConfig.replicationFactor,
      partitions: kafkaConfig.partitions,
    },
    logger,
    metrics
  );
  
  // Create in-memory event bus (fallback)
  const inMemoryEventBus = new InMemoryEventBus();
  
  // Create layered event bus
  const layeredEventBus = new LayeredEventBus(
    kafkaEventBus,
    inMemoryEventBus,
    logger,
    metrics
  );
  
  // Connect to Kafka
  try {
    await kafkaEventBus.connect();
    logger.logInfo('Successfully connected to Kafka');
  } catch (error) {
    logger.logError('Failed to connect to Kafka, will use in-memory fallback', error);
  }
  
  return layeredEventBus;
}
```

## Benefícios da Implementação

1. **Alta Disponibilidade**: O barramento de eventos continua operando mesmo em caso de falhas parciais.
2. **Escalabilidade Horizontal**: Capacidade de escalar horizontalmente para lidar com aumento de carga.
3. **Resiliência**: Mecanismos de retry, circuit breaker e fallback garantem operação contínua.
4. **Garantia de Entrega**: Eventos são entregues pelo menos uma vez, mesmo em caso de falhas.
5. **Observabilidade**: Monitoramento detalhado do fluxo de eventos para identificação rápida de problemas.
6. **Operação Offline**: Dispositivos edge podem continuar operando offline e sincronizar quando voltarem online.

## Considerações para o MVP

Para a fase inicial de desenvolvimento (MVP), o barramento de eventos deve focar em:

1. Implementação básica do barramento de eventos com Kafka.
2. Mecanismos de fallback para operação contínua.
3. Monitoramento básico para identificação de problemas.
4. Integração com o sistema de Event Sourcing.

Recursos avançados como particionamento avançado, compactação de logs e replicação cross-region podem ser adicionados em fases posteriores.

## Conclusão

Esta implementação de barramento de eventos otimizado para escalabilidade e resiliência resolve os problemas de comunicação assíncrona da BazeX/QBeeX. O sistema garante:

1. **Alta Disponibilidade**: Operação contínua mesmo em caso de falhas parciais.
2. **Escalabilidade**: Capacidade de lidar com aumento de carga.
3. **Resiliência**: Mecanismos de retry, circuit breaker e fallback.
4. **Garantia de Entrega**: Eventos são entregues pelo menos uma vez.
5. **Observabilidade**: Monitoramento detalhado do fluxo de eventos.

Esta solução elimina os gargalos de comunicação identificados na revisão técnica e fornece uma base sólida para a integração perfeita entre frontend, backend e componentes IoT da plataforma BazeX/QBeeX.
