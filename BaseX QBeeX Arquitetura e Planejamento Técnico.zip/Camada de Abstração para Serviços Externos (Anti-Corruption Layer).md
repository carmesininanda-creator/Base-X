# Camada de Abstração para Serviços Externos (Anti-Corruption Layer)

## Visão Geral da Solução

Para aumentar a resiliência e desacoplar as integrações core da BazeX/QBeeX de serviços externos, implementaremos uma Camada de Abstração, também conhecida como Anti-Corruption Layer (ACL). Esta camada protegerá o domínio central da BazeX contra mudanças e instabilidades em APIs de terceiros, como Google Calendar, Gmail, Alexa, etc.

## Princípios de Design

1.  **Desacoplamento Forte**: O núcleo da BazeX não terá conhecimento direto das APIs externas. Toda a comunicação passará pela ACL.
2.  **Resiliência Integrada**: A ACL implementará padrões como Circuit Breaker, Retry com backoff exponencial, Timeouts e Fallbacks para lidar com falhas de serviços externos.
3.  **Contrato Estável**: A ACL exporá uma interface estável e bem definida para o núcleo da BazeX, independentemente das mudanças nas APIs externas.
4.  **Versionamento de Adaptadores**: Cada adaptador para um serviço externo poderá ter múltiplas versões para lidar com diferentes versões de API do serviço externo.
5.  **Monitoramento Proativo**: Mecanismos para detectar mudanças ou degradação em APIs externas.
6.  **Testabilidade**: A ACL facilitará o teste de integrações, permitindo o uso de mocks e stubs para serviços externos.

## Componentes da Solução

### 1. Interface do Adaptador de Serviço Externo (`ExternalServiceAdapter`)

Define o contrato que todos os adaptadores devem seguir.

```typescript
// src/acl/adapters/external-service-adapter.ts

export interface AdapterRequest {
  method: string; // e.g., 'getEvents', 'sendEmail'
  params: Record<string, any>;
  userId: string; // For user-specific context or credentials
  timeout?: number; // Optional request-specific timeout
}

export interface AdapterResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    type: string; // e.g., 'API_UNAVAILABLE', 'AUTH_ERROR', 'INVALID_REQUEST'
    message: string;
    details?: any;
  };
  metadata?: {
    externalApiVersionUsed?: string;
    retries?: number;
    latencyMs?: number;
  };
}

export interface ExternalServiceAdapter {
  readonly serviceName: string;
  isHealthy(): Promise<boolean>;
  request<T = any>(request: AdapterRequest): Promise<AdapterResponse<T>>;
  // Optional: specific methods for common operations if a generic request is not enough
  // getEvents?(userId: string, params: any): Promise<AdapterResponse<Event[]>>;
}
```

### 2. Implementação Base do Adaptador (`BaseAdapter`)

Classe base com funcionalidades comuns como logging, error handling básico.

```typescript
// src/acl/adapters/base-adapter.ts
import { AdapterRequest, AdapterResponse, ExternalServiceAdapter } from './external-service-adapter';
import { ResilienceManager, ResilienceOptions } from '../resilience/resilience-manager';

export abstract class BaseAdapter implements ExternalServiceAdapter {
  abstract readonly serviceName: string;
  protected resilienceManager: ResilienceManager;

  constructor(resilienceOptions?: ResilienceOptions) {
    this.resilienceManager = new ResilienceManager(this.serviceName, resilienceOptions);
  }

  abstract isHealthy(): Promise<boolean>;
  abstract request<T = any>(request: AdapterRequest): Promise<AdapterResponse<T>>;

  protected async handleRequest<T = any>(
    operation: () => Promise<T>,
    requestDetails: AdapterRequest
  ): Promise<AdapterResponse<T>> {
    const startTime = Date.now();
    try {
      // ResilienceManager will handle retries, circuit breaker, timeout
      const result = await this.resilienceManager.execute(operation, requestDetails.timeout);
      return {
        success: true,
        data: result,
        metadata: {
          latencyMs: Date.now() - startTime,
          // retries and api version would be set by specific adapter or resilience manager
        },
      };
    } catch (error: any) {
      // Log error internally
      console.error(`[${this.serviceName} Adapter Error] for method ${requestDetails.method}:`, error.message, error.details);
      return {
        success: false,
        error: {
          type: error.type || 'UNKNOWN_ERROR',
          message: error.message || 'An unexpected error occurred.',
          details: error.details,
        },
        metadata: {
          latencyMs: Date.now() - startTime,
        },
      };
    }
  }
}
```

### 3. Adaptadores Específicos (Exemplo: `GoogleCalendarAdapter`)

Implementa a lógica de comunicação com um serviço externo específico.

```typescript
// src/acl/adapters/google-calendar-adapter.ts
import { BaseAdapter } from './base-adapter';
import { AdapterRequest, AdapterResponse } from './external-service-adapter';
import { google, Auth, calendar_v3 } from 'googleapis'; // Assuming googleapis library
import { UserCredentialsRepository } from '../repositories/user-credentials-repository'; // To get OAuth tokens

export class GoogleCalendarAdapter extends BaseAdapter {
  readonly serviceName = 'GoogleCalendar';
  private calendar: calendar_v3.Calendar;
  private credentialsRepository: UserCredentialsRepository;

  constructor(credsRepo: UserCredentialsRepository) {
    super({ timeout: 5000, retryAttempts: 3, circuitBreakerThreshold: 0.5 });
    this.credentialsRepository = credsRepo;
    // Initialize Google API client - this is simplified
    const oauth2Client = new google.auth.OAuth2();
    this.calendar = google.calendar({ version: 'v3', auth: oauth2Client });
  }

  private async getAuthClient(userId: string): Promise<Auth.OAuth2Client> {
    const credentials = await this.credentialsRepository.getUserCredentials(userId, this.serviceName);
    if (!credentials || !credentials.accessToken) {
      throw { type: 'AUTH_ERROR', message: 'User not authenticated with Google Calendar' };
    }
    const oauth2Client = new google.auth.OAuth2();
    oauth2Client.setCredentials({ access_token: credentials.accessToken, refresh_token: credentials.refreshToken });
    // Handle token refresh if necessary (googleapis library might do this automatically)
    return oauth2Client;
  }

  async isHealthy(): Promise<boolean> {
    try {
      // A simple check, e.g., pinging a known endpoint or checking API status page
      // For Google Calendar, we might try to fetch a list of calendars for a test user
      // This is a placeholder
      const response = await fetch('https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest');
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  async request<T = any>(request: AdapterRequest): Promise<AdapterResponse<T>> {
    return this.handleRequest(async () => {
      const authClient = await this.getAuthClient(request.userId);
      this.calendar = google.calendar({ version: 'v3', auth: authClient });

      switch (request.method) {
        case 'getEvents':
          const params = request.params as calendar_v3.Params$Resource$Events$List;
          const response = await this.calendar.events.list(params);
          return response.data.items as any; // Cast to T, or define specific types
        case 'createEvent':
          const createParams = request.params as calendar_v3.Params$Resource$Events$Insert;
          const createResponse = await this.calendar.events.insert(createParams);
          return createResponse.data as any;
        // Add other methods like updateEvent, deleteEvent
        default:
          throw { type: 'INVALID_REQUEST', message: `Unsupported method: ${request.method}` };
      }
    }, request);
  }
}
```

### 4. Gerenciador de Resiliência (`ResilienceManager`)

Implementa Circuit Breaker, Retry, Timeout.

```typescript
// src/acl/resilience/resilience-manager.ts

export interface ResilienceOptions {
  timeout?: number; // milliseconds
  retryAttempts?: number;
  retryDelayMs?: number; // Base delay for exponential backoff
  circuitBreakerThreshold?: number; // Failure rate (0.0 to 1.0) to open circuit
  circuitBreakerTimeoutMs?: number; // How long circuit stays open
}

enum CircuitState { OPEN, HALF_OPEN, CLOSED }

export class ResilienceManager {
  private serviceName: string;
  private options: Required<ResilienceOptions>;
  private failureCount = 0;
  private successCount = 0;
  private state: CircuitState = CircuitState.CLOSED;
  private lastErrorTime: number = 0;

  constructor(serviceName: string, options?: ResilienceOptions) {
    this.serviceName = serviceName;
    this.options = {
      timeout: options?.timeout || 10000,
      retryAttempts: options?.retryAttempts || 3,
      retryDelayMs: options?.retryDelayMs || 500,
      circuitBreakerThreshold: options?.circuitBreakerThreshold || 0.5,
      circuitBreakerTimeoutMs: options?.circuitBreakerTimeoutMs || 30000,
    };
  }

  public async execute<T>(operation: () => Promise<T>, requestTimeout?: number): Promise<T> {
    if (this.state === CircuitState.OPEN) {
      if (Date.now() - this.lastErrorTime > this.options.circuitBreakerTimeoutMs) {
        this.state = CircuitState.HALF_OPEN;
        // Allow one request through to test
      } else {
        throw { type: 'CIRCUIT_OPEN', message: `Circuit for ${this.serviceName} is open.` };
      }
    }

    const timeoutToUse = requestTimeout || this.options.timeout;

    for (let attempt = 1; attempt <= this.options.retryAttempts; attempt++) {
      try {
        const result = await this.executeWithTimeout(operation, timeoutToUse);
        this.handleSuccess();
        return result;
      } catch (error: any) {
        if (attempt === this.options.retryAttempts || error.type === 'CIRCUIT_OPEN') {
          this.handleFailure(error);
          throw error; // Rethrow after max attempts or if circuit is open
        }
        // Exponential backoff
        const delay = this.options.retryDelayMs * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    // Should not be reached due to rethrow in catch block
    throw { type: 'MAX_RETRIES_REACHED', message: 'Max retries reached.' }; 
  }

  private async executeWithTimeout<T>(operation: () => Promise<T>, timeoutMs: number): Promise<T> {
    let timeoutId: NodeJS.Timeout;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => {
        reject({ type: 'TIMEOUT_ERROR', message: `Operation timed out after ${timeoutMs}ms` });
      }, timeoutMs);
    });

    try {
      return await Promise.race([operation(), timeoutPromise]);
    } finally {
      clearTimeout(timeoutId!);
    }
  }

  private handleSuccess() {
    this.successCount++;
    if (this.state === CircuitState.HALF_OPEN) {
      this.resetCircuit();
    }
    // Optionally, decay failureCount over time if not using a sliding window
  }

  private handleFailure(error: any) {
    this.failureCount++;
    this.lastErrorTime = Date.now();

    if (this.state === CircuitState.HALF_OPEN) {
      this.tripCircuit(); // Re-trip if half-open attempt fails
      return;
    }

    // Check if failure rate exceeds threshold (simplified)
    // A proper implementation would use a sliding window or time-based counter
    const totalRequests = this.successCount + this.failureCount;
    if (totalRequests > 10 && (this.failureCount / totalRequests) > this.options.circuitBreakerThreshold) {
      this.tripCircuit();
    }
  }

  private tripCircuit() {
    console.warn(`[ResilienceManager] Circuit for ${this.serviceName} is now OPEN.`);
    this.state = CircuitState.OPEN;
    this.lastErrorTime = Date.now(); // Record time when circuit tripped
  }

  private resetCircuit() {
    console.info(`[ResilienceManager] Circuit for ${this.serviceName} is now CLOSED.`);
    this.state = CircuitState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
  }
}
```

### 5. Registro de Serviços (`ServiceRegistry`)

Centraliza o acesso aos adaptadores.

```typescript
// src/acl/service-registry.ts
import { ExternalServiceAdapter } from './adapters/external-service-adapter';

export class ServiceRegistry {
  private static adapters: Map<string, ExternalServiceAdapter> = new Map();

  public static registerAdapter(adapter: ExternalServiceAdapter): void {
    if (this.adapters.has(adapter.serviceName)) {
      console.warn(`Adapter for ${adapter.serviceName} is already registered. Overwriting.`);
    }
    this.adapters.set(adapter.serviceName, adapter);
  }

  public static getAdapter(serviceName: string): ExternalServiceAdapter | undefined {
    return this.adapters.get(serviceName);
  }

  public static async checkAllServicesHealth(): Promise<Record<string, boolean>> {
    const healthStatus: Record<string, boolean> = {};
    for (const [name, adapter] of this.adapters) {
      healthStatus[name] = await adapter.isHealthy();
    }
    return healthStatus;
  }
}

// Example registration (e.g., in main application setup)
// import { GoogleCalendarAdapter } from './adapters/google-calendar-adapter';
// import { UserCredentialsRepository } from './repositories/user-credentials-repository';
// const credsRepo = new UserCredentialsRepository(); /* initialize */
// ServiceRegistry.registerAdapter(new GoogleCalendarAdapter(credsRepo));
```

### 6. Monitor de API Externa (`ApiMonitor` - Conceitual)

Este componente seria responsável por monitorar ativamente as APIs externas para detectar mudanças (ex: versionamento, campos obsoletos, quebras de contrato). Poderia usar:
*   **Health Checks Regulares**: Chamadas periódicas a endpoints de status ou operações simples.
*   **Canary Releases de Adaptadores**: Testar novas versões de adaptadores com um subconjunto de tráfego.
*   **Análise de Logs de Erro**: Identificar padrões de erro que indiquem problemas com a API externa.
*   **Alertas**: Notificar administradores sobre problemas detectados.

(A implementação completa do `ApiMonitor` é complexa e fora do escopo deste exemplo inicial, mas é um componente vital para a manutenção a longo prazo.)

### 7. Repositório de Credenciais de Usuário (`UserCredentialsRepository` - Conceitual)

Responsável por armazenar e fornecer de forma segura as credenciais (ex: OAuth tokens) que os adaptadores precisam para interagir com serviços externos em nome do usuário.

```typescript
// src/acl/repositories/user-credentials-repository.ts

export interface UserExternalCredentials {
  userId: string;
  serviceName: string;
  accessToken: string;
  refreshToken?: string;
  expiresAt?: Date;
  scopes: string[];
  // other service-specific metadata
}

export interface UserCredentialsRepository {
  getUserCredentials(userId: string, serviceName: string): Promise<UserExternalCredentials | null>;
  saveUserCredentials(credentials: UserExternalCredentials): Promise<void>;
  deleteUserCredentials(userId: string, serviceName: string): Promise<void>;
}

// Implementations would use a secure database (e.g., PostgreSQL with encryption)
// or a dedicated secrets manager.
```

## Integração com o Núcleo da BazeX

O sistema core da BazeX interagiria com os serviços externos exclusivamente através do `ServiceRegistry` e dos adaptadores.

```typescript
// src/core/services/calendar-integration-service.ts
import { ServiceRegistry } from '../../acl/service-registry';
import { AdapterRequest } from '../../acl/adapters/external-service-adapter';

export class CalendarIntegrationService {
  private adapterName = 'GoogleCalendar'; // Could be configurable

  async getUserEvents(userId: string, calendarId: string = 'primary', timeMin?: string, timeMax?: string): Promise<any[]> {
    const adapter = ServiceRegistry.getAdapter(this.adapterName);
    if (!adapter) {
      throw new Error(`Adapter for ${this.adapterName} not found.`);
    }

    const request: AdapterRequest = {
      method: 'getEvents',
      userId,
      params: {
        calendarId,
        timeMin: timeMin || new Date().toISOString(),
        timeMax,
        singleEvents: true,
        orderBy: 'startTime',
      },
    };

    const response = await adapter.request(request);

    if (response.success && response.data) {
      return response.data; // Assuming data is an array of events
    } else {
      console.error('Failed to get calendar events:', response.error);
      // Implement fallback logic if needed, e.g., return cached data or an empty array
      return [];
    }
  }
}
```

## Benefícios da Camada de Abstração

1.  **Isolamento de Mudanças**: Alterações nas APIs externas exigem apenas a atualização do adaptador correspondente, sem impactar o código do núcleo da BazeX.
2.  **Maior Resiliência**: Padrões como Circuit Breaker e Retry aumentam a tolerância a falhas temporárias dos serviços externos.
3.  **Consistência**: O núcleo da BazeX interage com uma interface padronizada para todos os serviços externos.
4.  **Facilidade de Substituição**: Se for necessário trocar um serviço externo por outro (ex: mudar de provedor de email), apenas o adaptador precisa ser substituído ou um novo adicionado.
5.  **Testes Simplificados**: O núcleo pode ser testado com adaptadores mockados, isolando-o das dependências externas.
6.  **Gerenciamento Centralizado**: Configurações de resiliência, logging e monitoramento para integrações externas são centralizadas.

## Conclusão

A implementação desta Camada de Abstração (ACL) é um passo crucial para tornar a BazeX/QBeeX uma plataforma robusta e sustentável. Ela protege o sistema contra a volatilidade inerente às integrações com serviços de terceiros, garantindo uma experiência de usuário mais estável e confiável, e facilitando a manutenção e evolução do sistema a longo prazo.
