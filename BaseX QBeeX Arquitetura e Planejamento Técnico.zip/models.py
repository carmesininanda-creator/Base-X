"""
Modelos de dados para o Auth Service
Autor: Maya Patel - Backend Developer
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional
from pydantic import BaseModel

Base = declarative_base()

class User(Base):
    """Modelo de usuário no banco de dados"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_superuser = Column(Boolean, default=False, nullable=False)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    # Campos de perfil
    avatar_url = Column(String(500), nullable=True)
    bio = Column(Text, nullable=True)
    timezone = Column(String(50), default="UTC", nullable=False)
    language = Column(String(10), default="pt-BR", nullable=False)
    
    # Configurações de privacidade
    privacy_level = Column(String(20), default="standard", nullable=False)  # minimal, standard, maximum
    data_sharing_consent = Column(Boolean, default=False, nullable=False)
    marketing_consent = Column(Boolean, default=False, nullable=False)
    
    def __repr__(self):
        return f"<User(id={self.id}, email='{self.email}', active={self.is_active})>"

class RefreshToken(Base):
    """Modelo para refresh tokens"""
    __tablename__ = "refresh_tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False, index=True)
    token_hash = Column(String(255), nullable=False, unique=True)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    is_revoked = Column(Boolean, default=False, nullable=False)
    
    # Metadados do dispositivo/sessão
    device_info = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)  # IPv6 compatible
    user_agent = Column(Text, nullable=True)

class LoginAttempt(Base):
    """Modelo para tentativas de login (segurança)"""
    __tablename__ = "login_attempts"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), nullable=False, index=True)
    ip_address = Column(String(45), nullable=False)
    success = Column(Boolean, nullable=False)
    attempted_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    user_agent = Column(Text, nullable=True)
    failure_reason = Column(String(100), nullable=True)

# Pydantic models para validação de dados

class TokenData(BaseModel):
    """Dados do token JWT"""
    user_id: Optional[int] = None
    email: Optional[str] = None
    exp: Optional[datetime] = None
    iat: Optional[datetime] = None
    
class UserBase(BaseModel):
    """Base para modelos de usuário"""
    email: str
    full_name: str
    is_active: bool = True
    timezone: str = "UTC"
    language: str = "pt-BR"

class UserCreate(BaseModel):
    """Modelo para criação de usuário"""
    email: str
    password: str
    full_name: str
    timezone: str = "UTC"
    language: str = "pt-BR"
    privacy_level: str = "standard"
    data_sharing_consent: bool = False
    marketing_consent: bool = False
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "usuario@exemplo.com",
                "password": "senhaSegura123",
                "full_name": "João Silva",
                "timezone": "America/Sao_Paulo",
                "language": "pt-BR",
                "privacy_level": "standard",
                "data_sharing_consent": False,
                "marketing_consent": False
            }
        }

class UserUpdate(BaseModel):
    """Modelo para atualização de usuário"""
    full_name: Optional[str] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    timezone: Optional[str] = None
    language: Optional[str] = None
    privacy_level: Optional[str] = None
    data_sharing_consent: Optional[bool] = None
    marketing_consent: Optional[bool] = None

class UserLogin(BaseModel):
    """Modelo para login de usuário"""
    email: str
    password: str
    remember_me: bool = False
    device_info: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "email": "usuario@exemplo.com",
                "password": "senhaSegura123",
                "remember_me": False,
                "device_info": "Chrome 119.0 on Windows 10"
            }
        }

class UserResponse(BaseModel):
    """Modelo de resposta de usuário (sem dados sensíveis)"""
    id: int
    email: str
    full_name: str
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime] = None
    avatar_url: Optional[str] = None
    bio: Optional[str] = None
    timezone: str
    language: str
    privacy_level: str
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    """Modelo de resposta de token"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # segundos
    
class TokenRefresh(BaseModel):
    """Modelo para refresh de token"""
    refresh_token: str

class PasswordChange(BaseModel):
    """Modelo para mudança de senha"""
    current_password: str
    new_password: str
    
class PasswordReset(BaseModel):
    """Modelo para reset de senha"""
    email: str
    
class PasswordResetConfirm(BaseModel):
    """Modelo para confirmação de reset de senha"""
    token: str
    new_password: str

class UserStats(BaseModel):
    """Estatísticas do usuário"""
    total_logins: int
    last_login: Optional[datetime]
    account_age_days: int
    active_sessions: int
    
class SecurityEvent(BaseModel):
    """Evento de segurança"""
    event_type: str  # login_success, login_failure, password_change, etc.
    timestamp: datetime
    ip_address: str
    user_agent: Optional[str]
    details: Optional[dict] = None

