## Melhores Práticas para Emails de Captação de Investidores e Parceiros

### Estrutura Eficaz
- **Assunto impactante:** Deve ser conciso, intrigante e específico
- **Abertura personalizada:** Demonstrar conhecimento sobre o destinatário
- **Proposta de valor clara:** Comunicar rapidamente o benefício principal
- **Elemento de urgência/escassez:** Criar senso de oportunidade limitada
- **Call-to-action específico:** Solicitar uma ação clara e direta

### Elementos Essenciais
1. **Credibilidade:** Mencionar conquistas, parcerias ou validações existentes
2. **Diferencial único:** Destacar o que torna o projeto verdadeiramente único
3. **Oportunidade de mercado:** Indicar tamanho e potencial do mercado
4. **Tração inicial:** Compartilhar métricas ou validações já alcançadas
5. **Time qualificado:** Destacar brevemente credenciais relevantes da equipe

### Proteção de Propriedade Intelectual
- Evitar detalhes técnicos específicos sobre implementação
- Não revelar algoritmos proprietários ou arquitetura detalhada
- Focar em benefícios e resultados, não em como são alcançados
- Utilizar termos amplos para descrever tecnologia ("IA avançada" vs. detalhes específicos)
- Mencionar proteções de PI existentes sem detalhar seu conteúdo

### Linguagem e Tom
- Profissional mas não excessivamente formal
- Confiante sem ser arrogante
- Entusiasta sem exageros irrealistas
- Conciso e direto, respeitando o tempo do leitor
- Focado em valor e oportunidade, não em necessidades próprias

### Elementos Visuais
- Design limpo e profissional
- Formatação que facilita leitura rápida (parágrafos curtos, bullets)
- Logo discreto mas profissional
- Evitar anexos pesados; preferir links para materiais adicionais
- Assinatura profissional com múltiplos canais de contato

### Erros a Evitar
- Emails excessivamente longos (ideal: 200-300 palavras)
- Linguagem técnica excessiva ou jargão de nicho
- Promessas irrealistas ou hipérboles
- Foco em necessidades próprias em vez de valor para o destinatário
- Múltiplos calls-to-action que confundem o próximo passo

### Exemplos de Assuntos Eficazes
- "Oportunidade reservada: Tecnologia que supera [concorrente conhecido]"
- "[Nome], podemos marcar 15 minutos para discutir o futuro da IA preditiva?"
- "Convite exclusivo: Conheça a tecnologia que está redefinindo [categoria]"
- "Parceria estratégica: Inovação em IA com potencial de [benefício específico]"
- "Reunião confidencial: Tecnologia disruptiva em IA preditiva"
