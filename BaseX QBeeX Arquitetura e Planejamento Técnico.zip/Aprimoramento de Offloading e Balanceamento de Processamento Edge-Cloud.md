# Aprimoramento de Offloading e Balanceamento de Processamento Edge-Cloud

## Visão Geral da Solução

Para otimizar o desempenho, a eficiência energética e a privacidade na plataforma BazeX/QBeeX, implementaremos um sistema adaptativo de offloading e balanceamento de processamento. Este sistema decidirá dinamicamente onde executar cada tarefa (no dispositivo edge ou na nuvem) com base em múltiplos fatores contextuais.

## Componentes da Solução

### 1. Módulo de Análise de Capacidade do Dispositivo (Edge)

Este módulo, executado em cada dispositivo edge, monitora continuamente os recursos disponíveis.

```typescript
// src/edge/capacity-analyzer.ts

export interface DeviceCapacity {
  cpuLoad: number; // 0.0 to 1.0
  memoryUsage: number; // 0.0 to 1.0
  batteryLevel: number; // 0.0 to 1.0
  isCharging: boolean;
  networkType: 'wifi' | 'cellular' | 'ethernet' | 'none';
  networkStrength: number; // 0 to 4 (e.g., signal bars)
  gpuAvailable: boolean;
}

export class CapacityAnalyzer {
  private static instance: CapacityAnalyzer;
  private capacity: DeviceCapacity;
  private intervalId: any;

  private constructor() {
    this.capacity = {
      cpuLoad: 0.1,
      memoryUsage: 0.3,
      batteryLevel: 0.8,
      isCharging: false,
      networkType: 'wifi',
      networkStrength: 3,
      gpuAvailable: true, // Assume GPU by default, can be updated
    };
    this.startMonitoring();
  }

  public static getInstance(): CapacityAnalyzer {
    if (!CapacityAnalyzer.instance) {
      CapacityAnalyzer.instance = new CapacityAnalyzer();
    }
    return CapacityAnalyzer.instance;
  }

  private async updateMetrics(): Promise<void> {
    // Placeholder: In a real scenario, use native APIs or libraries
    // to get actual device metrics.
    this.capacity.cpuLoad = Math.random() * 0.5 + 0.1; // Simulate CPU load
    this.capacity.memoryUsage = Math.random() * 0.6 + 0.2; // Simulate memory usage
    
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery = await (navigator as any).getBattery();
        this.capacity.batteryLevel = battery.level;
        this.capacity.isCharging = battery.charging;
      } catch (err) {
        // console.warn('Could not access battery status:', err);
      }
    }

    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const connection = (navigator as any).connection;
      this.capacity.networkType = connection.effectiveType || 'wifi'; // Simplification
      // Network strength is harder to get reliably, using placeholder
      this.capacity.networkStrength = connection.effectiveType === '4g' ? 4 : 3;
    } else {
        // Node.js environment (IoT device)
        // Use 'os-utils' or similar for CPU/memory
        // Use 'systeminformation' for battery/network if available
    }
  }

  private startMonitoring(): void {
    this.updateMetrics(); // Initial update
    this.intervalId = setInterval(() => this.updateMetrics(), 15000); // Update every 15s
  }

  public stopMonitoring(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  public getCurrentCapacity(): DeviceCapacity {
    return { ...this.capacity };
  }
}
```

### 2. Módulo de Decisão de Offloading (Core)

Este módulo central (pode ser replicado no edge para decisões rápidas) avalia onde executar uma tarefa.

```typescript
// src/core/offloading-decision-engine.ts
import { DeviceCapacity } from '../edge/capacity-analyzer';

export enum ProcessingLocation {
  EDGE = 'edge',
  CLOUD = 'cloud',
  HYBRID = 'hybrid', // Part on edge, part on cloud
}

export interface TaskRequirements {
  computeIntensity: 'low' | 'medium' | 'high'; // CPU/GPU needs
  memoryIntensity: 'low' | 'medium' | 'high'; // RAM needs
  dataSensitivity: 'low' | 'medium' | 'high'; // Privacy level
  latencyRequirement: 'low' | 'medium' | 'high'; // Real-time needs
  inputDataSize: number; // Size in MB
  outputDataSize: number; // Size in MB
}

export class OffloadingDecisionEngine {
  private static readonly BATTERY_THRESHOLD_LOW = 0.2;
  private static readonly BATTERY_THRESHOLD_OFFLOAD = 0.4;
  private static readonly CPU_THRESHOLD_HIGH = 0.8;
  private static readonly MEMORY_THRESHOLD_HIGH = 0.8;
  private static readonly NETWORK_STRENGTH_THRESHOLD_LOW = 1;
  private static readonly MAX_DATA_TRANSFER_EDGE_MB = 50; // Max data to prefer edge over cloud due to transfer

  public decideLocation(
    task: TaskRequirements,
    capacity: DeviceCapacity
  ): ProcessingLocation {
    // Rule 1: High data sensitivity tasks prefer edge, unless edge resources are critically low.
    if (task.dataSensitivity === 'high') {
      if (this.canRunOnEdge(task, capacity, true)) {
        return ProcessingLocation.EDGE;
      }
      // If edge is not viable, but data is highly sensitive, this is a problem.
      // For now, we might still offload if absolutely necessary, but log a privacy concern.
      console.warn('High sensitivity task offloaded due to resource constraints on edge.');
    }

    // Rule 2: Low latency tasks prefer edge if viable.
    if (task.latencyRequirement === 'low') {
      if (this.canRunOnEdge(task, capacity)) {
        return ProcessingLocation.EDGE;
      }
    }

    // Rule 3: If battery is critically low and not charging, prefer cloud if task is intensive.
    if (
      capacity.batteryLevel < OffloadingDecisionEngine.BATTERY_THRESHOLD_LOW &&
      !capacity.isCharging &&
      (task.computeIntensity === 'high' || task.memoryIntensity === 'high')
    ) {
      return ProcessingLocation.CLOUD;
    }

    // Rule 4: If network is very weak or absent, must run on edge if possible.
    if (capacity.networkType === 'none' || capacity.networkStrength <= OffloadingDecisionEngine.NETWORK_STRENGTH_THRESHOLD_LOW) {
      if (this.canRunOnEdge(task, capacity)) {
        return ProcessingLocation.EDGE;
      }
      // If cannot run on edge and network is bad, task might fail or be queued.
      // For now, assume it must attempt cloud if edge is not an option.
      console.warn('Task may fail due to poor network and insufficient edge resources.');
    }
    
    // Rule 5: Avoid large data transfers if network is not wifi or strong.
    const totalDataTransfer = task.inputDataSize + task.outputDataSize;
    if (totalDataTransfer > OffloadingDecisionEngine.MAX_DATA_TRANSFER_EDGE_MB && capacity.networkType !== 'wifi') {
        if (this.canRunOnEdge(task, capacity)) {
            // If edge can handle it, prefer edge to avoid large cellular data transfer
            return ProcessingLocation.EDGE;
        }
    }

    // Scoring system for edge vs. cloud
    let edgeScore = 0;
    let cloudScore = 0;

    // Resource availability on edge
    if (capacity.cpuLoad < OffloadingDecisionEngine.CPU_THRESHOLD_HIGH) edgeScore += 2;
    if (capacity.memoryUsage < OffloadingDecisionEngine.MEMORY_THRESHOLD_HIGH) edgeScore += 2;
    if (capacity.batteryLevel > OffloadingDecisionEngine.BATTERY_THRESHOLD_OFFLOAD || capacity.isCharging) edgeScore += 1;

    // Task requirements favoring edge
    if (task.latencyRequirement === 'low') edgeScore += 3;
    if (task.dataSensitivity === 'high') edgeScore += 3;
    if (task.dataSensitivity === 'medium') edgeScore += 1;
    if (totalDataTransfer < OffloadingDecisionEngine.MAX_DATA_TRANSFER_EDGE_MB / 2) edgeScore +=1; 

    // Network conditions favoring cloud (if good network)
    if (capacity.networkType === 'wifi' || capacity.networkStrength > 2) cloudScore += 2;
    if (totalDataTransfer > OffloadingDecisionEngine.MAX_DATA_TRANSFER_EDGE_MB) cloudScore +=1; // Large data is better handled by cloud if network is good

    // Task requirements favoring cloud
    if (task.computeIntensity === 'high') cloudScore += 2;
    if (task.memoryIntensity === 'high') cloudScore += 2;
    if (task.latencyRequirement === 'high') cloudScore +=1; // If latency is not an issue, cloud is fine

    // Decision
    if (edgeScore >= cloudScore && this.canRunOnEdge(task, capacity)) {
      return ProcessingLocation.EDGE;
    }
    return ProcessingLocation.CLOUD;
  }

  private canRunOnEdge(
    task: TaskRequirements,
    capacity: DeviceCapacity,
    isSensitiveDataOverride: boolean = false
  ): boolean {
    const cpuOk = task.computeIntensity === 'low' || 
                  (task.computeIntensity === 'medium' && capacity.cpuLoad < 0.7) || 
                  (capacity.cpuLoad < 0.5);
    const memoryOk = task.memoryIntensity === 'low' || 
                     (task.memoryIntensity === 'medium' && capacity.memoryUsage < 0.7) || 
                     (capacity.memoryUsage < 0.5);
    
    // For highly sensitive data, be more lenient with resources if forced to edge
    if (isSensitiveDataOverride) {
        return (task.computeIntensity === 'low' || capacity.cpuLoad < 0.9) && 
               (task.memoryIntensity === 'low' || capacity.memoryUsage < 0.9);
    }

    return cpuOk && memoryOk;
  }
}
```

### 3. Orquestrador de Tarefas (Core/Backend)

Este componente utiliza o `OffloadingDecisionEngine` para rotear tarefas.

```typescript
// src/core/task-orchestrator.ts
import {
  ProcessingLocation,
  TaskRequirements,
  OffloadingDecisionEngine,
} from './offloading-decision-engine';
import { CapacityAnalyzer, DeviceCapacity } from '../edge/capacity-analyzer';

// Placeholder for EdgeExecutionService and CloudExecutionService
interface ExecutionService {
  execute(task: TaskRequirements, taskId: string): Promise<any>;
}

class EdgeExecutionService implements ExecutionService {
  async execute(task: TaskRequirements, taskId: string): Promise<any> {
    console.log(`Executing task ${taskId} on EDGE:`, task);
    // Simulate edge execution
    await new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 500));
    return { result: 'edge_executed', taskId };
  }
}

class CloudExecutionService implements ExecutionService {
  async execute(task: TaskRequirements, taskId: string): Promise<any> {
    console.log(`Executing task ${taskId} on CLOUD:`, task);
    // Simulate cloud execution (e.g., API call to backend)
    await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 200));
    return { result: 'cloud_executed', taskId };
  }
}

export class TaskOrchestrator {
  private decisionEngine: OffloadingDecisionEngine;
  private capacityAnalyzer: CapacityAnalyzer;
  private edgeService: EdgeExecutionService;
  private cloudService: CloudExecutionService;
  private taskQueue: Array<{task: TaskRequirements, taskId: string, resolve: any, reject: any}> = [];
  private isProcessingQueue: boolean = false;

  constructor() {
    this.decisionEngine = new OffloadingDecisionEngine();
    // In a real edge environment, CapacityAnalyzer would be local.
    // For simulation, it might be passed or instantiated.
    this.capacityAnalyzer = CapacityAnalyzer.getInstance(); 
    this.edgeService = new EdgeExecutionService();
    this.cloudService = new CloudExecutionService();
  }

  public async submitTask(task: TaskRequirements, taskId: string): Promise<any> {
    return new Promise((resolve, reject) => {
        this.taskQueue.push({task, taskId, resolve, reject});
        this.processTaskQueue();
    });
  }

  private async processTaskQueue(): Promise<void> {
    if (this.isProcessingQueue || this.taskQueue.length === 0) {
        return;
    }
    this.isProcessingQueue = true;

    const {task, taskId, resolve, reject} = this.taskQueue.shift()!;

    try {
        const deviceCapacity = this.capacityAnalyzer.getCurrentCapacity();
        const location = this.decisionEngine.decideLocation(task, deviceCapacity);

        let result;
        switch (location) {
        case ProcessingLocation.EDGE:
            result = await this.edgeService.execute(task, taskId);
            break;
        case ProcessingLocation.CLOUD:
            if (deviceCapacity.networkType === 'none') {
                // Re-queue or handle error if cloud is chosen but no network
                console.warn(`Task ${taskId} requires cloud but no network. Re-queueing.`);
                this.taskQueue.unshift({task, taskId, resolve, reject}); // Add back to front
                this.isProcessingQueue = false;
                // Optional: Implement a delay or max retries for re-queueing
                setTimeout(() => this.processTaskQueue(), 5000); // Try again in 5s
                return;
            }
            result = await this.cloudService.execute(task, taskId);
            break;
        case ProcessingLocation.HYBRID:
            // Hybrid execution logic would be more complex
            console.log(`Task ${taskId} decided for HYBRID (not fully implemented, defaulting to cloud)`);
            result = await this.cloudService.execute(task, taskId);
            break;
        default:
            throw new Error('Unknown processing location');
        }
        resolve(result);
    } catch (error) {
        console.error(`Failed to execute task ${taskId}:`, error);
        reject(error);
    }

    this.isProcessingQueue = false;
    this.processTaskQueue(); // Process next task if any
  }
}

```

### 4. Definição de Tarefas e Metadados

As aplicações (frontend, IoT) que submetem tarefas ao orquestrador devem fornecer metadados claros sobre os requisitos da tarefa.

```typescript
// Exemplo de submissão de tarefa
// src/frontend/services/some-feature-service.ts
import { TaskOrchestrator } from '../../core/task-orchestrator';
import { TaskRequirements } from '../../core/offloading-decision-engine';

class FeatureService {
  private orchestrator: TaskOrchestrator;

  constructor() {
    this.orchestrator = new TaskOrchestrator();
  }

  async performImageAnalysis(imageData: ArrayBuffer): Promise<any> {
    const taskId = `image-analysis-${Date.now()}`;
    const taskRequirements: TaskRequirements = {
      computeIntensity: 'high', // Image analysis is usually compute-intensive
      memoryIntensity: 'medium',
      dataSensitivity: 'medium', // Could be high depending on image content
      latencyRequirement: 'medium', // User might be waiting, but not strictly real-time
      inputDataSize: imageData.byteLength / (1024 * 1024), // MB
      outputDataSize: 0.1, // Assuming small JSON output in MB
    };
    return this.orchestrator.submitTask(taskRequirements, taskId);
  }

  async quickLocalCheck(data: any): Promise<any> {
    const taskId = `local-check-${Date.now()}`;
    const taskRequirements: TaskRequirements = {
      computeIntensity: 'low',
      memoryIntensity: 'low',
      dataSensitivity: 'high', // Local check, keep data on device
      latencyRequirement: 'low', // Needs to be fast
      inputDataSize: 0.01, 
      outputDataSize: 0.001,
    };
    return this.orchestrator.submitTask(taskRequirements, taskId);
  }
}
```

## Fluxo de Decisão

1.  **Monitoramento Contínuo (Edge)**: `CapacityAnalyzer` no dispositivo edge coleta métricas de CPU, memória, bateria e rede.
2.  **Submissão de Tarefa**: Uma aplicação (frontend, IoT) submete uma tarefa ao `TaskOrchestrator`, incluindo `TaskRequirements` (intensidade computacional, sensibilidade dos dados, etc.).
3.  **Coleta de Capacidade**: O `TaskOrchestrator` consulta o `CapacityAnalyzer` para obter o estado atual do dispositivo edge.
4.  **Decisão de Offloading**: O `OffloadingDecisionEngine` recebe os `TaskRequirements` e a `DeviceCapacity`, aplicando um conjunto de regras e heurísticas para determinar a localização ideal (`EDGE`, `CLOUD`, `HYBRID`).
    *   **Prioridade à Privacidade**: Tarefas com alta sensibilidade de dados são preferencialmente executadas no edge, a menos que os recursos sejam insuficientes.
    *   **Requisitos de Latência**: Tarefas de baixa latência são priorizadas para o edge.
    *   **Estado do Dispositivo**: Bateria fraca ou recursos sobrecarregados no edge favorecem o offloading para a nuvem.
    *   **Condições de Rede**: Rede fraca ou ausente força a execução no edge (se possível); rede forte e estável facilita o offloading para a nuvem, especialmente para tarefas pesadas ou que envolvem grandes transferências de dados.
5.  **Execução da Tarefa**: O `TaskOrchestrator` direciona a tarefa para o serviço de execução apropriado (Edge ou Cloud).
    *   Se `CLOUD` for escolhido mas não houver rede, a tarefa pode ser enfileirada para execução posterior.
6.  **Feedback e Adaptação (Opcional Avançado)**: Resultados da execução e o tempo gasto podem retroalimentar o `OffloadingDecisionEngine` para refinar futuras decisões (não implementado neste exemplo básico).

## Considerações Adicionais

*   **Segurança no Offloading**: Transferências de dados para a nuvem devem ser sempre criptografadas (TLS). Dados sensíveis offloaded devem ser manuseados com extremo cuidado na nuvem, idealmente em ambientes isolados ou com criptografia em uso.
*   **Granularidade das Tarefas**: Tarefas muito pequenas podem ter um overhead de decisão e transferência que supera os benefícios do offloading. O sistema deve ser otimizado para tarefas de tamanho e complexidade significativos.
*   **Estado Compartilhado**: Se uma tarefa offloaded para a nuvem precisa de estado que reside no edge, mecanismos de sincronização (como os CRDTs implementados anteriormente) são cruciais.
*   **Cold Starts na Nuvem**: Para funções serverless na nuvem, o tempo de 
