/**
 * BazeX/QBeeX - Interface Revolucionária
 * Autor: Jordan Kim - Frontend Developer
 * Inspirado nos princípios de Steve Jobs: Simplicidade, Elegância, Funcionalidade
 */

import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  Brain, 
  Eye, 
  Shield, 
  Zap, 
  User, 
  Settings, 
  TrendingUp,
  Activity,
  Camera,
  Home,
  Bell,
  Search,
  Menu,
  X
} from 'lucide-react'
import './App.css'

// Componente de Login
const LoginScreen = ({ onLogin }) => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simular autenticação (integração real com Auth Service)
    setTimeout(() => {
      onLogin({ email, name: 'Usuário Demo' })
      setIsLoading(false)
    }, 1500)
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-emerald-900 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="w-full max-w-md"
      >
        <Card className="bg-black/20 backdrop-blur-xl border-white/10 shadow-2xl">
          <CardHeader className="text-center pb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.4, type: "spring" }}
              className="mx-auto w-16 h-16 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-2xl flex items-center justify-center mb-4"
            >
              <Brain className="w-8 h-8 text-black" />
            </motion.div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
              BazeX
            </CardTitle>
            <p className="text-slate-400 mt-2">Sua IA Preditiva Pessoal</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-4">
                <Input
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-slate-400"
                  required
                />
                <Input
                  type="password"
                  placeholder="Senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/5 border-white/10 text-white placeholder:text-slate-400"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-600 hover:to-emerald-600 text-black font-semibold"
                disabled={isLoading}
              >
                {isLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full"
                  />
                ) : (
                  'Entrar'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

// Componente de Navegação
const Navigation = ({ user, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <motion.nav 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="bg-black/20 backdrop-blur-xl border-b border-white/10 sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-black" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
              BazeX
            </span>
          </div>

          {/* Menu Desktop */}
          <div className="hidden md:flex items-center space-x-6">
            <Button variant="ghost" className="text-white hover:text-cyan-400">
              <Home className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <Button variant="ghost" className="text-white hover:text-cyan-400">
              <Activity className="w-4 h-4 mr-2" />
              Insights
            </Button>
            <Button variant="ghost" className="text-white hover:text-cyan-400">
              <Camera className="w-4 h-4 mr-2" />
              Visão
            </Button>
            <Button variant="ghost" className="text-white hover:text-cyan-400">
              <Settings className="w-4 h-4 mr-2" />
              Configurações
            </Button>
          </div>

          {/* User Menu */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-white">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-white">
              <Search className="w-4 h-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-black" />
              </div>
              <span className="text-white text-sm hidden sm:block">{user.name}</span>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-white"
            >
              {isMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Menu Mobile */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-black/40 backdrop-blur-xl border-t border-white/10"
          >
            <div className="px-4 py-4 space-y-2">
              <Button variant="ghost" className="w-full justify-start text-white">
                <Home className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <Button variant="ghost" className="w-full justify-start text-white">
                <Activity className="w-4 h-4 mr-2" />
                Insights
              </Button>
              <Button variant="ghost" className="w-full justify-start text-white">
                <Camera className="w-4 h-4 mr-2" />
                Visão
              </Button>
              <Button variant="ghost" className="w-full justify-start text-white">
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </Button>
              <hr className="border-white/10 my-2" />
              <Button 
                variant="ghost" 
                onClick={onLogout}
                className="w-full justify-start text-red-400 hover:text-red-300"
              >
                Sair
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}

// Componente do Dashboard Principal
const Dashboard = ({ user }) => {
  const [predictions, setPredictions] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simular carregamento de predições
    setTimeout(() => {
      setPredictions([
        {
          id: 1,
          type: 'behavior',
          title: 'Próxima Atividade Prevista',
          prediction: 'Você provavelmente irá trabalhar no projeto BazeX às 14:30',
          confidence: 0.89,
          icon: Activity
        },
        {
          id: 2,
          type: 'preference',
          title: 'Preferência Musical',
          prediction: 'Música eletrônica ambient seria ideal para seu foco agora',
          confidence: 0.76,
          icon: TrendingUp
        },
        {
          id: 3,
          type: 'environment',
          title: 'Contexto Ambiental',
          prediction: 'Iluminação atual está 23% abaixo do ideal para produtividade',
          confidence: 0.92,
          icon: Eye
        }
      ])
      setIsLoading(false)
    }, 1000)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-emerald-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-white mb-2">
            Olá, {user.name.split(' ')[0]} 👋
          </h1>
          <p className="text-slate-400 text-lg">
            Sua IA preditiva está analisando seu contexto em tempo real
          </p>
        </motion.div>

        {/* Status Cards */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <Card className="bg-black/20 backdrop-blur-xl border-white/10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Precisão da IA</p>
                  <p className="text-2xl font-bold text-white">94.2%</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-xl flex items-center justify-center">
                  <Brain className="w-6 h-6 text-black" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 backdrop-blur-xl border-white/10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Predições Hoje</p>
                  <p className="text-2xl font-bold text-white">127</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-400 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-black" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/20 backdrop-blur-xl border-white/10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm">Privacidade</p>
                  <p className="text-2xl font-bold text-white">100%</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-400 rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-black" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Predições */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold text-white mb-6">Predições Inteligentes</h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-black/20 backdrop-blur-xl border-white/10">
                  <CardContent className="p-6">
                    <div className="animate-pulse">
                      <div className="h-4 bg-white/10 rounded mb-4"></div>
                      <div className="h-6 bg-white/10 rounded mb-2"></div>
                      <div className="h-4 bg-white/10 rounded w-3/4"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {predictions.map((prediction, index) => (
                <motion.div
                  key={prediction.id}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <Card className="bg-black/20 backdrop-blur-xl border-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer group">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <prediction.icon className="w-6 h-6 text-black" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-white font-semibold mb-2">{prediction.title}</h3>
                          <p className="text-slate-300 text-sm mb-3">{prediction.prediction}</p>
                          <div className="flex items-center justify-between">
                            <Badge 
                              variant="secondary" 
                              className="bg-white/10 text-white border-white/20"
                            >
                              {Math.round(prediction.confidence * 100)}% confiança
                            </Badge>
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="text-cyan-400 hover:text-cyan-300"
                            >
                              Ver detalhes
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

// Componente Principal da Aplicação
function App() {
  const [user, setUser] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Verificar se há usuário logado (localStorage, token, etc.)
    const savedUser = localStorage.getItem('bazex_user')
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])

  const handleLogin = (userData) => {
    setUser(userData)
    localStorage.setItem('bazex_user', JSON.stringify(userData))
  }

  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem('bazex_user')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-emerald-900 flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full"
        />
      </div>
    )
  }

  return (
    <Router>
      <div className="App">
        {!user ? (
          <LoginScreen onLogin={handleLogin} />
        ) : (
          <>
            <Navigation user={user} onLogout={handleLogout} />
            <Routes>
              <Route path="/" element={<Dashboard user={user} />} />
              <Route path="/dashboard" element={<Dashboard user={user} />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </>
        )}
      </div>
    </Router>
  )
}

export default App

