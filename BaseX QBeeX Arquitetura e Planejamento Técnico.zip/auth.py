"""
Módulo de autenticação e autorização
Autor: Maya Patel - Backend Developer
"""

from datetime import datetime, timedelta
from typing import Optional, Union
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import structlog

from .config import settings
from .database import get_db
from .models import User, TokenData
from .cache import get_redis, is_token_blacklisted

logger = structlog.get_logger()

# Configuração do contexto de criptografia
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Security scheme
security = HTTPBearer()

def hash_password(password: str) -> str:
    """
    Gera hash da senha usando bcrypt
    
    Args:
        password: Senha em texto plano
        
    Returns:
        Hash da senha
    """
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verifica se a senha corresponde ao hash
    
    Args:
        plain_password: Senha em texto plano
        hashed_password: Hash da senha armazenada
        
    Returns:
        True se a senha estiver correta
    """
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Cria um access token JWT
    
    Args:
        data: Dados a serem incluídos no token
        expires_delta: Tempo de expiração customizado
        
    Returns:
        Token JWT codificado
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "access"
    })
    
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.SECRET_KEY, 
        algorithm=settings.ALGORITHM
    )
    
    logger.debug("Access token criado", user_id=data.get("sub"), expires_at=expire)
    
    return encoded_jwt

def create_refresh_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Cria um refresh token JWT
    
    Args:
        data: Dados a serem incluídos no token
        expires_delta: Tempo de expiração customizado
        
    Returns:
        Refresh token JWT codificado
    """
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    
    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "refresh"
    })
    
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.REFRESH_SECRET_KEY, 
        algorithm=settings.ALGORITHM
    )
    
    logger.debug("Refresh token criado", user_id=data.get("sub"), expires_at=expire)
    
    return encoded_jwt

def verify_token(token: str, secret_key: str = None) -> dict:
    """
    Verifica e decodifica um token JWT
    
    Args:
        token: Token JWT a ser verificado
        secret_key: Chave secreta (usa SECRET_KEY por padrão)
        
    Returns:
        Payload decodificado do token
        
    Raises:
        JWTError: Se o token for inválido
    """
    if secret_key is None:
        secret_key = settings.SECRET_KEY
    
    try:
        payload = jwt.decode(
            token, 
            secret_key, 
            algorithms=[settings.ALGORITHM]
        )
        return payload
    except JWTError as e:
        logger.warning("Token inválido", error=str(e))
        raise e

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
    redis = Depends(get_redis)
) -> User:
    """
    Obtém o usuário atual baseado no token JWT
    
    Args:
        credentials: Credenciais HTTP Bearer
        db: Sessão do banco de dados
        redis: Cliente Redis
        
    Returns:
        Usuário autenticado
        
    Raises:
        HTTPException: Se o token for inválido ou usuário não encontrado
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Não foi possível validar as credenciais",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        token = credentials.credentials
        
        # Verificar se o token está na blacklist
        if await is_token_blacklisted(redis, token):
            logger.warning("Tentativa de uso de token blacklisted")
            raise credentials_exception
        
        # Decodificar token
        payload = verify_token(token)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if user_id is None or token_type != "access":
            logger.warning("Token sem user_id ou tipo incorreto")
            raise credentials_exception
            
    except JWTError:
        logger.warning("Erro ao decodificar token JWT")
        raise credentials_exception
    
    # Buscar usuário no banco
    user = db.query(User).filter(User.id == int(user_id)).first()
    if user is None:
        logger.warning("Usuário não encontrado", user_id=user_id)
        raise credentials_exception
    
    if not user.is_active:
        logger.warning("Usuário inativo tentando acessar", user_id=user_id)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário inativo"
        )
    
    return user

async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    Obtém o usuário atual ativo
    
    Args:
        current_user: Usuário atual
        
    Returns:
        Usuário ativo
        
    Raises:
        HTTPException: Se o usuário estiver inativo
    """
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Usuário inativo"
        )
    return current_user

async def get_current_superuser(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    Obtém o usuário atual se for superuser
    
    Args:
        current_user: Usuário atual
        
    Returns:
        Superusuário
        
    Raises:
        HTTPException: Se o usuário não for superuser
    """
    if not current_user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Privilégios insuficientes"
        )
    return current_user

def create_password_reset_token(email: str) -> str:
    """
    Cria token para reset de senha
    
    Args:
        email: Email do usuário
        
    Returns:
        Token de reset de senha
    """
    delta = timedelta(hours=settings.PASSWORD_RESET_TOKEN_EXPIRE_HOURS)
    now = datetime.utcnow()
    expires = now + delta
    
    exp = expires.timestamp()
    encoded_jwt = jwt.encode(
        {"exp": exp, "nbf": now, "sub": email, "type": "password_reset"},
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )
    return encoded_jwt

def verify_password_reset_token(token: str) -> Optional[str]:
    """
    Verifica token de reset de senha
    
    Args:
        token: Token de reset
        
    Returns:
        Email do usuário se o token for válido
    """
    try:
        decoded_token = jwt.decode(
            token, 
            settings.SECRET_KEY, 
            algorithms=[settings.ALGORITHM]
        )
        
        if decoded_token.get("type") != "password_reset":
            return None
            
        return decoded_token.get("sub")
    except JWTError:
        return None

def validate_password_strength(password: str) -> tuple[bool, list[str]]:
    """
    Valida a força da senha
    
    Args:
        password: Senha a ser validada
        
    Returns:
        Tupla (é_válida, lista_de_erros)
    """
    errors = []
    
    if len(password) < 8:
        errors.append("Senha deve ter pelo menos 8 caracteres")
    
    if not any(c.isupper() for c in password):
        errors.append("Senha deve conter pelo menos uma letra maiúscula")
    
    if not any(c.islower() for c in password):
        errors.append("Senha deve conter pelo menos uma letra minúscula")
    
    if not any(c.isdigit() for c in password):
        errors.append("Senha deve conter pelo menos um número")
    
    special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    if not any(c in special_chars for c in password):
        errors.append("Senha deve conter pelo menos um caractere especial")
    
    # Verificar sequências comuns
    common_sequences = ["123456", "abcdef", "qwerty", "password"]
    if any(seq in password.lower() for seq in common_sequences):
        errors.append("Senha não pode conter sequências comuns")
    
    return len(errors) == 0, errors

class RoleChecker:
    """Classe para verificação de roles/permissões"""
    
    def __init__(self, allowed_roles: list[str]):
        self.allowed_roles = allowed_roles
    
    def __call__(self, current_user: User = Depends(get_current_user)):
        if current_user.is_superuser:
            return current_user
        
        # Aqui você pode implementar lógica de roles mais complexa
        # Por enquanto, apenas superuser tem acesso total
        
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Permissões insuficientes"
        )

# Instâncias de verificadores de role
require_admin = RoleChecker(["admin"])
require_moderator = RoleChecker(["admin", "moderator"])
require_user = RoleChecker(["admin", "moderator", "user"])

