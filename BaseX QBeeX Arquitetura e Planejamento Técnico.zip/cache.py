"""
Módulo de cache Redis para o Auth Service
Autor: Maya Patel - Backend Developer
"""

import redis.asyncio as redis
import json
from typing import Optional, Any
from datetime import timedelta
import structlog

from .config import settings

logger = structlog.get_logger()

# Pool de conexões Redis
redis_pool = None

async def init_redis():
    """Inicializa o pool de conexões Redis"""
    global redis_pool
    
    try:
        redis_pool = redis.ConnectionPool.from_url(
            settings.REDIS_URL,
            password=settings.REDIS_PASSWORD,
            max_connections=settings.REDIS_MAX_CONNECTIONS,
            decode_responses=True
        )
        
        # Testar conexão
        redis_client = redis.Redis(connection_pool=redis_pool)
        await redis_client.ping()
        
        logger.info("✅ Redis conectado com sucesso")
        
    except Exception as e:
        logger.error("❌ Erro ao conectar com Redis", error=str(e))
        raise

async def get_redis():
    """Dependency para obter cliente Redis"""
    if redis_pool is None:
        await init_redis()
    
    return redis.Redis(connection_pool=redis_pool)

async def close_redis():
    """Fecha as conexões Redis"""
    global redis_pool
    if redis_pool:
        await redis_pool.disconnect()
        logger.info("Redis desconectado")

# Funções de cache para tokens

async def cache_token(redis_client: redis.Redis, token: str, user_id: int, ttl: int = None):
    """
    Armazena token no cache
    
    Args:
        redis_client: Cliente Redis
        token: Token JWT
        user_id: ID do usuário
        ttl: Time to live em segundos
    """
    if ttl is None:
        ttl = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
    
    key = f"token:{token}"
    value = {
        "user_id": user_id,
        "cached_at": str(datetime.utcnow())
    }
    
    try:
        await redis_client.setex(key, ttl, json.dumps(value))
        logger.debug("Token cacheado", user_id=user_id, ttl=ttl)
    except Exception as e:
        logger.error("Erro ao cachear token", error=str(e))

async def get_cached_token(redis_client: redis.Redis, token: str) -> Optional[dict]:
    """
    Recupera token do cache
    
    Args:
        redis_client: Cliente Redis
        token: Token JWT
        
    Returns:
        Dados do token ou None se não encontrado
    """
    key = f"token:{token}"
    
    try:
        cached_data = await redis_client.get(key)
        if cached_data:
            return json.loads(cached_data)
        return None
    except Exception as e:
        logger.error("Erro ao recuperar token do cache", error=str(e))
        return None

async def invalidate_token(redis_client: redis.Redis, token: str):
    """
    Invalida token (adiciona à blacklist)
    
    Args:
        redis_client: Cliente Redis
        token: Token JWT a ser invalidado
    """
    blacklist_key = f"blacklist:{token}"
    
    try:
        # Adicionar à blacklist com TTL igual ao tempo de expiração do token
        ttl = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
        await redis_client.setex(blacklist_key, ttl, "1")
        
        # Remover do cache de tokens válidos
        token_key = f"token:{token}"
        await redis_client.delete(token_key)
        
        logger.debug("Token invalidado", token_prefix=token[:10])
        
    except Exception as e:
        logger.error("Erro ao invalidar token", error=str(e))

async def is_token_blacklisted(redis_client: redis.Redis, token: str) -> bool:
    """
    Verifica se token está na blacklist
    
    Args:
        redis_client: Cliente Redis
        token: Token JWT
        
    Returns:
        True se o token estiver na blacklist
    """
    blacklist_key = f"blacklist:{token}"
    
    try:
        result = await redis_client.exists(blacklist_key)
        return bool(result)
    except Exception as e:
        logger.error("Erro ao verificar blacklist", error=str(e))
        return False

# Funções de cache para rate limiting

async def check_rate_limit(redis_client: redis.Redis, key: str, limit: int, window: int) -> tuple[bool, int]:
    """
    Verifica rate limit usando sliding window
    
    Args:
        redis_client: Cliente Redis
        key: Chave única para o rate limit
        limit: Número máximo de tentativas
        window: Janela de tempo em segundos
        
    Returns:
        Tupla (permitido, tentativas_restantes)
    """
    try:
        current_time = int(time.time())
        pipeline = redis_client.pipeline()
        
        # Remover entradas antigas
        pipeline.zremrangebyscore(key, 0, current_time - window)
        
        # Contar tentativas atuais
        pipeline.zcard(key)
        
        # Adicionar tentativa atual
        pipeline.zadd(key, {str(current_time): current_time})
        
        # Definir expiração
        pipeline.expire(key, window)
        
        results = await pipeline.execute()
        current_count = results[1]
        
        if current_count < limit:
            return True, limit - current_count - 1
        else:
            # Remover a tentativa que acabamos de adicionar
            await redis_client.zrem(key, str(current_time))
            return False, 0
            
    except Exception as e:
        logger.error("Erro ao verificar rate limit", error=str(e))
        # Em caso de erro, permitir a operação
        return True, limit

async def increment_login_attempts(redis_client: redis.Redis, email: str) -> int:
    """
    Incrementa contador de tentativas de login
    
    Args:
        redis_client: Cliente Redis
        email: Email do usuário
        
    Returns:
        Número atual de tentativas
    """
    key = f"login_attempts:{email}"
    
    try:
        attempts = await redis_client.incr(key)
        if attempts == 1:
            # Definir expiração apenas na primeira tentativa
            await redis_client.expire(key, settings.LOCKOUT_DURATION_MINUTES * 60)
        
        return attempts
    except Exception as e:
        logger.error("Erro ao incrementar tentativas de login", error=str(e))
        return 0

async def reset_login_attempts(redis_client: redis.Redis, email: str):
    """
    Reseta contador de tentativas de login
    
    Args:
        redis_client: Cliente Redis
        email: Email do usuário
    """
    key = f"login_attempts:{email}"
    
    try:
        await redis_client.delete(key)
        logger.debug("Tentativas de login resetadas", email=email)
    except Exception as e:
        logger.error("Erro ao resetar tentativas de login", error=str(e))

async def is_account_locked(redis_client: redis.Redis, email: str) -> bool:
    """
    Verifica se conta está bloqueada
    
    Args:
        redis_client: Cliente Redis
        email: Email do usuário
        
    Returns:
        True se a conta estiver bloqueada
    """
    if not settings.ENABLE_ACCOUNT_LOCKOUT:
        return False
    
    key = f"login_attempts:{email}"
    
    try:
        attempts = await redis_client.get(key)
        if attempts and int(attempts) >= settings.MAX_LOGIN_ATTEMPTS:
            return True
        return False
    except Exception as e:
        logger.error("Erro ao verificar bloqueio de conta", error=str(e))
        return False

# Funções de cache para sessões

async def cache_user_session(redis_client: redis.Redis, user_id: int, session_data: dict, ttl: int = None):
    """
    Armazena dados da sessão do usuário
    
    Args:
        redis_client: Cliente Redis
        user_id: ID do usuário
        session_data: Dados da sessão
        ttl: Time to live em segundos
    """
    if ttl is None:
        ttl = settings.SESSION_TIMEOUT_MINUTES * 60
    
    key = f"session:{user_id}"
    
    try:
        await redis_client.setex(key, ttl, json.dumps(session_data))
        logger.debug("Sessão cacheada", user_id=user_id)
    except Exception as e:
        logger.error("Erro ao cachear sessão", error=str(e))

async def get_user_session(redis_client: redis.Redis, user_id: int) -> Optional[dict]:
    """
    Recupera dados da sessão do usuário
    
    Args:
        redis_client: Cliente Redis
        user_id: ID do usuário
        
    Returns:
        Dados da sessão ou None
    """
    key = f"session:{user_id}"
    
    try:
        session_data = await redis_client.get(key)
        if session_data:
            return json.loads(session_data)
        return None
    except Exception as e:
        logger.error("Erro ao recuperar sessão", error=str(e))
        return None

async def invalidate_user_session(redis_client: redis.Redis, user_id: int):
    """
    Invalida sessão do usuário
    
    Args:
        redis_client: Cliente Redis
        user_id: ID do usuário
    """
    key = f"session:{user_id}"
    
    try:
        await redis_client.delete(key)
        logger.debug("Sessão invalidada", user_id=user_id)
    except Exception as e:
        logger.error("Erro ao invalidar sessão", error=str(e))

# Funções utilitárias

async def cache_set(redis_client: redis.Redis, key: str, value: Any, ttl: int = 3600):
    """
    Função genérica para cache
    
    Args:
        redis_client: Cliente Redis
        key: Chave do cache
        value: Valor a ser cacheado
        ttl: Time to live em segundos
    """
    try:
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        
        await redis_client.setex(key, ttl, value)
    except Exception as e:
        logger.error("Erro ao definir cache", key=key, error=str(e))

async def cache_get(redis_client: redis.Redis, key: str, parse_json: bool = False) -> Optional[Any]:
    """
    Função genérica para recuperar do cache
    
    Args:
        redis_client: Cliente Redis
        key: Chave do cache
        parse_json: Se deve fazer parse JSON do valor
        
    Returns:
        Valor do cache ou None
    """
    try:
        value = await redis_client.get(key)
        if value and parse_json:
            return json.loads(value)
        return value
    except Exception as e:
        logger.error("Erro ao recuperar cache", key=key, error=str(e))
        return None

async def cache_delete(redis_client: redis.Redis, key: str):
    """
    Remove item do cache
    
    Args:
        redis_client: Cliente Redis
        key: Chave do cache
    """
    try:
        await redis_client.delete(key)
    except Exception as e:
        logger.error("Erro ao deletar cache", key=key, error=str(e))

